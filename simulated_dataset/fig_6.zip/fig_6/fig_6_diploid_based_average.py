#
#		SLF-RNAse interaction in Non-self recognition self-incompatible (SI) System
#
##########################################################################################

#from mpl_toolkits.mplot3d import Axes3D
#import pylab
#import sympy as sp
#from operator import itemgetter
#from scipy import linalg
from pylab import genfromtxt
#import fit
#import networkx as nx
from multiprocessing import Pool#, TimeoutError, Process, Queue, Pipe, Value, Array
import os, math, pdb, time, random as ra, numpy as np, matplotlib.pyplot as plt, sys
import collections, pickle
from datetime import datetime
#from numba import jit
import pickle
from scipy.optimize import curve_fit
import matplotlib.ticker as mtick
#from scipy.integrate import odeint
#from scipy.signal import argrelextrema, find_peaks
#from scipy import signal
########################################################################################################
start_time = datetime.now()
print ('Starts|--------|', start_time)

weight = [0.5, 0.265, 0.113, 0.122]

output_dir = './data_fig_6_dup' # './data_fig_6'

def data_To_Plot(input_Var):
    splt_iter = input_Var

    # input data
    min_duration = 10
    d_iters = 10
    directory = output_dir #'./data_fig_6_dup'

    with open(output_dir + '/analyze_split_rnase_cros_slfs_info_' + str(min_duration * 10) + '_iters_bot.pkl', 'rb') as input:
        analyze_split_rnase_cros_slfs_info = pickle.load(input)

    if splt_iter in [47450, 45670, 51980, 43870]:
        with open(output_dir + '/analyze_split_rnase_cros_slfs_info_' + str(min_duration * 10) + '_iters_top.pkl', 'rb') as input:
            analyze_split_rnase_cros_slfs_info = pickle.load(input)

    if splt_iter in [69990]:
        with open(output_dir + '/analyze_split_rnase_cros_slfs_info_' + str(min_duration * 10) + '_iters_mid.pkl', 'rb') as input:
            analyze_split_rnase_cros_slfs_info = pickle.load(input)
        #print (analyze_split_rnase_cros_slfs_info.keys())

    if splt_iter in [98870]:
        with open(output_dir + '/analyze_split_rnase_cros_slfs_info_' + str(min_duration * 10) + '_iters_bot.pkl', 'rb') as input:
            analyze_split_rnase_cros_slfs_info = pickle.load(input)

    with open(directory + '/num_paths_RNase_SLFmut_SLForig.pkl', 'rb') as input:
        num_paths_RNase_SLFmut_SLForig = pickle.load(input)

    with open(directory + '/num_paths_RNase_SLForig_SLFmut.pkl', 'rb') as input:
        num_paths_RNase_SLForig_SLFmut = pickle.load(input)

    with open(directory + '/num_paths_SLForig_RNase_SLFmut.pkl', 'rb') as input:
        num_paths_SLForig_RNase_SLFmut = pickle.load(input)

    with open(directory + '/num_paths_SLForig_SLFmut_RNase.pkl', 'rb') as input:
        num_paths_SLForig_SLFmut_RNase = pickle.load(input)

    with open(directory + '/num_paths_SLFmut_RNase_SLForig.pkl', 'rb') as input:
        num_paths_SLFmut_RNase_SLForig = pickle.load(input)

    with open(directory + '/num_paths_SLFmut_SLForig_RNase.pkl', 'rb') as input:
        num_paths_SLFmut_SLForig_RNase = pickle.load(input)

    counts_Of_Events = [num_paths_RNase_SLFmut_SLForig,\
                        num_paths_RNase_SLForig_SLFmut,\
                        num_paths_SLForig_RNase_SLFmut,\
                        num_paths_SLForig_SLFmut_RNase,\
                        num_paths_SLFmut_RNase_SLForig,\
                        num_paths_SLFmut_SLForig_RNase]


    #print (counts_Of_Events)
    ###########################
    # first split path
    ###########################
    splt_iter = input_Var
    val = analyze_split_rnase_cros_slfs_info[splt_iter][0]
    mut_iters = [val['rnase_mut_iter'], int(np.ceil(val['iter_cros_mut_slf_mut_gro'] / d_iters) * d_iters),
                 int(np.ceil(val['iter_cros_mut_slf_orig_gro'] / d_iters) * d_iters)]
    iters_values = np.arange(np.min(mut_iters), splt_iter + 5 * d_iters, d_iters)

    #print (mut_iters)
    #print (iters_values)

    with open(output_dir + '/fitness_avg_dict_' + 'splt_iter_' + str(splt_iter) + '_' + str(min_duration * 10) + '_iters.pkl',
            'rb') as input:
        fitness_avg_dict = pickle.load(input)

    with open(output_dir + '/tot_fitness_hap_orig_rnase' + 'splt_iter_' + str(splt_iter) + '_' + str(
            min_duration * 10) + '_iters.pkl', 'rb') as input:
        tot_fitness_hap_orig_rnase = pickle.load(input)

    with open(output_dir + '/tot_num_hap_orig_rnase' + 'splt_iter_' + str(splt_iter) + '_' + str(
            min_duration * 10) + '_iters.pkl', 'rb') as input:
        tot_num_hap_orig_rnase = pickle.load(input)

    with open(output_dir + '/tot_fitness_hap_mut_rnase' + 'splt_iter_' + str(splt_iter) + '_' + str(
            min_duration * 10) + '_iters.pkl', 'rb') as input:
        tot_fitness_hap_mut_rnase = pickle.load(input)

    with open(output_dir + '/tot_num_hap_mut_rnase' + 'splt_iter_' + str(splt_iter) + '_' + str(
            min_duration * 10) + '_iters.pkl', 'rb') as input:
        tot_num_hap_mut_rnase = pickle.load(input)

    with open(output_dir + '/tot_num_hap_cross_orig_rnase' + 'splt_iter_' + str(splt_iter) + '_' + str(
            min_duration * 10) + '_iters.pkl', 'rb') as input:
        tot_num_hap_cross_orig_rnase = pickle.load(input)

    with open(output_dir + '/tot_fitness_hap_cross_orig_rnase' + 'splt_iter_' + str(splt_iter) + '_' + str(
            min_duration * 10) + '_iters.pkl', 'rb') as input:
        tot_fitness_hap_cross_orig_rnase = pickle.load(input)

    with open(output_dir + '/tot_num_hap_cross_mut_rnase' + 'splt_iter_' + str(splt_iter) + '_' + str(
            min_duration * 10) + '_iters.pkl', 'rb') as input:
        tot_num_hap_cross_mut_rnase = pickle.load(input)

    with open(output_dir + '/tot_fitness_hap_cross_mut_rnase' + 'splt_iter_' + str(splt_iter) + '_' + str(
            min_duration * 10) + '_iters.pkl', 'rb') as input:
        tot_fitness_hap_cross_mut_rnase = pickle.load(input)

    with open(output_dir + '/tot_num_hap_full_cross_orig_rnase' + 'splt_iter_' + str(splt_iter) + '_' + str(
            min_duration * 10) + '_iters.pkl', 'rb') as input:
        tot_num_hap_full_cross_orig_rnase = pickle.load(input)

    with open(output_dir + '/tot_fitness_hap_full_cross_orig_rnase' + 'splt_iter_' + str(splt_iter) + '_' + str(
            min_duration * 10) + '_iters.pkl', 'rb') as input:
        tot_fitness_hap_full_cross_orig_rnase = pickle.load(input)

    with open(output_dir + '/tot_num_hap_full_cross_mut_rnase' + 'splt_iter_' + str(splt_iter) + '_' + str(
            min_duration * 10) + '_iters.pkl', 'rb') as input:
        tot_num_hap_full_cross_mut_rnase = pickle.load(input)

    with open(output_dir + '/tot_fitness_hap_full_cross_mut_rnase' + 'splt_iter_' + str(splt_iter) + '_' + str(
            min_duration * 10) + '_iters.pkl', 'rb') as input:
        tot_fitness_hap_full_cross_mut_rnase = pickle.load(input)

    sum_tot_num_hap_orig_rnase = {}
    sum_tot_num_hap_mut_rnase = {}
    sum_tot_num_hap_cross_orig_rnase = {}
    sum_tot_num_hap_cross_mut_rnase = {}
    sum_tot_num_hap_full_cross_orig_rnase = {}
    sum_tot_num_hap_full_cross_mut_rnase = {}

    for i, num_hap_orig_rnase_dict in tot_num_hap_orig_rnase.items():
        for iter_ind, num in num_hap_orig_rnase_dict.items():
            if not np.isnan(num):
                if iter_ind not in sum_tot_num_hap_orig_rnase:
                    sum_tot_num_hap_orig_rnase[iter_ind] = 0
                sum_tot_num_hap_orig_rnase[iter_ind] += num

    for i, num_hap_mut_rnase_dict in tot_num_hap_mut_rnase.items():
        for iter_ind, num in num_hap_mut_rnase_dict.items():
            if not np.isnan(num):
                if iter_ind not in sum_tot_num_hap_mut_rnase:
                    sum_tot_num_hap_mut_rnase[iter_ind] = 0
                sum_tot_num_hap_mut_rnase[iter_ind] += num

    for i, num_hap_cross_orig_rnase in tot_num_hap_cross_orig_rnase.items():
        for iter_ind, num in num_hap_cross_orig_rnase.items():
            if not np.isnan(num):
                if iter_ind not in sum_tot_num_hap_cross_orig_rnase:
                    sum_tot_num_hap_cross_orig_rnase[iter_ind] = 0
                sum_tot_num_hap_cross_orig_rnase[iter_ind] += num

    for i, num_hap_cross_mut_rnase in tot_num_hap_cross_mut_rnase.items():
        for iter_ind, num in num_hap_cross_mut_rnase.items():
            if not np.isnan(num):
                if iter_ind not in sum_tot_num_hap_cross_mut_rnase:
                    sum_tot_num_hap_cross_mut_rnase[iter_ind] = 0
                sum_tot_num_hap_cross_mut_rnase[iter_ind] += num

    for i, num_hap_full_cross_orig_rnase in tot_num_hap_full_cross_orig_rnase.items():
        for iter_ind, num in num_hap_full_cross_orig_rnase.items():
            if not np.isnan(num):
                if iter_ind not in sum_tot_num_hap_full_cross_orig_rnase:
                    sum_tot_num_hap_full_cross_orig_rnase[iter_ind] = 0
                sum_tot_num_hap_full_cross_orig_rnase[iter_ind] += num

    for i, num_hap_full_cross_mut_rnase in tot_num_hap_full_cross_mut_rnase.items():
        for iter_ind, num in num_hap_full_cross_mut_rnase.items():
            if not np.isnan(num):
                if iter_ind not in sum_tot_num_hap_full_cross_mut_rnase:
                    sum_tot_num_hap_full_cross_mut_rnase[iter_ind] = 0
                sum_tot_num_hap_full_cross_mut_rnase[iter_ind] += num

    box_1_Panel_1_Data = [
        sum_tot_num_hap_orig_rnase, \
        sum_tot_num_hap_mut_rnase, \
        sum_tot_num_hap_cross_orig_rnase, \
        sum_tot_num_hap_cross_mut_rnase, \
        sum_tot_num_hap_full_cross_orig_rnase, \
        sum_tot_num_hap_full_cross_mut_rnase, \
        ]

    box_1_Panel_2_Data = [
        tot_fitness_hap_orig_rnase, \
        tot_fitness_hap_mut_rnase, \
        tot_fitness_hap_cross_orig_rnase, \
        tot_fitness_hap_cross_mut_rnase, \
        tot_fitness_hap_full_cross_orig_rnase, \
        tot_fitness_hap_full_cross_mut_rnase, \
        ]

    with open(output_dir + '/expected_num_change_orig_rnase_dict' + 'splt_iter_' + str(splt_iter) + '_' + str(
            min_duration * 10) + '_iters.pkl', 'rb') as input:
        expected_num_adjusted_orig_rnase_dict = pickle.load(input)

    with open(output_dir + '/expected_num_change_mut_rnase_dict' + 'splt_iter_' + str(splt_iter) + '_' + str(
            min_duration * 10) + '_iters.pkl', 'rb') as input:
        expected_num_adjusted_mut_rnase_dict = pickle.load(input)

    with open(output_dir + '/expected_num_change_cross_SLF_in_mut_dict' + 'splt_iter_' + str(splt_iter) + '_' + str(
            min_duration * 10) + '_iters.pkl', 'rb') as input:
        expected_num_adjusted_cross_SLF_in_mut_dict = pickle.load(input)

    with open(output_dir + '/expected_num_change_cross_SLF_in_orig_dict' + 'splt_iter_' + str(splt_iter) + '_' + str(
            min_duration * 10) + '_iters.pkl', 'rb') as input:
        expected_num_adjusted_cross_SLF_in_orig_dict = pickle.load(input)

    with open(output_dir + '/expected_num_change_full_cross_SLF_in_mut_dict' + 'splt_iter_' + str(splt_iter) + '_' + str(
            min_duration * 10) + '_iters.pkl', 'rb') as input:
        expected_num_adjusted_full_cross_SLF_in_mut_dict = pickle.load(input)

    with open(output_dir + '/expected_num_change_full_cross_SLF_in_orig_dict' + 'splt_iter_' + str(splt_iter) + '_' + str(
            min_duration * 10) + '_iters.pkl', 'rb') as input:
        expected_num_adjusted_full_cross_SLF_in_orig_dict = pickle.load(input)

    sum_expected_num_adjusted_orig_rnase_dict = {}
    sum_expected_num_adjusted_mut_rnase_dict = {}
    sum_expected_num_adjusted_cross_SLF_in_orig_dict = {}
    sum_expected_num_adjusted_cross_SLF_in_mut_dict = {}
    sum_expected_num_adjusted_full_cross_SLF_in_orig_dict = {}
    sum_expected_num_adjusted_full_cross_SLF_in_mut_dict = {}

    for i, expected_dict in expected_num_adjusted_orig_rnase_dict.items():
        for iter_ind, num in expected_dict.items():
            if not np.isnan(num):
                if iter_ind not in sum_expected_num_adjusted_orig_rnase_dict:
                    sum_expected_num_adjusted_orig_rnase_dict[iter_ind] = 0
                sum_expected_num_adjusted_orig_rnase_dict[iter_ind] += num

    for i, expected_dict in expected_num_adjusted_mut_rnase_dict.items():
        for iter_ind, num in expected_dict.items():
            if not np.isnan(num):
                if iter_ind not in sum_expected_num_adjusted_mut_rnase_dict:
                    sum_expected_num_adjusted_mut_rnase_dict[iter_ind] = 0
                sum_expected_num_adjusted_mut_rnase_dict[iter_ind] += num

    for i, expected_dict in expected_num_adjusted_cross_SLF_in_orig_dict.items():
        for iter_ind, num in expected_dict.items():
            if not np.isnan(num):
                if iter_ind not in sum_expected_num_adjusted_cross_SLF_in_orig_dict:
                    sum_expected_num_adjusted_cross_SLF_in_orig_dict[iter_ind] = 0
                sum_expected_num_adjusted_cross_SLF_in_orig_dict[iter_ind] += num

    for i, expected_dict in expected_num_adjusted_cross_SLF_in_mut_dict.items():
        for iter_ind, num in expected_dict.items():
            if not np.isnan(num):
                if iter_ind not in sum_expected_num_adjusted_cross_SLF_in_mut_dict:
                    sum_expected_num_adjusted_cross_SLF_in_mut_dict[iter_ind] = 0
                sum_expected_num_adjusted_cross_SLF_in_mut_dict[iter_ind] += num

    for i, expected_dict in expected_num_adjusted_full_cross_SLF_in_orig_dict.items():
        for iter_ind, num in expected_dict.items():
            if not np.isnan(num):
                if iter_ind not in sum_expected_num_adjusted_full_cross_SLF_in_orig_dict:
                    sum_expected_num_adjusted_full_cross_SLF_in_orig_dict[iter_ind] = 0
                sum_expected_num_adjusted_full_cross_SLF_in_orig_dict[iter_ind] += num

    for i, expected_dict in expected_num_adjusted_full_cross_SLF_in_mut_dict.items():
        for iter_ind, num in expected_dict.items():
            if not np.isnan(num):
                if iter_ind not in sum_expected_num_adjusted_full_cross_SLF_in_mut_dict:
                    sum_expected_num_adjusted_full_cross_SLF_in_mut_dict[iter_ind] = 0
                sum_expected_num_adjusted_full_cross_SLF_in_mut_dict[iter_ind] += num


    box_1_Panel_3_Data = [
        sum_expected_num_adjusted_orig_rnase_dict, \
        sum_expected_num_adjusted_mut_rnase_dict, \
        sum_expected_num_adjusted_cross_SLF_in_orig_dict, \
        sum_expected_num_adjusted_cross_SLF_in_mut_dict, \
        sum_expected_num_adjusted_full_cross_SLF_in_orig_dict, \
        sum_expected_num_adjusted_full_cross_SLF_in_mut_dict, \
        ]

    return [box_1_Panel_1_Data, box_1_Panel_2_Data, box_1_Panel_3_Data, fitness_avg_dict, iters_values, counts_Of_Events]















#
#
#
#############
def fert_Mut_Class(input_Var): # Box plot

    fig = plt.figure(figsize=(7.0,11.3))
    plt.subplots_adjust(top=0.970, bottom=0.004, left=0.083, right=0.990, hspace=25.25, wspace=25.5)
    fontsizeX, fontsizeY, fonttitle, fontticks, fontsizetext = 9, 10, 9, 7.5, 8

    fig_Grid_Size = (200,53)
    height_Row, height_Col = 16, 24
    small_gap, big_gap, small_gap_Col, extra_ini_gap = 1, 9, 5, 8
    subplot_Index = [0, 2, 4, 1, 3, 5, 6, 8, 10, 7, 9, 11]
    fig_Title = ['a', 'a', 'b', 'b', 'c', 'c', 'a', 'd', 'b', 'b', 'c', 'c']
    fig_Title = ['a', 'b', 'c']
    alpha_Color = 0.25
    color_b, color_r = [0/2**8,158/2**8,231/2**8], [175/2**8,45/2**8,47/2**8]
    lw = 0.5; mW = 1.5; mS = 6.5

    splt_iter = 45670
    box_1_Panel_1_Data, box_1_Panel_2_Data, box_1_Panel_3_Data, fitness_avg_dict, iters_values, counts_Of_Events = data_To_Plot(splt_iter)
    x_limit = [45420, 45770]

    for index_fig, box_Data, fig_range in zip(subplot_Index[:3], [box_1_Panel_1_Data, box_1_Panel_2_Data, box_1_Panel_3_Data], range(3)):
        ax = plt.subplot2grid(fig_Grid_Size, ((height_Row+small_gap)*(index_fig//2)+extra_ini_gap, (height_Col+small_gap_Col)*(index_fig%2)), \
                rowspan=height_Row-1, colspan=fig_Grid_Size[1]-0)
        ax.spines.right.set_visible(False)
        ax.spines.top.set_visible(False)
        #if fig_range == 0:  ax.set_title(fig_Title[fig_range], loc='left', fontweight='bold')



        if fig_range in [0, 2]:
            # -------------------------------
            if fig_range == 0:
                p_mut4, = ax.plot([splt_iter+10, splt_iter+10], [-9, 140], color=color_r, linestyle='dashed', label='split', linewidth=lw)
            else:
                p_mut4, = ax.plot([splt_iter+10, splt_iter+10], [-70, 140], color=color_r, linestyle='dashed', label='split', linewidth=lw)

            p_num_rnase_orig, = ax.plot(list(box_Data[0].keys()), \
                                         list(box_Data[0].values()), \
                                         markerfacecolor=color_b, markeredgecolor=color_b, marker="_", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                         color=[0.5, 0.5, 0.5],
                                         label='orig. RNase')

            p_num_rnase_mut, = ax.plot(list(box_Data[1].keys()), \
                                        list(box_Data[1].values()), \
                                        markerfacecolor=color_r, markeredgecolor=color_r, marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                        color=[0.5, 0.5, 0.5],
                                        label='mut. RNase')

            p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[2].keys()), \
                                                   list(box_Data[2].values()), \
                                                   markerfacecolor=color_r, markeredgecolor=color_r, marker='o', markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                   color=[0.5, 0.5, 0.5],
                                                   label='orig. RNase + cross SLF mut.')

            p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[2].keys()), \
                                                   list(box_Data[2].values()), \
                                                   markerfacecolor=color_b, markeredgecolor=color_b, marker="_", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                   linestyle='none',
                                                   label='orig. RNase + cross SLF mut.')

            p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[4].keys()), \
                                                   list(box_Data[4].values()), \
                                                   markerfacecolor=color_r, markeredgecolor='None', alpha=alpha_Color, marker='o', color='b', markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                   label='orig. RNase + cross SLF mut.')

            p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[4].keys()), \
                                                   list(box_Data[4].values()), \
                                                   color='b', linewidth=lw,
                                                   label='orig. RNase + cross SLF mut.')

            p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[4].keys()), \
                                                   list(box_Data[4].values()), \
                                                   markerfacecolor=color_b, markeredgecolor=color_b, marker="_", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                   linestyle='-', color=color_b,
                                                   label='orig. RNase + cross SLF mut.')

            p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[3].keys()), \
                                                  list(box_Data[3].values()), \
                                                  markerfacecolor='b', markeredgecolor='None', alpha=alpha_Color, marker='o', color=[0.5, 0.5, 0.5], markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                  label='mut. RNase + cross SLF mut.')  # haplotype that has a SLF cross mutation

            p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[3].keys()), \
                                                  list(box_Data[3].values()), \
                                                  markerfacecolor=color_r, markeredgecolor=color_r, marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                  linestyle='none',
                                                  label='mut. RNase + cross SLF mut.')

            p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[5].keys()), \
                                                  list(box_Data[5].values()), \
                                                  markerfacecolor=color_b, markeredgecolor='None', alpha=alpha_Color, marker='o', color='r', markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                  label='mut. RNase + cross SLF mut.')  # haplotype that has a SLF cross mutation

            p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[5].keys()), \
                                                  list(box_Data[5].values()), \
                                                  color='r', linewidth=lw,
                                                  label='mut. RNase + cross SLF mut.')  # haplotype that has a SLF cross mutation

            p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[5].keys()), \
                                                  list(box_Data[5].values()), \
                                                  markerfacecolor=color_r, markeredgecolor=color_r, marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                  linestyle='-', color=color_r,
                                                  label='mut. RNase + cross SLF mut.')

            if fig_range == 2:
                ax.fill_between(x_limit, -60, 0, color='black', alpha=0.15, edgecolor="w")

        else:
            if output_dir == './data_fig_6_dup':
                divide_by = 1000/2
            else:
                divide_by = 1000
            # -------------------------------
            p_mut4, = ax.plot([splt_iter+10, splt_iter+10], [0.65, 0.95], color=color_r, linestyle='dashed', label='split', markeredgewidth=mW, markersize=mS, linewidth=lw)

            p_fitness_avg, = ax.plot(list(fitness_avg_dict.keys()), np.array(list(fitness_avg_dict.values())) / divide_by, \
                      color='k', linestyle='dashed', markeredgewidth=mW, markersize=mS, linewidth=lw,
                      label='avg fitness')

            print (np.array(list(fitness_avg_dict.values())), '\n', '\n')

            for index in range(1):

                p_num_rnase_orig, = ax.plot(list(box_Data[0][index].keys()), \
                                             np.array(list(box_Data[0][index].values())) / divide_by, \
                                             markerfacecolor=color_b, markeredgecolor=color_b, marker="_", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                             color=[0.5, 0.5, 0.5],
                                             label='orig. RNase')

                p_num_rnase_mut, = ax.plot(list(box_Data[1][index].keys()), \
                                            np.array(list(box_Data[1][index].values())) / divide_by, \
                                            markerfacecolor=color_r, markeredgecolor=color_r, marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                            color=[0.5, 0.5, 0.5],
                                            label='mut. RNase')

                print (list(box_Data[0][index].values()))
                print (list(box_Data[1][index].values()), '\n', '\n')

                p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[2][index].keys()), \
                                                       np.array(list(box_Data[2][index].values())) / divide_by, \
                                                       markerfacecolor='r', markeredgecolor='None', alpha=alpha_Color, marker='o', markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                       color=[0.5, 0.5, 0.5],
                                                       label='orig. RNase + cross SLF mut.')

                p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[2][index].keys()), \
                                                       np.array(list(box_Data[2][index].values())) / divide_by, \
                                                       markerfacecolor=color_b, markeredgecolor=color_b, marker="_", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                       linestyle='-', color=color_b,
                                                       label='orig. RNase + cross SLF mut.')

                p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[4][index].keys()), \
                                                       np.array(list(box_Data[4][index].values())) / divide_by, \
                                                       markerfacecolor=color_r, markeredgecolor='None', alpha=alpha_Color, marker='o', color='b', markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                       label='orig. RNase + cross SLF mut.')

                p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[4][index].keys()), \
                                                       np.array(list(box_Data[4][index].values())) / divide_by, \
                                                       color='b', linewidth=lw,
                                                       label='orig. RNase + cross SLF mut.')

                p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[4][index].keys()), \
                                                       np.array(list(box_Data[4][index].values())) / divide_by, \
                                                       markerfacecolor=color_b, markeredgecolor=color_b, marker="_", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                       linestyle='-', color=color_b,
                                                       label='orig. RNase + cross SLF mut.')

                p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[3][index].keys()), \
                                                      np.array(list(box_Data[3][index].values())) / divide_by, \
                                                      markerfacecolor='b', markeredgecolor='None', alpha=alpha_Color, marker='o', color=[0.5, 0.5, 0.5], markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                      label='mut. RNase + cross SLF mut.')  # haplotype that has a SLF cross mutation

                p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[3][index].keys()), \
                                                      np.array(list(box_Data[3][index].values())) / divide_by, \
                                                      markerfacecolor='r', markeredgecolor='r', marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                      linestyle='none',
                                                      label='mut. RNase + cross SLF mut.')

                p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[5][index].keys()), \
                                                      np.array(list(box_Data[5][index].values())) / divide_by, \
                                                      markerfacecolor=color_b, markeredgecolor='None', alpha=alpha_Color, marker='o', color='r', markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                      label='mut. RNase + cross SLF mut.')  # haplotype that has a SLF cross mutation
                p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[5][index].keys()), \
                                                      np.array(list(box_Data[5][index].values())) / divide_by, \
                                                      color='r', linewidth=lw,
                                                      label='mut. RNase + cross SLF mut.')  # haplotype that has a SLF cross mutation

                p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[5][index].keys()), \
                                                      np.array(list(box_Data[5][index].values())) / divide_by, \
                                                      markerfacecolor=color_r, markeredgecolor=color_r, marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                      linestyle='-', color=color_r,
                                                      label='mut. RNase + cross SLF mut.')



        #if fig_range == 2:
        #    ax.set_xlabel('Generation', fontsize=fontsizeX)

        if fig_range == 0:
            #ax.set_ylabel('Copy number', fontsize=fontsizeX, labelpad=11)
            ax.set_ylabel(r'$X_{i}$', fontsize=fontsizeY, labelpad=9.0)
            ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
            ax.set_xticks([], minor = False)
            ax.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
            ax.set_xticks([45450+i*10-20 for i in range(34)], minor = True)
            ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
            ax.set_yticks([0, 50, 100, 150], minor = False)
            ax.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
            ax.set_yticks(np.arange(0.0,135,25/2), minor = True)
            ax.set_ylim(-9,145)

        if fig_range == 1:
            #ax.set_ylabel('Male fitness', fontsize=fontsizeX, labelpad=12)
            ax.set_ylabel(r'$f_{i}$', fontsize=fontsizeY, labelpad=9.5)
            ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
            ax.set_xticks([], minor = False)
            ax.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
            ax.set_xticks([45450+i*10-20 for i in range(34)], minor = True)
            ax.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
            ax.set_yticks(np.arange(0.66,0.96,0.02), minor = True)
            ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
            ax.set_yticks([0.7, 0.8, 0.9], minor = False)
            ax.set_ylim(0.65,0.95)

        if fig_range == 2:
            ax.set_ylabel(r'$\tilde{X_{i}}$', fontsize=fontsizeY, labelpad=6)
            ax.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
            ax.set_xticks([45450+i*10-20 for i in range(34)], minor = True)
            ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
            ax.set_xticks([45450+i*50-20 for i in range(7)], [r'$t_{0}$'+'{}'.format(i*50) if i < 0 else r'$t_{0}$' if i == 0 else r'$t_{0}$+'+'{}'.format(i*50) for i in range(-2,5)], minor = False)
            ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
            ax.set_yticks([-50, 0, 50, 100], minor = False)
            ax.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
            ax.set_yticks(np.arange(-50,130,25/2), minor = True)
            ax.set_ylim(-60,140)

        ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax.set_xlim(x_limit)









    #lw = 0.5; mW = 1; mS = 5

    splt_iter = 69990
    box_2_Panel_1_Data, box_2_Panel_2_Data, box_2_Panel_3_Data, fitness_avg_dict, iters_values, counts_Of_Events = data_To_Plot(splt_iter)
    x_limit = [69770, 70090]

    for index_fig, box_Data, fig_range in zip(subplot_Index[6:9], [box_2_Panel_1_Data, box_2_Panel_2_Data, box_2_Panel_3_Data], range(3)):
        ax = plt.subplot2grid(fig_Grid_Size, ((height_Row+small_gap)*(index_fig//2)+big_gap+extra_ini_gap+9, (height_Col+small_gap_Col)*(index_fig%2)), \
                rowspan=height_Row-1, colspan=fig_Grid_Size[1]-0)
        ax.spines.right.set_visible(False)
        ax.spines.top.set_visible(False)
        #if fig_range == 0:  ax.set_title(fig_Title[fig_range+1], loc='left', fontweight='bold')



        if fig_range in [0, 2]:
            # -------------------------------
            if fig_range == 0:
                p_mut4, = ax.plot([splt_iter, splt_iter], [-10, 140], color=color_r, linestyle='dashed', label='split', linewidth=lw)
            else:
                p_mut4, = ax.plot([splt_iter, splt_iter], [-100, 150], color=color_r, linestyle='dashed', label='split', linewidth=lw)

            p_num_rnase_orig, = ax.plot(list(box_Data[0].keys()), \
                                         list(box_Data[0].values()), \
                                         markerfacecolor=color_b, markeredgecolor=color_b, marker="_", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                         color=[0.5, 0.5, 0.5],
                                         label='orig. RNase')

            p_num_rnase_mut, = ax.plot(list(box_Data[1].keys()), \
                                        list(box_Data[1].values()), \
                                        markerfacecolor=color_r, markeredgecolor=color_r, marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                        color=[0.5, 0.5, 0.5],
                                        label='mut. RNase')

            p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[2].keys()), \
                                                   list(box_Data[2].values()), \
                                                   markerfacecolor='r', markeredgecolor='None', alpha=alpha_Color, marker='o', markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                   color=[0.5, 0.5, 0.5],
                                                   label='orig. RNase + cross SLF mut.')

            p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[2].keys()), \
                                                   list(box_Data[2].values()), \
                                                   markerfacecolor='b', markeredgecolor='b', marker="_", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                   linestyle='none',
                                                   label='orig. RNase + cross SLF mut.')

            p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[4].keys()), \
                                                   list(box_Data[4].values()), \
                                                   markerfacecolor=color_r, markeredgecolor='None', alpha=alpha_Color, marker='o', color='b', markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                   label='orig. RNase + cross SLF mut.')

            p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[4].keys()), \
                                                   list(box_Data[4].values()), \
                                                   color='b', linewidth=lw,
                                                   label='orig. RNase + cross SLF mut.')

            p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[4].keys()), \
                                                   list(box_Data[4].values()), \
                                                   markerfacecolor=color_b, markeredgecolor=color_b, marker="_", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                   linestyle='-', color=color_b,
                                                   label='orig. RNase + cross SLF mut.')

            p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[3].keys()), \
                                                  list(box_Data[3].values()), \
                                                  markerfacecolor='b', markeredgecolor='None', alpha=alpha_Color, marker='o', color=[0.5, 0.5, 0.5], markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                  label='mut. RNase + cross SLF mut.')  # haplotype that has a SLF cross mutation

            p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[3].keys()), \
                                                  list(box_Data[3].values()), \
                                                  markerfacecolor='r', markeredgecolor='r', marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                  linestyle='none',
                                                  label='mut. RNase + cross SLF mut.')

            p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[5].keys()), \
                                                  list(box_Data[5].values()), \
                                                  markerfacecolor=color_b, markeredgecolor='None', alpha=alpha_Color, marker='o', color='r', markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                  label='mut. RNase + cross SLF mut.')  # haplotype that has a SLF cross mutation

            p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[5].keys()), \
                                                  list(box_Data[5].values()), \
                                                  color='r', linewidth=lw,
                                                  label='mut. RNase + cross SLF mut.')  # haplotype that has a SLF cross mutation

            p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[5].keys()), \
                                                  list(box_Data[5].values()), \
                                                  markerfacecolor=color_r, markeredgecolor=color_r, marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                  linestyle='-', color=color_r,
                                                  label='mut. RNase + cross SLF mut.')

            if fig_range == 2:
                ax.fill_between(x_limit, -110, 0, color='black', alpha=0.15, edgecolor="w")

        else:
            if output_dir == './data_fig_6_dup':
                divide_by = 1000/2
            else:
                divide_by = 1000
            # -------------------------------
            p_mut4, = ax.plot([splt_iter, splt_iter], [0.57, 0.95], color=color_r, linestyle='dashed', label='split', markeredgewidth=mW, markersize=mS, linewidth=lw)

            p_fitness_avg, = ax.plot(list(fitness_avg_dict.keys()), np.array(list(fitness_avg_dict.values())) / divide_by, \
                      color='k', linestyle='dashed', markeredgewidth=mW, markersize=mS, linewidth=lw,
                      label='avg fitness')

            fitness_avg_dict_to_plot = {}
            for index in range(5):

                #p_num_rnase_orig, = ax.plot(list(box_Data[0][index].keys()), \
                #                             np.array(list(box_Data[0][index].values())) / divide_by, \
                #                             markerfacecolor=color_b, markeredgecolor=color_b, marker="_", markeredgewidth=mW, markersize=mS, linewidth=lw,
                #                             color=[0.5, 0.5, 0.5],
                #                             label='orig. RNase')

                p_num_rnase_mut, = ax.plot(list(box_Data[1][index].keys()), \
                                            np.array(list(box_Data[1][index].values())) / divide_by, \
                                            markerfacecolor=color_r, markeredgecolor=color_r, marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                            color=[0.5, 0.5, 0.5],
                                            label='mut. RNase')

                p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[2][index].keys()), \
                                                       np.array(list(box_Data[2][index].values())) / divide_by, \
                                                       markerfacecolor='r', markeredgecolor='None', alpha=alpha_Color, marker='o', markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                       color=[0.5, 0.5, 0.5],
                                                       label='orig. RNase + cross SLF mut.')

                p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[2][index].keys()), \
                                                       np.array(list(box_Data[2][index].values())) / divide_by, \
                                                       markerfacecolor='b', markeredgecolor='b', marker="_", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                       linestyle='none',
                                                       label='orig. RNase + cross SLF mut.')

                p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[4][index].keys()), \
                                                       np.array(list(box_Data[4][index].values())) / divide_by, \
                                                       markerfacecolor=color_r, markeredgecolor='None', alpha=alpha_Color, marker='o', color='b', markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                       label='orig. RNase + cross SLF mut.')

                p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[4][index].keys()), \
                                                       np.array(list(box_Data[4][index].values())) / divide_by, \
                                                       color='b', linewidth=lw,
                                                       label='orig. RNase + cross SLF mut.')

                p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[4][index].keys()), \
                                                       np.array(list(box_Data[4][index].values())) / divide_by, \
                                                       markerfacecolor=color_b, markeredgecolor=color_b, marker="_", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                       linestyle='-', color=color_b,
                                                       label='orig. RNase + cross SLF mut.')

                p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[3][index].keys()), \
                                                      np.array(list(box_Data[3][index].values())) / divide_by, \
                                                      markerfacecolor='b', markeredgecolor='None', alpha=alpha_Color, marker='o', color=[0.5, 0.5, 0.5], markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                      label='mut. RNase + cross SLF mut.')  # haplotype that has a SLF cross mutation

                p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[3][index].keys()), \
                                                      np.array(list(box_Data[3][index].values())) / divide_by, \
                                                      markerfacecolor='r', markeredgecolor='r', marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                      linestyle='none',
                                                      label='mut. RNase + cross SLF mut.')

                p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[5][index].keys()), \
                                                      np.array(list(box_Data[5][index].values())) / divide_by, \
                                                      markerfacecolor=color_b, markeredgecolor='None', alpha=alpha_Color, marker='o', color='r', markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                      label='mut. RNase + cross SLF mut.')  # haplotype that has a SLF cross mutation

                p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[5][index].keys()), \
                                                      np.array(list(box_Data[5][index].values())) / divide_by, \
                                                      color='r', linewidth=lw,
                                                      label='mut. RNase + cross SLF mut.')  # haplotype that has a SLF cross mutation

                p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[5][index].keys()), \
                                                      np.array(list(box_Data[5][index].values())) / divide_by, \
                                                      markerfacecolor=color_r, markeredgecolor=color_r, marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                      linestyle='-', color=color_r,
                                                      label='mut. RNase + cross SLF mut.')

                for gen_key, gen_value in zip(list(box_Data[0][index].keys()), np.array(list(box_Data[0][index].values()))/divide_by):

                    if gen_key not in fitness_avg_dict_to_plot:
                            fitness_avg_dict_to_plot[gen_key] = [gen_value]
                    else:
                        fitness_avg_dict_to_plot[gen_key].append(gen_value)


            for key, value in zip(list(fitness_avg_dict_to_plot.keys()), list(fitness_avg_dict_to_plot.values())):
                fitness_avg_dict_to_plot[key] = np.nanmean(value)

            p_num_rnase_orig, = ax.plot(list(fitness_avg_dict_to_plot.keys()), \
                                         np.array(list(fitness_avg_dict_to_plot.values())), \
                                         markerfacecolor=color_b, markeredgecolor=color_b, marker="_", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                         color=[0.5, 0.5, 0.5],
                                         label='orig. RNase')


        #if fig_range == 2:
        #    ax.set_xlabel('Generation', fontsize=fontsizeX)

        if fig_range == 0:
            #ax.set_ylabel('Copy number', fontsize=fontsizeX, labelpad=11)
            ax.set_ylabel(r'$X_{i}$', fontsize=fontsizeY, labelpad=9.0)
            ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
            ax.set_xticks([], minor = False)
            ax.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
            ax.set_xticks([69800+i*10-20 for i in range(31)], minor = True)
            ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
            ax.set_yticks([0, 50, 100, 150], minor = False)
            ax.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
            ax.set_yticks(np.arange(0,150,25/2), minor = True)
            ax.set_ylim(-9,160)

        if fig_range == 1:
            #ax.set_ylabel('Male fitness', fontsize=fontsizeX, labelpad=12)
            ax.set_ylabel(r'$f_{i}$', fontsize=fontsizeY, labelpad=9.5)
            ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
            ax.set_xticks([], minor = False)
            ax.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
            ax.set_xticks([69800+i*10-20 for i in range(31)], minor = True)
            ax.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
            ax.set_yticks(np.arange(0.58,0.95,0.02), minor = True)
            ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
            ax.set_yticks([0.6, 0.7, 0.8, 0.9, 1.0], minor = False)
            ax.set_ylim(0.57,0.95)


        if fig_range == 2:
            #ax.set_ylabel('Fitness adjusted\ncopy number', fontsize=fontsizeX, labelpad=0)
            ax.set_ylabel(r'$\tilde{X_{i}}$', fontsize=fontsizeY, labelpad=1)
            ax.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
            ax.set_xticks([69800+i*10-20 for i in range(30)], minor = True)
            ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
            #ax.set_xticks([69800, 69850, 69900, 69950, 70000, 70050], ['t+{}'.format(i*50) if i > 0 else 't' for i in range(6)], minor = False)
            ax.set_xticks([69800+i*50-20 for i in range(7)], [r'$t_{0}$'+'{}'.format(i*50) if i < 0 else r'$t_{0}$' if i == 0 else r'$t_{0}$+'+'{}'.format(i*50) for i in range(-2,5)], minor = False)
            ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
            ax.set_yticks([-100,0, 100], minor = False)
            ax.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
            ax.set_yticks(np.arange(-100,150,25), minor = True)
            ax.set_ylim(-100,155)

        ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax.set_xlim(x_limit)














    splt_iter = 98870#519800, 2, 4, 1, 3, 5, 6, 8, 10, 7, 9, 11
    box_3_Panel_1_Data, box_3_Panel_2_Data, box_3_Panel_3_Data, fitness_avg_dict, iters_values, counts_Of_Events = data_To_Plot(splt_iter)
    x_limit = [98610, 98970] #[51800, 52070]
    subplot_Index = [12, 14, 16]
    for index_fig, box_Data, fig_range in zip(subplot_Index, [box_3_Panel_1_Data, box_3_Panel_2_Data, box_3_Panel_3_Data], range(3)):
        ax = plt.subplot2grid(fig_Grid_Size, ((height_Row+small_gap)*(index_fig//2)+big_gap+extra_ini_gap+26, 0), \
                rowspan=height_Row-1, colspan=fig_Grid_Size[1]-0)
        ax.spines.right.set_visible(False)
        ax.spines.top.set_visible(False)
        #if fig_range == 0:  ax.set_title(fig_Title[fig_range+2], loc='left', fontweight='bold')



        if fig_range in [0, 2]:
            # -------------------------------
            if fig_range == 0:
                p_mut4, = ax.plot([splt_iter, splt_iter], [-10, 160], color=color_r, linestyle='dashed', label='split', linewidth=lw)
            else:
                p_mut4, = ax.plot([splt_iter, splt_iter], [-150, 225], color=color_r, linestyle='dashed', label='split', linewidth=lw)

            p_num_rnase_orig, = ax.plot(list(box_Data[0].keys()), \
                                         list(box_Data[0].values()), \
                                         markerfacecolor=color_b, markeredgecolor=color_b, marker="_", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                         color=[0.5, 0.5, 0.5],
                                         label='orig. RNase')

            p_num_rnase_mut, = ax.plot(list(box_Data[1].keys()), \
                                        list(box_Data[1].values()), \
                                        markerfacecolor=color_r, markeredgecolor=color_r, marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                        color=[0.5, 0.5, 0.5],
                                        label='mut. RNase')

            p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[2].keys()), \
                                                   list(box_Data[2].values()), \
                                                   markerfacecolor='r', markeredgecolor='None', alpha=alpha_Color, marker='o', markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                   color=[0.5, 0.5, 0.5],
                                                   label='orig. RNase + cross SLF mut.')

            p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[2].keys()), \
                                                   list(box_Data[2].values()), \
                                                   markerfacecolor='b', markeredgecolor='b', marker="_", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                   linestyle='none',
                                                   label='orig. RNase + cross SLF mut.')

            p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[4].keys()), \
                                                   list(box_Data[4].values()), \
                                                   markerfacecolor=color_r, markeredgecolor='None', alpha=alpha_Color, marker='o', color='b', markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                   label='orig. RNase + cross SLF mut.')

            p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[4].keys()), \
                                                   list(box_Data[4].values()), \
                                                   color='b', linewidth=lw,
                                                   label='orig. RNase + cross SLF mut.')

            p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[4].keys()), \
                                                   list(box_Data[4].values()), \
                                                   markerfacecolor=color_b, markeredgecolor=color_b, marker="_", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                   linestyle='-', color=color_b,
                                                   label='orig. RNase + cross SLF mut.')
            '''
            p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[3].keys()), \
                                                  list(box_Data[3].values()), \
                                                  markerfacecolor='b', markeredgecolor='None', alpha=alpha_Color, marker='o', color=[0.5, 0.5, 0.5], markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                  label='mut. RNase + cross SLF mut.')  # haplotype that has a SLF cross mutation

            p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[3].keys()), \
                                                  list(box_Data[3].values()), \
                                                  markerfacecolor='r', markeredgecolor='r', marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                  linestyle='none',
                                                  label='mut. RNase + cross SLF mut.')
            '''
            p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[5].keys()), \
                                                  list(box_Data[5].values()), \
                                                  markerfacecolor=color_b, markeredgecolor='None', alpha=alpha_Color, marker='o', color='r', markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                  label='mut. RNase + cross SLF mut.')  # haplotype that has a SLF cross mutation

            p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[5].keys()), \
                                                  list(box_Data[5].values()), \
                                                  color='r', linewidth=lw,
                                                  label='mut. RNase + cross SLF mut.')  # haplotype that has a SLF cross mutation

            p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[5].keys()), \
                                                  list(box_Data[5].values()), \
                                                  markerfacecolor=color_r, markeredgecolor=color_r, marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                  linestyle='-', color=color_r,
                                                  label='mut. RNase + cross SLF mut.')

            if fig_range == 2:
                ax.fill_between(x_limit, -155, 0, color='black', alpha=0.15, edgecolor="w")

        else:
            if output_dir == './data_fig_6_dup':
                divide_by = 1000/2
            else:
                divide_by = 1000
            # -------------------------------
            p_mut4, = ax.plot([splt_iter, splt_iter], [0.5, 0.95], color=color_r, linestyle='dashed', label='split', markeredgewidth=mW, markersize=mS, linewidth=lw)

            p_fitness_avg, = ax.plot(list(fitness_avg_dict.keys()), np.array(list(fitness_avg_dict.values())) / divide_by, \
                      color='k', linestyle='dashed', markeredgewidth=mW, markersize=mS, linewidth=lw,
                      label='avg fitness')

            for index in range(5):

                p_num_rnase_orig, = ax.plot(list(box_Data[0][index].keys()), \
                                             np.array(list(box_Data[0][index].values())) / divide_by, \
                                             markerfacecolor=color_b, markeredgecolor=color_b, marker="_", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                             color=[0.5, 0.5, 0.5],
                                             label='orig. RNase')
                #print (list(box_Data[1][index].keys()), np.array(list(box_Data[1][index].values())) / divide_by, '----')
                p_num_rnase_mut, = ax.plot(list(box_Data[1][index].keys()), \
                                            np.array(list(box_Data[1][index].values())) / divide_by, \
                                            markerfacecolor=color_r, markeredgecolor=color_r, marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                            color=[0.5, 0.5, 0.5],
                                            label='mut. RNase')

                p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[2][index].keys()), \
                                                       np.array(list(box_Data[2][index].values())) / divide_by, \
                                                       markerfacecolor='r', markeredgecolor='None', alpha=alpha_Color, marker='o', markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                       color=[0.5, 0.5, 0.5],
                                                       label='orig. RNase + cross SLF mut.')

                p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[2][index].keys()), \
                                                       np.array(list(box_Data[2][index].values())) / divide_by, \
                                                       markerfacecolor='b', markeredgecolor='b', marker="_", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                       linestyle='none',
                                                       label='orig. RNase + cross SLF mut.')

                p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[4][index].keys()), \
                                                       np.array(list(box_Data[4][index].values())) / divide_by, \
                                                       markerfacecolor='r', markeredgecolor='None', alpha=alpha_Color, marker='o', color='b', markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                       label='orig. RNase + cross SLF mut.')

                p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[4][index].keys()), \
                                                       np.array(list(box_Data[4][index].values())) / divide_by, \
                                                       color=color_r, linewidth=lw,
                                                       label='orig. RNase + cross SLF mut.')

                p_num_rnase_orig_slf_cross, = ax.plot(list(box_Data[4][index].keys()), \
                                                       np.array(list(box_Data[4][index].values())) / divide_by, \
                                                       markerfacecolor=color_b, markeredgecolor=color_b, marker="_", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                       linestyle='-', color=color_b,
                                                       label='orig. RNase + cross SLF mut.')

                p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[3][index].keys()), \
                                                      np.array(list(box_Data[3][index].values())) / divide_by, \
                                                      markerfacecolor='b', markeredgecolor='None', alpha=alpha_Color, marker='o', color=[0.5, 0.5, 0.5], markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                      label='mut. RNase + cross SLF mut.')  # haplotype that has a SLF cross mutation

                p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[3][index].keys()), \
                                                      np.array(list(box_Data[3][index].values())) / divide_by, \
                                                      markerfacecolor='r', markeredgecolor='r', marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                      linestyle='none',
                                                      label='mut. RNase + cross SLF mut.')

                p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[5][index].keys()), \
                                                      np.array(list(box_Data[5][index].values())) / divide_by, \
                                                      markerfacecolor=color_b, markeredgecolor='None', alpha=alpha_Color, marker='o', color='r', markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                      label='mut. RNase + cross SLF mut.')  # haplotype that has a SLF cross mutation

                p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[5][index].keys()), \
                                                      np.array(list(box_Data[5][index].values())) / divide_by, \
                                                      color='r', linewidth=lw,
                                                      label='mut. RNase + cross SLF mut.')  # haplotype that has a SLF cross mutation

                p_num_rnase_mut_slf_cross, = ax.plot(list(box_Data[5][index].keys()), \
                                                      np.array(list(box_Data[5][index].values())) / divide_by, \
                                                      markerfacecolor=color_r, markeredgecolor=color_r, marker="|", markeredgewidth=mW, markersize=mS, linewidth=lw,
                                                      linestyle='-', color=color_r,
                                                      label='mut. RNase + cross SLF mut.')



        if fig_range == 2:
            ax.set_xlabel('Generation', fontsize=fontsizeX)

        if fig_range == 0:
            #ax.set_ylabel('Copy number', fontsize=fontsizeX, labelpad=11)
            ax.set_ylabel(r'$X_{i}$', fontsize=fontsizeY, labelpad=9)
            ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
            ax.set_xticks([], minor = False)
            ax.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
            ax.set_xticks([98620+i*10 for i in range(35)], minor = True)
            ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
            ax.set_yticks([0, 50, 100, 150], minor = False)
            ax.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
            ax.set_yticks(np.arange(0,200,25/2), minor = True)
            ax.set_ylim(-10,200)

        if fig_range == 1:
            #ax.set_ylabel('Male fitness', fontsize=fontsizeX, labelpad=12)
            ax.set_ylabel(r'$f_{i}$', fontsize=fontsizeY, labelpad=9.5)
            ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
            ax.set_xticks([], minor = False)
            ax.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
            ax.set_xticks([98620+i*10 for i in range(35)], minor = True)
            ax.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
            ax.set_yticks(np.arange(0.46,0.95,0.02), minor = True)
            ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
            ax.set_yticks([0.6, 0.7, 0.9, 0.8], minor = False)
            ax.set_ylim(0.50,0.95)

        if fig_range == 2:
            #ax.set_ylabel('Fitness adjusted\ncopy number', fontsize=fontsizeX, labelpad=0)
            ax.set_ylabel(r'$\tilde{X_{i}}$', fontsize=fontsizeY, labelpad=1)
            ax.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
            ax.set_xticks([98620+i*10 for i in range(35)], minor = True)
            ax.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
            ax.set_xticks([98640+i*50-20 for i in range(7)], [r'$t_{0}$'+'{}'.format(i*50) if i < 0 else r'$t_{0}$' if i == 0 else r'$t_{0}$+'+'{}'.format(i*50) for i in range(-2,5)], minor = False)
            ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
            ax.set_yticks([-100, 0, 100, 200], minor = False)
            ax.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
            ax.set_yticks(np.arange(-160,200,20), minor = True)
            ax.set_ylim(-155,225)

        ax.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax.set_xlim(x_limit)







    plt.savefig('./figures/Fig_6_diploid_based_average.pdf', transparent=True)
    #plt.show()


    return 'done'

input_Var = 0
print (fert_Mut_Class(input_Var))



print ('Ends|----|H:M:S|{}'.format(datetime.now() - start_time), '\n')
###############################################################################################################
###############################################################################################################
