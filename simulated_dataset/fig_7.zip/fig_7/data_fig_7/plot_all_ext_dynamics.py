import pickle
import os
import numpy as np
import matplotlib as mpl
from matplotlib import pyplot as plt
from matplotlib.patches import Rectangle

figure_facecolour = 'w'
figure_edgecolour = 'k'
# overall font size, and other overall parameters
font_size = 10
width_global = 0.7

# now we want to define font properties:

font_dict_axis = {'fontsize': font_size, 'fontweight': 300}

# let us difine legend properties

legend_facecolour = 'w'
legend_edgecolour = '0'

# legend_prop = {'size': font_size}  # sets legend's size (obviously)
# text_prop = {'size': font_size}


# This is a sort of a config file for figures in python

params = {

    'text.usetex': False,

    'axes.spines.bottom': True,

    'axes.spines.left': True,

    'axes.spines.right': False,

    'axes.spines.top': False,

    'legend.fontsize': 7,

    'figure.figsize': [7, 4]  # instead of 4.5, 4.5

}
mpl.rc('font', family='arial')
plt.rcParams.update(params)
plt.rcParams['axes.linewidth'] = width_global
plt.rcParams["savefig.format"] = 'png'
plt.rcParams['figure.constrained_layout.use'] = False

figure_dpi = 500
#os.chdir("..")
#if os.getcwd() == 'D:\\':
#    os.chdir("gdrive")
#if os.getcwd() == 'D:\\gdrive':
#    os.chdir("FlowersEvolutionsSimulation_ver13_data")

#directory = "output_data_10haplotypes_k5_18AAs_E_thresh-6_p10-4"

min_duration = 10
d_iters = 10

#subdirectories = set(next(os.walk(directory))[1]) - set(['2022-11-12-15-57-44-13'])
subdirectories = ['2022-11-12-15-57-44-13'] #['2022-11-12-15-57-44-32']
for ii_dir in range(1):
    #print(os.path.join(subdirectory))
    iter_ext_ind = 62690 #80590, 33700, 62690
    if iter_ext_ind in [80590]:
        output_dir = './neutral' + "/" + '2022-11-12-15-57-44-13'
    if iter_ext_ind in [33700]:
        output_dir = './non_comp_rnase-cross_mut' + "/" + '2022-11-12-15-57-44-32'
    if iter_ext_ind in [62690]:
        output_dir = './splt_and_ext' + "/" + '2022-11-12-15-57-44-13'
    #output_dir = 'D:/gdrive/FlowersEvolutionsSimulation_ver13_data/ext_dynamics_figures/splt_and_ext/2022-11-12-15-57-44-13'
    if os.path.isfile(output_dir + '/analyze_extinct_group_all_iters_' + str(min_duration * 10) + '_dict.pkl'):
        with open(output_dir + '/analyze_extinct_group_all_iters_' + str(min_duration * 10) + '_dict.pkl', 'rb') as input:
            analyze_extinct_group_all_iters_dict = pickle.load(input)

        #for iter_ext_ind in [80590]:#analyze_extinct_group_all_iters_dict.keys():#[74280] :#[80590]:#
        # iter_ext_ind = 107880
        if 'ext_type' in analyze_extinct_group_all_iters_dict[iter_ext_ind][0]:

            #Extinction – cross in SLFmut

            mut_RNase = analyze_extinct_group_all_iters_dict[iter_ext_ind][0]['mut RNase']
            extinct_group = analyze_extinct_group_all_iters_dict[iter_ext_ind][0]['extinct_group']
            mut_iter = analyze_extinct_group_all_iters_dict[iter_ext_ind][0]['mut iter']

            with open(output_dir + '/tot_fitness_hap_orig_rnase_' + str(
                    iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
                extinct_group) + '_' + str(
                min_duration * 10) + '_.pkl', 'rb') as input:
                tot_fitness_hap_orig_rnase = pickle.load(input)

            with open(output_dir + '/tot_fitness_hap_mut_rnase_' + str(
                    iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
                extinct_group) + '_' + str(
                min_duration * 10) + '_.pkl', 'rb') as input:
                tot_fitness_hap_mut_rnase = pickle.load(input)

            with open(output_dir + '/tot_fitness_hap_cross_orig_rnase_' + str(
                    iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
                extinct_group) + '_' + str(
                min_duration * 10) + '_.pkl', 'rb') as input:
                tot_fitness_hap_cross_orig_rnase = pickle.load(input)

            with open(output_dir + '/tot_fitness_hap_cross_mut_rnase_' + str(
                    iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
                extinct_group) + '_' + str(
                min_duration * 10) + '_.pkl', 'rb') as input:
                tot_fitness_hap_cross_mut_rnase = pickle.load(input)

            with open(output_dir + '/tot_num_hap_orig_rnase_' + str(
                    iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
                extinct_group) + '_' + str(
                min_duration * 10) + '_.pkl', 'rb') as input:
                tot_num_hap_orig_rnase = pickle.load(input)

            with open(output_dir + '/tot_num_hap_mut_rnase_' + str(
                    iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
                extinct_group) + '_' + str(
                min_duration * 10) + '_.pkl', 'rb') as input:
                tot_num_hap_mut_rnase = pickle.load(input)

            with open(output_dir + '/tot_num_hap_cross_orig_rnase_' + str(
                    iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
                extinct_group) + '_' + str(
                min_duration * 10) + '_.pkl', 'rb') as input:
                tot_num_hap_cross_orig_rnase = pickle.load(input)

            with open(output_dir + '/tot_num_hap_cross_mut_rnase_' + str(
                    iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
                extinct_group) + '_' + str(
                min_duration * 10) + '_.pkl', 'rb') as input:
                tot_num_hap_cross_mut_rnase = pickle.load(input)

            sum_tot_num_hap_orig_rnase = {}
            sum_tot_num_hap_mut_rnase = {}
            sum_tot_num_hap_cross_orig_rnase = {}
            sum_tot_num_hap_cross_mut_rnase = {}

            for i, num_hap_orig_rnase_dict in tot_num_hap_orig_rnase.items():
                for iter_ind, num in num_hap_orig_rnase_dict.items():
                    if not np.isnan(num):
                        if iter_ind not in sum_tot_num_hap_orig_rnase:
                            sum_tot_num_hap_orig_rnase[iter_ind] = 0
                        sum_tot_num_hap_orig_rnase[iter_ind] += num

            for i, num_hap_mut_rnase_dict in tot_num_hap_mut_rnase.items():
                for iter_ind, num in num_hap_mut_rnase_dict.items():
                    if not np.isnan(num):
                        if iter_ind not in sum_tot_num_hap_mut_rnase:
                            sum_tot_num_hap_mut_rnase[iter_ind] = 0
                        sum_tot_num_hap_mut_rnase[iter_ind] += num

            for i, num_hap_cross_orig_rnase in tot_num_hap_cross_orig_rnase.items():
                for iter_ind, num in num_hap_cross_orig_rnase.items():
                    if not np.isnan(num):
                        if iter_ind not in sum_tot_num_hap_cross_orig_rnase:
                            sum_tot_num_hap_cross_orig_rnase[iter_ind] = 0
                        sum_tot_num_hap_cross_orig_rnase[iter_ind] += num

            for i, num_hap_cross_mut_rnase in tot_num_hap_cross_mut_rnase.items():
                for iter_ind, num in num_hap_cross_mut_rnase.items():
                    if not np.isnan(num):
                        if iter_ind not in sum_tot_num_hap_cross_mut_rnase:
                            sum_tot_num_hap_cross_mut_rnase[iter_ind] = 0
                        sum_tot_num_hap_cross_mut_rnase[iter_ind] += num

            with open(output_dir + '/expected_num_change_orig_rnase_dict_' + str(
                    iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
                extinct_group) + '_' + str(
                min_duration * 10) + '_.pkl', 'rb') as input:
                expected_num_change_orig_rnase_dict = pickle.load(input)

            with open(output_dir + '/expected_num_change_mut_rnase_dict_' + str(
                    iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
                extinct_group) + '_' + str(
                min_duration * 10) + '_.pkl', 'rb') as input:
                expected_num_change_mut_rnase_dict = pickle.load(input)

            with open(output_dir + '/expected_num_change_cross_SLF_in_mut_dict_' + str(
                    iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
                extinct_group) + '_' + str(
                min_duration * 10) + '_.pkl', 'rb') as input:
                expected_num_change_cross_SLF_in_mut_dict = pickle.load(input)

            with open(output_dir + '/expected_num_change_cross_SLF_in_orig_dict_' + str(
                    iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
                extinct_group) + '_' + str(
                min_duration * 10) + '_.pkl', 'rb') as input:
                expected_num_change_cross_SLF_in_orig_dict = pickle.load(input)

            sum_expected_num_change_orig_rnase_dict = {}
            sum_expected_num_change_mut_rnase_dict = {}
            sum_expected_num_change_cross_SLF_in_orig_dict = {}
            sum_expected_num_change_cross_SLF_in_mut_dict = {}

            for i, expected_dict in expected_num_change_orig_rnase_dict.items():
                for iter_ind, num in expected_dict.items():
                    if not np.isnan(num):
                        if iter_ind not in sum_expected_num_change_orig_rnase_dict:
                            sum_expected_num_change_orig_rnase_dict[iter_ind] = 0
                        sum_expected_num_change_orig_rnase_dict[iter_ind] += num

            for i, expected_dict in expected_num_change_mut_rnase_dict.items():
                for iter_ind, num in expected_dict.items():
                    if not np.isnan(num):
                        if iter_ind not in sum_expected_num_change_mut_rnase_dict:
                            sum_expected_num_change_mut_rnase_dict[iter_ind] = 0
                        sum_expected_num_change_mut_rnase_dict[iter_ind] += num

            for i, expected_dict in expected_num_change_cross_SLF_in_orig_dict.items():
                for iter_ind, num in expected_dict.items():
                    if not np.isnan(num):
                        if iter_ind not in sum_expected_num_change_cross_SLF_in_orig_dict:
                            sum_expected_num_change_cross_SLF_in_orig_dict[iter_ind] = 0
                        sum_expected_num_change_cross_SLF_in_orig_dict[iter_ind] += num

            for i, expected_dict in expected_num_change_cross_SLF_in_mut_dict.items():
                for iter_ind, num in expected_dict.items():
                    if not np.isnan(num):
                        if iter_ind not in sum_expected_num_change_cross_SLF_in_mut_dict:
                            sum_expected_num_change_cross_SLF_in_mut_dict[iter_ind] = 0
                        sum_expected_num_change_cross_SLF_in_mut_dict[iter_ind] += num

            with open(output_dir + '/ext_group_count_arr_ext_iter_' + str(
                    iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
                extinct_group) + '_' + str(
                min_duration * 10) + '_.pkl', 'rb') as input:
                ext_group_count_arr = pickle.load(input)

            with open(output_dir + '/ext_append_group_count_arr_ext_iter_' + str(
                    iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
                extinct_group) + '_' + str(
                min_duration * 10) + '_.pkl', 'rb') as input:
                ext_append_group_count_arr = pickle.load(input)

            with open(output_dir + '/iters_values_ext_iter_' + str(
                    iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
                extinct_group) + '_' + str(
                min_duration * 10) + '_.pkl', 'rb') as input:
                iters_values = pickle.load(input)


            with open(output_dir + '/fitness_avg_dict_' + str(
                    iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(
                        mut_iter) + '_ext_gro_' + str(
                    extinct_group) + '_' + str(
                    min_duration * 10) + '_.pkl', 'rb') as input:
                fitness_avg_dict = pickle.load(input)

            with open(output_dir + '/tot_fitness_hap_orig_rnase_' + str(
                    iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(
                        mut_iter) + '_ext_gro_' + str(
                    extinct_group) + '_' + str(
                    min_duration * 10) + '_.pkl', 'rb') as input:
                tot_fitness_hap_orig_rnase = pickle.load(input)

            with open(output_dir + '/tot_fitness_hap_mut_rnase_' + str(
                    iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(
                        mut_iter) + '_ext_gro_' + str(
                    extinct_group) + '_' + str(
                    min_duration * 10) + '_.pkl', 'rb') as input:
                tot_fitness_hap_mut_rnase = pickle.load(input)

            with open(output_dir + '/tot_fitness_hap_ext_gro_' + str(
                    iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(
                        mut_iter) + '_ext_gro_' + str(
                    extinct_group) + '_' + str(
                    min_duration * 10) + '_.pkl', 'rb') as input:
                tot_fitness_hap_ext_gro = pickle.load(input)

            with open(output_dir + '/tot_num_hap_ext_gro_' + str(
                    iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(
                        mut_iter) + '_ext_gro_' + str(
                    extinct_group) + '_' + str(
                    min_duration * 10) + '_.pkl', 'rb') as input:
                tot_num_hap_ext_gro = pickle.load(input)

            sum_tot_num_hap_ext_gro = {}
            for i, num_hap_ext_gro in tot_num_hap_ext_gro.items():
                for iter_ind, num in num_hap_ext_gro.items():
                    if not np.isnan(num):
                        if iter_ind not in sum_tot_num_hap_ext_gro:
                            sum_tot_num_hap_ext_gro[iter_ind] = 0
                        sum_tot_num_hap_ext_gro[iter_ind] += num

            with open(output_dir + '/expected_num_change_mut_rnase_dict_' + str(
                    iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
                extinct_group) + '_' + str(
                min_duration * 10) + '_.pkl', 'rb') as input:
                expected_num_change_mut_rnase_dict = pickle.load(input)

            with open(output_dir + '/expected_num_change_ext_gro_dict_' + str(
                    iter_ext_ind) + '_RNase_mutant_' + str(mut_RNase) + '_mut_iter_' + str(mut_iter) + '_ext_gro_' + str(
                extinct_group) + '_' + str(
                min_duration * 10) + '_.pkl', 'rb') as input:
                expected_num_change_ext_gro_dict = pickle.load(input)

            sum_expected_num_change_mut_rnase_dict = {}
            for i, expected_dict in expected_num_change_mut_rnase_dict.items():
                for iter_ind, num in expected_dict.items():
                    if not np.isnan(num):
                        if iter_ind not in sum_expected_num_change_mut_rnase_dict:
                            sum_expected_num_change_mut_rnase_dict[iter_ind] = 0
                        sum_expected_num_change_mut_rnase_dict[iter_ind] += num

            sum_expected_num_change_ext_gro_dict = {}
            for i, expected_dict in expected_num_change_ext_gro_dict.items():
                for iter_ind, num in expected_dict.items():
                    if not np.isnan(num):
                        if iter_ind not in sum_expected_num_change_ext_gro_dict:
                            sum_expected_num_change_ext_gro_dict[iter_ind] = 0
                        sum_expected_num_change_ext_gro_dict[iter_ind] += num

            sum_expected_num_change_cross_SLF_in_orig_dict = {}
            for i, expected_dict in expected_num_change_cross_SLF_in_orig_dict.items():
                if len(list(expected_dict.values())) > 3:
                    for iter_ind, num in expected_dict.items():
                        if not np.isnan(num):
                            if iter_ind not in sum_expected_num_change_cross_SLF_in_orig_dict:
                                sum_expected_num_change_cross_SLF_in_orig_dict[iter_ind] = 0
                            sum_expected_num_change_cross_SLF_in_orig_dict[iter_ind] += num

            fig_size = (8, 12)
            fig = plt.figure(1, dpi=figure_dpi, facecolor=figure_facecolour, edgecolor=figure_edgecolour,
                             figsize=fig_size)  # no frame
            fig.subplots_adjust(left=0.2, right=0.97, top=0.92, bottom=0.22, hspace=0.02, wspace=0.02)

            ax1 = fig.add_subplot(311)
            ax2 = fig.add_subplot(312)
            ax3 = fig.add_subplot(313)

            # ---------------------------------------------------------------
            # subplot1 - orig RNase, mut RNase, orig group, extincted group
            # ---------------------------------------------------------------

            line1, = ax1.plot(iters_values, ext_group_count_arr + ext_append_group_count_arr,
                              color="0.5", marker='o', label='extinct group (+ appendix)')

            p_num_rnase_orig, = ax1.plot(list(sum_tot_num_hap_orig_rnase.keys()), \
                                         list(sum_tot_num_hap_orig_rnase.values()), \
                                         markerfacecolor='b', markeredgecolor='b', marker="_", markeredgewidth=2,
                                         color=[0.5, 0.5, 0.5],
                                         label='orig. RNase')

            p_num_rnase_mut, = ax1.plot(list(sum_tot_num_hap_mut_rnase.keys()), \
                                        list(sum_tot_num_hap_mut_rnase.values()), \
                                        markerfacecolor='r', markeredgecolor='r', marker="|", markeredgewidth=2,
                                        color=[0.5, 0.5, 0.5],
                                        label='mut. RNase')

            p_num_rnase_orig_slf_cross, = ax1.plot(list(sum_tot_num_hap_cross_orig_rnase.keys()), \
                                                   list(sum_tot_num_hap_cross_orig_rnase.values()), \
                                                   markerfacecolor='r', markeredgecolor='r', marker='o', ms=8, color='b',
                                                   label='orig. RNase + cross SLF mut.')

            p_num_rnase_orig_slf_cross, = ax1.plot(list(sum_tot_num_hap_cross_orig_rnase.keys()), \
                                                   list(sum_tot_num_hap_cross_orig_rnase.values()), \
                                                   markerfacecolor='b', markeredgecolor='b', marker="_", markeredgewidth=2,
                                                   linestyle='none',
                                                   label='orig. RNase + cross SLF mut.')

            p_num_rnase_mut_slf_cross, = ax1.plot(list(sum_tot_num_hap_cross_mut_rnase.keys()), \
                                                  list(sum_tot_num_hap_cross_mut_rnase.values()), \
                                                  markerfacecolor='b', markeredgecolor='b', marker='o', ms=8, color='r',
                                                  label='mut. RNase + cross SLF mut.')  # haplotype that has a SLF cross mutation
            p_num_rnase_mut_slf_cross, = ax1.plot(list(sum_tot_num_hap_cross_mut_rnase.keys()), \
                                                  list(sum_tot_num_hap_cross_mut_rnase.values()), \
                                                  markerfacecolor='r', markeredgecolor='r', marker="|", markeredgewidth=2,
                                                  linestyle='none',
                                                  label='mut. RNase + cross SLF mut.')

            ax1.grid(which='both', axis='both', color="0.8", linestyle='--')
            ax1.set_xlabel('generation', fontdict=font_dict_axis)  # , fontweight=300)
            # ax1.set_xticklabels([])
            ax1.set_ylabel('size', fontdict=font_dict_axis)  # , fontweight=300)
            # ax1.set_yticklabels([])
            # ax1.set_xticklabels([])
            ax1.set_title('a', loc='left', fontweight="bold")

            p_fitness_avg, = ax2.plot(list(fitness_avg_dict.keys()), np.array(list(fitness_avg_dict.values())) / 1000, \
                                      color='k', linestyle='dashed',
                                      label='avg fitness')

            for i in range(15):
                if len(list(tot_fitness_hap_ext_gro[i].keys())) > 3:
                    p_num_rnase_orig, = ax2.plot(list(tot_fitness_hap_ext_gro[i].keys()), \
                                                 np.array(list(tot_fitness_hap_ext_gro[i].values())) / 1000, \
                                                 color=[0.5, 0.5, 0.5], marker='o', label='ext gro')

            for i in range(15):
                if len(list(tot_fitness_hap_orig_rnase[i].keys())) > 3:
                    p_num_rnase_orig, = ax2.plot(list(tot_fitness_hap_orig_rnase[i].keys()), \
                                                 np.array(list(tot_fitness_hap_orig_rnase[i].values())) / 1000, \
                                                 markerfacecolor='b', markeredgecolor='b', marker="_", markeredgewidth=2,
                                                 color=[0.5, 0.5, 0.5],
                                                 label='orig. RNase')

            for i in range(15):
                if len(list(tot_fitness_hap_mut_rnase[i].keys())) > 3:
                    p_num_rnase_mut, = ax2.plot(list(tot_fitness_hap_mut_rnase[i].keys()), \
                                                np.array(list(tot_fitness_hap_mut_rnase[i].values())) / 1000, \
                                                markerfacecolor='r', markeredgecolor='r', marker="|", markeredgewidth=2,
                                                color=[0.5, 0.5, 0.5],
                                                label='mut. RNase')

            for i in range(15):
                if len(list(tot_fitness_hap_cross_orig_rnase[i].keys())) > 3:
                    p_num_rnase_orig_slf_cross, = ax2.plot(list(tot_fitness_hap_cross_orig_rnase[i].keys()), \
                                                           np.array(list(tot_fitness_hap_cross_orig_rnase[i].values())) / 1000, \
                                                           markerfacecolor='r', markeredgecolor='r', marker='o', ms=8, color='b',
                                                           label='orig. RNase + cross SLF mut.')

                    p_num_rnase_orig_slf_cross, = ax2.plot(list(tot_fitness_hap_cross_orig_rnase[i].keys()), \
                                                           np.array(list(tot_fitness_hap_cross_orig_rnase[i].values())) / 1000, \
                                                           markerfacecolor='b', markeredgecolor='b', marker="_", markeredgewidth=2,
                                                           linestyle='none',
                                                           label='orig. RNase + cross SLF mut.')

            for i in range(15):
                if len(list(tot_fitness_hap_cross_mut_rnase[i].keys())) > 3:
                    p_num_rnase_mut_slf_cross, = ax2.plot(list(tot_fitness_hap_cross_mut_rnase[i].keys()), \
                                                          np.array(list(tot_fitness_hap_cross_mut_rnase[i].values())) / 1000, \
                                                          markerfacecolor='b', markeredgecolor='b', marker='o', ms=8, color='r',
                                                          label='mut. RNase + cross SLF mut.')  # haplotype that has a SLF cross mutation
                    p_num_rnase_mut_slf_cross, = ax2.plot(list(tot_fitness_hap_cross_mut_rnase[i].keys()), \
                                                          np.array(list(tot_fitness_hap_cross_mut_rnase[i].values())) / 1000, \
                                                          markerfacecolor='r', markeredgecolor='r', marker="|", markeredgewidth=2,
                                                          linestyle='none',
                                                          label='mut. RNase + cross SLF mut.')

            ax2.grid(which='both', axis='both', color="0.8", linestyle='--')
            ax2.set_xlabel('generation', fontdict=font_dict_axis)  # , fontweight=300)
            # ax2.set_xticklabels([])
            ax2.set_ylabel('male fitness', fontdict=font_dict_axis)  # , fontweight=300)
            ax2.set_title('b', loc='left', fontweight="bold")

            sum_expected_num_change_ext_gro_dict

            p_num_ext_gro, = ax3.plot(list(sum_expected_num_change_ext_gro_dict.keys()), \
                                      list(sum_expected_num_change_ext_gro_dict.values()), \
                                      marker='o', color=[0.5, 0.5, 0.5], label='ext gro')

            p_num_rnase_orig, = ax3.plot(list(sum_expected_num_change_orig_rnase_dict.keys()), \
                                         list(sum_expected_num_change_orig_rnase_dict.values()), \
                                         markerfacecolor='b', markeredgecolor='b', marker="_", markeredgewidth=2,
                                         color=[0.5, 0.5, 0.5],
                                         label='orig. RNase')

            p_num_rnase_mut, = ax3.plot(list(sum_expected_num_change_mut_rnase_dict.keys()), \
                                        list(sum_expected_num_change_mut_rnase_dict.values()), \
                                        markerfacecolor='r', markeredgecolor='r', marker="|", markeredgewidth=2,
                                        color=[0.5, 0.5, 0.5],
                                        label='mut. RNase')

            p_num_rnase_orig_slf_cross, = ax3.plot(list(sum_expected_num_change_cross_SLF_in_orig_dict.keys()), \
                                                   list(sum_expected_num_change_cross_SLF_in_orig_dict.values()), \
                                                   markerfacecolor='r', markeredgecolor='r', marker='o', ms=8, color='b',
                                                   label='orig. RNase + cross SLF mut.')

            p_num_rnase_orig_slf_cross, = ax3.plot(list(sum_expected_num_change_cross_SLF_in_orig_dict.keys()), \
                                                   list(sum_expected_num_change_cross_SLF_in_orig_dict.values()), \
                                                   markerfacecolor='b', markeredgecolor='b', marker="_", markeredgewidth=2,
                                                   linestyle='none',
                                                   label='orig. RNase + cross SLF mut.')

            p_num_rnase_mut_slf_cross, = ax3.plot(list(sum_expected_num_change_cross_SLF_in_mut_dict.keys()), \
                list(sum_expected_num_change_cross_SLF_in_mut_dict.values()), \
                markerfacecolor='b', markeredgecolor='b', marker='o', ms=8, color='r',
                label='mut. RNase + cross SLF mut.')  # haplotype that has a SLF cross mutation
            p_num_rnase_mut_slf_cross, = ax3.plot(list(sum_expected_num_change_cross_SLF_in_mut_dict.keys()), \
                list(sum_expected_num_change_cross_SLF_in_mut_dict.values()), \
                markerfacecolor='r', markeredgecolor='r', marker="|", markeredgewidth=2,
                linestyle='none',
                label='mut. RNase + cross SLF mut.')

            ax3.grid(which='both', axis='both', color="0.8", linestyle='--')
            ax3.set_xlabel('generation', fontdict=font_dict_axis)  # , fontweight=300)
            # ax2.set_xticklabels([])
            ax3.set_ylabel('fitness adjusted size', fontdict=font_dict_axis)  # , fontweight=300)
            # ax3.set_yticklabels([])
            # ax3.set_xticklabels([])
            ax3.set_xlim(ax2.get_xlim())
            ax3.set_title('c', loc='left', fontweight="bold")

            plt.tight_layout()

            #fig_path = output_dir + '/fitness_haps_ext_iter' + str(iter_ext_ind) + '_ext_gro_' + str(
            #    extinct_group) + '_RNase_mutant_' + str(mut_RNase) + '_' + str(min_duration * 10)

            # fig_path = output_dir + '/RNase_mutant_' + str(mut_RNase) + '_ext_gro_' + str(extinct_group) + '_' + str(min_duration * 10)
            plt.savefig(output_dir[2:7] + '.pdf')
            #plt.savefig(fig_path + '.png')
            plt.close()
