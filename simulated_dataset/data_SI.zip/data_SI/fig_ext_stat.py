#
#		SLF-RNAse interaction in Non-self recognition self-incompatible (SI) System
#
##########################################################################################

#from mpl_toolkits.mplot3d import Axes3D
#import pylab
#import sympy as sp
#from operator import itemgetter
#from scipy import linalg
from pylab import genfromtxt
#import fit
#import networkx as nx
from multiprocessing import Pool#, TimeoutError, Process, Queue, Pipe, Value, Array
import os, math, pdb, time, random as ra, numpy as np, matplotlib.pyplot as plt, sys
import collections, pickle
from datetime import datetime
#from numba import jit
import pickle
from scipy.optimize import curve_fit
import matplotlib.ticker as mtick
#from scipy.integrate import odeint
#from scipy.signal import argrelextrema, find_peaks
#from scipy import signal
#import matplotlib
from mpl_toolkits.axes_grid1.inset_locator import (inset_axes, InsetPosition, mark_inset, zoomed_inset_axes)
#matplotlib.use('ps')
#from matplotlib import rc
#rc('text',usetex=True)
#rc('text.latex', preamble='\usepackage{color}')
########################################################################################################
start_time = datetime.now()
print ('Starts|--------|', start_time)

directory = './ext_stats'

with open(directory + '/cum_t_n_gro_dict_ext.pkl', 'rb') as input:
    cum_t_n_gro_dict= pickle.load(input)
with open(directory + '/n_gro_before_ext_neutral_count_all_noncomp.pkl', 'rb') as input:
    n_gro_before_ext_neutral= pickle.load(input)
with open(directory + '/n_gro_before_ext_split_count_all_noncomp.pkl', 'rb') as input:
    n_gro_before_ext_split= pickle.load(input)
with open(directory + '/n_gro_before_ext_SLF_mut_count_all_noncomp.pkl', 'rb') as input:
    n_gro_before_ext_SLF_mut= pickle.load(input)
with open(directory + '/n_gro_before_ext_SLF_orig_count_all_noncomp.pkl', 'rb') as input:
    n_gro_before_ext_SLF_orig= pickle.load(input)

#------------------------------------------------------------------------------

n_gro_before_ext_neutral_all_files_dict = {}
n_gro_before_ext_split_all_files_dict = {}
n_gro_before_ext_SLF_mut_all_files_dict = {}
n_gro_before_ext_SLF_orig_all_files_dict = {}


for n_gro in range(1,30):
    n_gro_before_ext_neutral_all_files_dict[n_gro] = 0
    n_gro_before_ext_split_all_files_dict[n_gro] = 0
    n_gro_before_ext_SLF_mut_all_files_dict[n_gro] = 0
    n_gro_before_ext_SLF_orig_all_files_dict[n_gro] = 0

for vals in n_gro_before_ext_neutral.values():
    for n_gro, num in vals.items():
        n_gro_before_ext_neutral_all_files_dict[n_gro] += num

for vals in n_gro_before_ext_split.values():
    for n_gro, num in vals.items():
        n_gro_before_ext_split_all_files_dict[n_gro] += num

for vals in n_gro_before_ext_SLF_mut.values():
    for n_gro, num in vals.items():
        n_gro_before_ext_SLF_mut_all_files_dict[n_gro] += num

for vals in n_gro_before_ext_SLF_orig.values():
    for n_gro, num in vals.items():
        n_gro_before_ext_SLF_orig_all_files_dict[n_gro] += num

#----------------------------------------------------------------------------------

p_ext_neutral_given_k_gro = {}
p_ext_split_given_k_gro = {}
p_ext_SLF_mut_given_k_gro = {}
p_ext_SLF_orig_given_k_gro = {}

p_ext_neutral_given_k_gro1 = {}
p_ext_split_given_k_gro1 = {}
p_ext_SLF_mut_given_k_gro1 = {}
p_ext_SLF_orig_given_k_gro1 = {}


for n_gro in range(4,13):

    p_ext_neutral_given_k_gro1[n_gro] = n_gro_before_ext_neutral_all_files_dict[n_gro]/ \
       np.sum(list(n_gro_before_ext_neutral_all_files_dict.values()))/ \
       (cum_t_n_gro_dict[n_gro]/np.sum(list(cum_t_n_gro_dict.values())))

    p_ext_split_given_k_gro1[n_gro] = n_gro_before_ext_split_all_files_dict[n_gro]/ \
        np.sum(list(n_gro_before_ext_split_all_files_dict.values()))/ \
        (cum_t_n_gro_dict[n_gro]/np.sum(list(cum_t_n_gro_dict.values())))

    p_ext_SLF_mut_given_k_gro1[n_gro] = n_gro_before_ext_SLF_mut_all_files_dict[n_gro] / \
        np.sum(list(n_gro_before_ext_SLF_mut_all_files_dict.values())) / \
        (cum_t_n_gro_dict[n_gro] / np.sum(list(cum_t_n_gro_dict.values())))

    p_ext_SLF_orig_given_k_gro1[n_gro] = n_gro_before_ext_SLF_orig_all_files_dict[n_gro] / \
        np.sum(list(n_gro_before_ext_SLF_orig_all_files_dict.values())) / \
        (cum_t_n_gro_dict[n_gro] / np.sum(list(cum_t_n_gro_dict.values())))



for n_gro in range(4,13):
    if cum_t_n_gro_dict[n_gro] == 0:
        p_ext_neutral_given_k_gro[n_gro] = np.nan
        p_ext_split_given_k_gro[n_gro] = np.nan
        p_ext_SLF_mut_given_k_gro[n_gro] = np.nan
        p_ext_SLF_orig_given_k_gro[n_gro] = np.nan
    else:
        p_ext_neutral_given_k_gro[n_gro] = n_gro_before_ext_neutral_all_files_dict[n_gro]/ \
           cum_t_n_gro_dict[n_gro]
        p_ext_split_given_k_gro[n_gro] = n_gro_before_ext_split_all_files_dict[n_gro]/ \
            cum_t_n_gro_dict[n_gro]
        p_ext_SLF_mut_given_k_gro[n_gro] = n_gro_before_ext_SLF_mut_all_files_dict[n_gro] / \
            cum_t_n_gro_dict[n_gro]
        p_ext_SLF_orig_given_k_gro[n_gro] = n_gro_before_ext_SLF_orig_all_files_dict[n_gro] / \
            cum_t_n_gro_dict[n_gro]


#-------------------------------------------------------------------------------------------------





x_lim_min = 4
x_lim_max = 13



#-----------------------------------------------------------------
fig = plt.figure(figsize=(7.0,2.75))
plt.subplots_adjust(top=0.920, bottom=0.130, left=0.062, right=0.990, hspace=0.375, wspace=0.20)
fontsizeX, fontsizeY, fonttitle, fontticks, fontsizetext = 9, 8, 9, 6.5, 8


Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
alpha_Color = 0.25
lw = 0.5; mW = 1.5; mS = 6
color1, color2, color3 = 'g', 'b', 'r'

# ax1 = fig.add_subplot(1, 3, 1)
ax1 = plt.subplot(1, 2, 1)
ax1.spines.right.set_visible(False)
ax1.spines.top.set_visible(False)

ax3 = plt.subplot(1, 2, 2)
ax3.spines.right.set_visible(False)
ax3.spines.top.set_visible(False)

width = 0.2
ax1.bar(np.array(list(n_gro_before_ext_split_all_files_dict.keys()))-0.3,
        list(n_gro_before_ext_split_all_files_dict.values())/ \
        np.sum(list(n_gro_before_ext_split_all_files_dict.values())),
         color = 'g', width = width) #log=True, #/np.sum(list(dt_dict.values()))/10,

ax1.bar(np.array(list(n_gro_before_ext_neutral_all_files_dict.keys()))-0.1,
        list(n_gro_before_ext_neutral_all_files_dict.values()) / \
        np.sum(list(n_gro_before_ext_neutral_all_files_dict.values())),
         color = 'r', width = width) #log=True, #/np.sum(list(dt_dict.values()))/10,

ax1.bar(np.array(list(n_gro_before_ext_SLF_orig_all_files_dict.keys()))+0.1,
        list(n_gro_before_ext_SLF_orig_all_files_dict.values())/ \
        np.sum(list(n_gro_before_ext_SLF_orig_all_files_dict.values())),
         color = 'm', width = width)

ax1.bar(np.array(list(n_gro_before_ext_SLF_mut_all_files_dict.keys()))+0.3,
        list(n_gro_before_ext_SLF_mut_all_files_dict.values())/ \
        np.sum(list(n_gro_before_ext_SLF_mut_all_files_dict.values())),
         color = 'y', width = width)

ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
ax1.set_xticks(list(n_gro_before_ext_neutral_all_files_dict.keys()), minor = False)
ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
ax1.set_yticks(np.arange(0.0,0.5,0.1), minor = False)
ax1.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
ax1.set_yticks(np.arange(0.0,0.52,0.02), minor = True)
ax1.set_xlim(x_lim_min+1.25, x_lim_max+0.25)
ax1.set_ylabel('Fraction of events in $K$ classes', fontsize=fontsizeY)
ax1.set_xlabel('# classes', fontsize=fontsizeX)
ax1.set_title(Title[0], loc='left', fontweight='bold')
ax1.legend(['ext + split', 'neutral', 'cross mut. in comp.', 'cross mut. in non-comp.'], frameon=False, loc=2, fontsize=fontticks-0.5)





width = 0.2

ax3.bar(np.arange(4,13)-0.3, np.array(list(p_ext_split_given_k_gro.values()))*1000,
         color = 'g', width = width, label = 'ext + split') #log=True, #/np.sum(list(dt_dict.values()))/10,


ax3.bar(np.arange(4,13)-0.1, np.array(list(p_ext_neutral_given_k_gro.values()))*1000,
         color = 'r', width = width, label='neutral') #log=True, #/np.sum(list(dt_dict.values()))/10,

ax3.bar(np.arange(4,13)+0.1, np.array(list(p_ext_SLF_orig_given_k_gro.values()))*1000,
         color = 'm', width = width, label = 'cross mut. in comp.')

ax3.bar(np.arange(4,13)+0.3, np.array(list(p_ext_SLF_mut_given_k_gro.values()))*1000,
         color = 'y', width = width, label = 'cross mut. in non-comp.')

ax3.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
ax3.set_xticks(list(n_gro_before_ext_neutral_all_files_dict.keys()), minor = False)
ax3.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
ax3.set_yticks(np.arange(0.0,1.51,0.5), minor = False)
ax3.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
ax3.set_yticks(np.arange(0.0,1.5,0.1), minor = True)
ax3.set_xlim(x_lim_min+1.25, x_lim_max+0.25)
ax3.set_ylabel('# events in K classes / total time in \n$K$ classes'+r'$(\times ~10^{-3})$', fontsize=fontsizeY)
ax3.set_xlabel('# classes', fontsize=fontsizeX)
ax3.set_title(Title[1], loc='left', fontweight='bold')


#plt.tight_layout()
plt.savefig('../SI_figures/Fig_ext_statistics_all_trajs_Eminus6.pdf', transparent=True)
plt.close()

print ('Ends|----|H:M:S|{}'.format(datetime.now() - start_time), '\n')
###############################################################################################################
###############################################################################################################
