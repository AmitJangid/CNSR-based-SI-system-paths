#
#		SLF-RNAse interaction in Non-self recognition self-incompatible (SI) System
#
##########################################################################################

#from mpl_toolkits.mplot3d import Axes3D
#import pylab
#import sympy as sp
#from operator import itemgetter
#from scipy import linalg
from pylab import genfromtxt
#import fit
#import networkx as nx
from multiprocessing import Pool#, TimeoutError, Process, Queue, Pipe, Value, Array
import os, math, pdb, time, random as ra, numpy as np, matplotlib.pyplot as plt, sys
import collections, pickle
from datetime import datetime
#from numba import jit
import pickle
from scipy.optimize import curve_fit
import matplotlib.ticker as mtick
from mpl_toolkits.axes_grid1.inset_locator import (inset_axes, InsetPosition, mark_inset, zoomed_inset_axes)
#from scipy.integrate import odeint
#from scipy.signal import argrelextrema, find_peaks
#from scipy import signal
########################################################################################################
start_time = datetime.now()
print ('Starts|--------|', start_time)

def bin_Control(input_Var, no_bins, density):
    data_X, data_Y = input_Var[:,0], input_Var[:,1]
    density_State = density # 1 means PDF, 0 means PMF

    Check_Bin = np.linspace(min(input_Var[:,0]),max(input_Var[:,0])+1,no_bins+1)
    output_Bin_Data = np.zeros(len(Check_Bin)-1)

    for bin1, bin2, index in zip(Check_Bin[:-1], Check_Bin[1:], range(len(Check_Bin[1:]))):
        current_Bin_Data = [Value for Key, Value in zip(data_X, data_Y) if Key >= bin1 and Key < bin2]
        if density_State == 1:
            if len(current_Bin_Data) > 0:
                output_Bin_Data[index] = sum(current_Bin_Data)/float(len(current_Bin_Data))
            else:
                output_Bin_Data[index] = sum(current_Bin_Data)
        if density_State == 0:
            output_Bin_Data[index] = sum(current_Bin_Data)

    frequency = np.array(output_Bin_Data)/sum(output_Bin_Data)
    center_bin = (Check_Bin[:-1]+Check_Bin[1:])/2

    return center_bin, frequency, (max(input_Var[:,0]) - min(input_Var[:,0]))/no_bins


def SI_figures(inpuT):
    index = inpuT

    #E = -4, N = 500, mu = 10^-4
    if index == 1:

        E = -4
        x_lim_min = 7
        x_lim_max = 16.5
        directory = './ext_split_stat/Eminus4'


        cum_t_n_gro_dict = pickle.load(open(directory + '/cum_t_n_gro_dict.pkl', 'rb'))
        n_gro_before_splt_dict = pickle.load(open(directory + '/n_gro_before_splt_dict.pkl', 'rb'))
        n_gro_before_ext_dict = pickle.load(open(directory + '/n_gro_before_ext_dict.pkl', 'rb'))

        n_gro_before_ext_all_files_dict = {}
        n_gro_before_splt_all_files_dict = {}
        for n_gro in range(1,30):
            n_gro_before_ext_all_files_dict[n_gro] = 0
            n_gro_before_splt_all_files_dict[n_gro] = 0

        for vals in n_gro_before_ext_dict.values():
            for n_gro, num in vals.items():
                n_gro_before_ext_all_files_dict[n_gro] += num

        for vals in n_gro_before_splt_dict.values():
            for n_gro, num in vals.items():
                n_gro_before_splt_all_files_dict[n_gro] += num


        p_ext_given_k_gro = {}
        p_splt_given_k_gro = {}
        p_ext_splt_given_k_gro = {}


        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):

            if cum_t_n_gro_dict[n_gro] == 0:
                p_ext_given_k_gro[n_gro] = np.nan
                p_splt_given_k_gro[n_gro] = np.nan
                p_ext_splt_given_k_gro[n_gro] = np.nan

            else:
                p_ext_given_k_gro[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                    cum_t_n_gro_dict[n_gro]
                p_splt_given_k_gro[n_gro] = n_gro_before_splt_all_files_dict[n_gro]/ \
                    cum_t_n_gro_dict[n_gro]
                p_ext_splt_given_k_gro[n_gro] = (n_gro_before_splt_all_files_dict[n_gro] \
                     + n_gro_before_ext_all_files_dict[n_gro])/ \
                    cum_t_n_gro_dict[n_gro]

        p_gro_before_ext_all_files_dict = {}
        p_gro_before_splt_all_files_dict = {}
        prop_ext_all_files_dict = {}
        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):
            p_gro_before_ext_all_files_dict[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                np.sum(list(n_gro_before_ext_all_files_dict.values()))

            p_gro_before_splt_all_files_dict[n_gro] = n_gro_before_splt_all_files_dict[n_gro]/ \
                np.sum(list(n_gro_before_splt_all_files_dict.values()))

        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):
            if (n_gro_before_splt_all_files_dict[n_gro] \
                 + n_gro_before_ext_all_files_dict[n_gro]) == 0:
                prop_ext_all_files_dict[n_gro] = np.nan
            else:
                prop_ext_all_files_dict[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                (n_gro_before_splt_all_files_dict[n_gro] \
                 + n_gro_before_ext_all_files_dict[n_gro])





        fig = plt.figure(figsize=(8,5.0))
        plt.subplots_adjust(top=0.956, bottom=0.071, left=0.072, right=0.995, hspace=0.40, wspace=0.27)
        fontsizeX, fontsizeY, fonttitle, fontticks, fontsizetext = 9, 8, 9, 6.5, 8


        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'




        data_1_key, data_1_value = np.array(list(cum_t_n_gro_dict.keys())), list(cum_t_n_gro_dict.values())/np.sum(list(cum_t_n_gro_dict.values()))
        width = 0.3
        print (len(list(p_gro_before_ext_all_files_dict.values())))
        data_2a_key, data_2a_value = np.arange(x_lim_min-1,int(np.ceil(x_lim_max)))-width/2, list(p_gro_before_ext_all_files_dict.values())
        data_2b_key, data_2b_value = np.arange(x_lim_min-1,int(np.ceil(x_lim_max)))+width/2, list(p_gro_before_splt_all_files_dict.values())
        data_3a_key, data_3a_value = np.array(list(p_ext_given_k_gro.keys())) - width/2, np.array(list(p_ext_given_k_gro.values()))*1000
        data_3b_key, data_3b_value = np.array(list(p_splt_given_k_gro.keys())) + width/2, np.array(list(p_splt_given_k_gro.values()))*1000



        width1=0.4
        binSize = 28

        ax1 = plt.subplot(2, 3, 1)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        ax1.bar(data_1_key, data_1_value, color = 'k', width = width1)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize = 0)
        ax1.set_yticks(np.arange(0,0.36,0.01), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(x_lim_min+1,x_lim_max+1.0,2), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,1), minor = True)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,0.36,0.10), minor = False)
        ax1.set_title(Title[0], loc='left', fontweight='bold')
        ax1.set_ylabel('Fraction of time in $K$ classes', fontsize=fontsizeY, labelpad=14)
        #ax1.set_xlabel('# classes', fontsize=fontsizeY)
        ax1.set_xlim(x_lim_min+0.5, x_lim_max)
        ax1.set_xlabel('# classes', fontsize=fontsizeY)

        width=width
        ax2 = plt.subplot(2, 3, 2)
        ax2.spines.right.set_visible(False)
        ax2.spines.top.set_visible(False)
        ax2.bar(data_2a_key, data_2a_value, width=width, color=color3, label='extinctions')
        ax2.bar(data_2b_key, data_2b_value, width=width, color=color1, label='splits')
        ax2.set_xlim(-3, 500)
        ax2.tick_params(axis = 'y', which = 'minor', labelsize = 0)
        ax2.set_yticks(np.arange(0,0.36,0.01), minor = True)
        ax2.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax2.set_xticks(np.arange(x_lim_min+1,x_lim_max+1.0,2), minor = False)
        ax2.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax2.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,1), minor = True)
        ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax2.set_yticks(np.arange(0,0.36,0.10), minor = False)
        ax2.set_title(Title[1], loc='left', fontweight='bold')
        #ax2.set_xlabel('# classes', fontsize=fontsizeY)
        ax2.set_ylabel('Fraction of events in $K$ classes', fontsize=fontsizeY, labelpad=13)
        ax2.legend(frameon=False, ncol=2, fontsize=fontticks, bbox_to_anchor=(1.0, 1.07))
        ax2.set_xlim(x_lim_min+0.5,x_lim_max)
        ax2.set_xlabel('# classes', fontsize=fontsizeY)

        ax3 = plt.subplot(2, 3, 3)
        ax3.spines.right.set_visible(False)
        ax3.spines.top.set_visible(False)
        ax3.bar(data_3a_key, data_3a_value, width=width, color=color3, label='extinctions')
        ax3.bar(data_3b_key, data_3b_value, width=width, color=color1, label='split')
        ax3.tick_params(axis = 'y', which = 'minor', labelsize = 0)
        ax3.set_yticks(np.arange(0,180,10), minor = True)
        ax3.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax3.set_xticks(np.arange(x_lim_min+1,x_lim_max+1.0,2), minor = False)
        ax3.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax3.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,1), minor = True)
        ax3.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax3.set_yticks(np.arange(1,180,25), minor = False)
        ax3.set_title(Title[2], loc='left', fontweight='bold')
        #ax3.set_xlabel('# classes', fontsize=fontsizeY)
        ax3.set_ylabel('# events in $K$ classes / total \ntime in $K$ classes '+r'$(\times 10^{-3})$', fontsize=fontsizeY, labelpad=-3)
        ax3.set_xlim(x_lim_min+0.5,x_lim_max)
        ax3.set_ylim(0.05,180)
        ax3.set_yscale('log')
        ax3.set_xlabel('# classes', fontsize=fontsizeY)


        ax4 = plt.subplot(2, 3, 4)
        ax4.spines.right.set_visible(False)
        ax4.spines.top.set_visible(False)
        ax4.bar(np.arange(x_lim_min-1,int(np.ceil(x_lim_max))), list(p_ext_splt_given_k_gro.values()),
                 color = 'k', width = width) #log=True, #/np.sum(list(dt_dict.values()))/10,
        ax4.set_yscale('log')
        ax4.set_xticks(list(n_gro_before_ext_all_files_dict.keys()))
        ax4.set_xticklabels(list(n_gro_before_ext_all_files_dict.keys()), fontsize=8)
        #ax4.tick_params(axis = 'y', which = 'minor', labelsize = 0)
        #ax4.set_yticks(np.arange(0,180,10), minor = True)
        ax4.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax4.set_xticks(np.arange(x_lim_min+1,x_lim_max+1.0,2), minor = False)
        ax4.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax4.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,1), minor = True)
        ax4.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        #ax4.set_yticks(np.arange(1,180,25), minor = False)
        ax4.set_title(Title[3], loc='left', fontweight='bold')
        ax4.set_xlim(x_lim_min, x_lim_max)
        ax4.set_ylabel('# (splits and extinction) divided \n'+r'by time in $K$-classes', fontsize=fontsizeY, labelpad=-1)
        ax4.set_xlim(x_lim_min+0.5,x_lim_max)
        ax4.set_xlabel('# classes', fontsize=fontsizeY)





        non_classified = pickle.load(open('./unclassified_hap/num_SC_haps_all_iters_all_files_E-4_N500_a095_d_1.pkl', 'rb'))
        print (type(non_classified), len(non_classified))


        #Mean, Std, full_data = [], [], []
        #for ele in non_classified:
        #    full_data.extend(ele)
        #    if len(ele) > 0:
        #        Mean.append(np.round(np.mean(np.array(ele)/1000), decimals=4))
        #        Std.append(np.round(np.std(np.array(ele)/1000), decimals=4))
        #full_data = np.array(full_data)
        #print (np.array(Mean), np.array(Std))

        full_data = np.array(non_classified)
        Avg = np.round(np.mean(full_data/1000), decimals=3)
        STD = np.round(np.std(full_data/1000), decimals=3)
        print (Avg, STD)

        data_X, data_Y = np.unique(full_data, return_counts=True)
        print (data_X, data_Y)
        print (max(data_X), 'x limit', '\n')

        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'

        ax1 = plt.subplot(2, 3, 5)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        width = 0.50
        ax1.plot(data_X/1000, data_Y*100/sum(data_Y), '-')
        ax1.vlines(np.mean(full_data)/1000, 0, 100, linestyle='dashed', color='r')
        #ax1.errorbar(range(0,len(data_X)), data_X, yerr=data_Y, elinewidth = width)
        #ax1.vlines(range(0,len(data_X)), data_X-data_Y, data_X+data_Y, linestyles='solid', linewidth=1.0, color='red', alpha=0.5)
        ax1.set_ylabel(r'PDF $(\times~ 10^{-2})$', fontsize=fontsizeY)
        ax1.set_xlabel('Fraction of SC haplotypes', fontsize=fontsizeY)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0.0,1.01*20,0.2*20), minor = False)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,1.01*20,0.2*20/4), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.026,0.005), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.025,0.005/3), minor = True)
        ax1.set_xlim(-0.0001,0.024)
        ax1.set_ylim(-0.25, 21)
        ax1.text(Avg+0.0002, 1.55, Avg, fontsize=fontsizeX-2, color='r')
        ax1.set_title(Title[4], loc='left', fontweight='bold')


        ax2 = inset_axes(ax1, 1.2, 0.8 , loc=1, bbox_to_anchor=(0.67, 0.435),bbox_transform=ax1.figure.transFigure)
        ax2.spines.right.set_visible(False)
        ax2.spines.top.set_visible(False)
        ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0.0,1.01,0.5), minor = False)
        ax2.tick_params(axis = 'y', which = 'minor', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0.0,1.01,0.2/2), minor = True)
        ax2.tick_params(axis = 'x', which = 'major', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.026,0.01), minor = False)
        ax2.tick_params(axis = 'x', which = 'minor', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.025,0.005/3), minor = True)
        ax2.set_xlim(-0.0001,0.025)
        ax2.set_ylim(0.0, 1.015)
        ax2.plot(data_X/1000, np.cumsum(data_Y/sum(data_Y)))
        #ax2.vlines(0.1, 0, 0.95, linestyle='dashed', color='k')
        #ax2.hlines(np.cumsum(data_Y/sum(data_Y))[100], 0, 0.1, linestyle='dashed', color='r')
        #ax2.text(0.123, 0.80, np.round(np.cumsum(data_Y/sum(data_Y))[100], 2), fontsize=fontsizeX-2)
        ax2.set_ylabel(r'CDF', fontsize=fontsizeX-3, labelpad=-0.5)






        non_classified = pickle.load(open('./unclassified_hap/n_non_class_hap_all_iters_all_files_E-4_N500_a095_d_1.pkl', 'rb'))
        print (type(non_classified), len(non_classified))


        Mean, Std, full_data = [], [], []
        for ele in non_classified:
            full_data.extend(ele)
            if len(ele) > 0:
                Mean.append(np.round(np.mean(np.array(ele)/1000), decimals=4))
                Std.append(np.round(np.std(np.array(ele)/1000), decimals=4))

        full_data = np.array(full_data)
        print (np.array(Mean), np.array(Std))

        Avg = np.round(np.mean(full_data/1000), decimals=3)
        STD = np.round(np.std(full_data/1000), decimals=3)
        print (Avg, STD)

        data_X, data_Y = np.unique(full_data, return_counts=True)
        print (list(data_X).index(100), np.cumsum(data_Y/sum(data_Y))[100])

        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'

        ax1 = plt.subplot(2, 3, 6)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        width = 0.50
        ax1.plot(data_X/1000, data_Y*100/sum(data_Y))
        ax1.vlines(np.mean(full_data)/1000, 0, 3.5, linestyle='dashed', color='r')
        #ax1.errorbar(range(0,len(data_X)), data_X, yerr=data_Y, elinewidth = width)
        #ax1.vlines(range(0,len(data_X)), data_X-data_Y, data_X+data_Y, linestyles='solid', linewidth=1.0, color='red', alpha=0.5)
        ax1.set_ylabel(r'PDF $(\times~ 10^{-2})$', fontsize=fontsizeY)
        ax1.set_xlabel('Fraction of unclassified haplotypes', fontsize=fontsizeY)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0.0,9.05,2.0), minor = False)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,9.05,0.5), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.23,0.1), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.23,0.02), minor = True)
        ax1.set_xlim(-0.005,0.23)
        ax1.set_ylim(-0.1, 6.0)
        ax1.text(Avg+0.005, 1.55, Avg, fontsize=fontsizeX-2, color='r')
        ax1.set_title(Title[5], loc='left', fontweight='bold')


        ax2 = inset_axes(ax1, 1.2, 0.8 , loc=1, bbox_to_anchor=(1.006, 0.435),bbox_transform=ax1.figure.transFigure)
        ax2.spines.right.set_visible(False)
        ax2.spines.top.set_visible(False)
        ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0.0,1.01,0.5), minor = False)
        ax2.tick_params(axis = 'y', which = 'minor', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0,1.01,0.1), minor = True)
        ax2.tick_params(axis = 'x', which = 'major', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.23,0.1), minor = False)
        ax2.tick_params(axis = 'x', which = 'minor', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.23,0.02), minor = True)
        ax2.set_xlim(-0.005,0.23)
        ax2.set_ylim(-0.015, 1.015)
        ax2.plot(data_X/1000, np.cumsum(data_Y/sum(data_Y)))
        ax2.vlines(0.1, 0, 1.1, linestyle='dashed', color='k')
        #ax2.hlines(np.cumsum(data_Y/sum(data_Y))[100], 0, 0.1, linestyle='dashed', color='r')
        if data_X[100] == 100:
            ax2.text(0.123, 0.80, np.round(np.cumsum(data_Y/sum(data_Y))[100], 2), fontsize=fontsizeX-2)
        ax2.set_ylabel(r'CDF', fontsize=fontsizeX-3, labelpad=-0.5)


        plt.savefig('../SI_figures/Fig_ext_splt_statistics_E-4.pdf', transparent=True)
        #plt.show()
        plt.close()

    #E = -8, N = 500, mu = 10^-4
    if index == 2:

        E = -8
        x_lim_min = 2
        x_lim_max = 13.5
        directory = './ext_split_stat/Eminus8'

        cum_t_n_gro_dict = pickle.load(open(directory + '/cum_t_n_gro_dict.pkl', 'rb'))
        n_gro_before_splt_dict = pickle.load(open(directory + '/n_gro_before_splt_dict.pkl', 'rb'))
        n_gro_before_ext_dict = pickle.load(open(directory + '/n_gro_before_ext_dict.pkl', 'rb'))

        n_gro_before_ext_all_files_dict = {}
        n_gro_before_splt_all_files_dict = {}
        for n_gro in range(1,30):
            n_gro_before_ext_all_files_dict[n_gro] = 0
            n_gro_before_splt_all_files_dict[n_gro] = 0

        for vals in n_gro_before_ext_dict.values():
            for n_gro, num in vals.items():
                n_gro_before_ext_all_files_dict[n_gro] += num

        for vals in n_gro_before_splt_dict.values():
            for n_gro, num in vals.items():
                n_gro_before_splt_all_files_dict[n_gro] += num


        p_ext_given_k_gro = {}
        p_splt_given_k_gro = {}
        p_ext_splt_given_k_gro = {}


        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):

            if cum_t_n_gro_dict[n_gro] == 0:
                p_ext_given_k_gro[n_gro] = np.nan
                p_splt_given_k_gro[n_gro] = np.nan
                p_ext_splt_given_k_gro[n_gro] = np.nan

            else:
                p_ext_given_k_gro[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                    cum_t_n_gro_dict[n_gro]
                p_splt_given_k_gro[n_gro] = n_gro_before_splt_all_files_dict[n_gro]/ \
                    cum_t_n_gro_dict[n_gro]
                p_ext_splt_given_k_gro[n_gro] = (n_gro_before_splt_all_files_dict[n_gro] \
                     + n_gro_before_ext_all_files_dict[n_gro])/ \
                    cum_t_n_gro_dict[n_gro]

        p_gro_before_ext_all_files_dict = {}
        p_gro_before_splt_all_files_dict = {}
        prop_ext_all_files_dict = {}
        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):
            p_gro_before_ext_all_files_dict[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                np.sum(list(n_gro_before_ext_all_files_dict.values()))

            p_gro_before_splt_all_files_dict[n_gro] = n_gro_before_splt_all_files_dict[n_gro]/ \
                np.sum(list(n_gro_before_splt_all_files_dict.values()))

        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):
            if (n_gro_before_splt_all_files_dict[n_gro] \
                 + n_gro_before_ext_all_files_dict[n_gro]) == 0:
                prop_ext_all_files_dict[n_gro] = np.nan
            else:
                prop_ext_all_files_dict[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                (n_gro_before_splt_all_files_dict[n_gro] \
                 + n_gro_before_ext_all_files_dict[n_gro])



        fig = plt.figure(figsize=(8,5.0))
        plt.subplots_adjust(top=0.956, bottom=0.071, left=0.072, right=0.995, hspace=0.40, wspace=0.27)
        fontsizeX, fontsizeY, fonttitle, fontticks, fontsizetext = 9, 8, 9, 6.5, 8


        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'




        data_1_key, data_1_value = np.array(list(cum_t_n_gro_dict.keys())), list(cum_t_n_gro_dict.values())/np.sum(list(cum_t_n_gro_dict.values()))
        width = 0.3
        data_2a_key, data_2a_value = np.arange(x_lim_min-1,int(np.ceil(x_lim_max)))-width/2, list(p_gro_before_ext_all_files_dict.values())
        data_2b_key, data_2b_value = np.arange(x_lim_min-1,int(np.ceil(x_lim_max)))+width/2, list(p_gro_before_splt_all_files_dict.values())
        data_3a_key, data_3a_value = np.array(list(p_ext_given_k_gro.keys())) - width/2, np.array(list(p_ext_given_k_gro.values()))*1000
        data_3b_key, data_3b_value = np.array(list(p_splt_given_k_gro.keys())) + width/2, np.array(list(p_splt_given_k_gro.values()))*1000
        #print (len(np.arange(x_lim_min-1,int(np.ceil(x_lim_max)))), len(list(p_gro_before_ext_all_files_dict.values())))


        width1=0.4
        binSize = 28

        ax1 = plt.subplot(2, 3, 1)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        ax1.bar(data_1_key, data_1_value, color = 'k', width = width1)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize = 0)
        ax1.set_yticks(np.arange(0,0.36,0.01), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,2), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,1), minor = True)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,0.36,0.10), minor = False)
        ax1.set_title(Title[0], loc='left', fontweight='bold')
        ax1.set_ylabel('Fraction of time in $K$ classes', fontsize=fontsizeY, labelpad=13)
        ax1.set_xlabel('# classes', fontsize=fontsizeY)
        ax1.set_xlim(x_lim_min+0.5,x_lim_max)

        width=width
        ax2 = plt.subplot(2, 3, 2)
        ax2.spines.right.set_visible(False)
        ax2.spines.top.set_visible(False)
        ax2.bar(data_2a_key[:], data_2a_value, width=width, color=color3, label='extinctions')
        ax2.bar(data_2b_key[:], data_2b_value, width=width, color=color1, label='splits')
        ax2.set_xlim(-3, 500)
        ax2.tick_params(axis = 'y', which = 'minor', labelsize = 0)
        ax2.set_yticks(np.arange(0,0.36,0.01), minor = True)
        ax2.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax2.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,2), minor = False)
        ax2.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax2.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,1), minor = True)
        ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax2.set_yticks(np.arange(0,0.32,0.10), minor = False)
        ax2.set_title(Title[1], loc='left', fontweight='bold')
        ax2.set_xlabel('# classes', fontsize=fontsizeY)
        ax2.set_ylabel('Fraction of events in $K$ classes', fontsize=fontsizeY, labelpad=13)
        ax2.legend(frameon=False, ncol=2, fontsize=fontticks, bbox_to_anchor=(1.0, 1.07))
        ax2.set_xlim(x_lim_min+0.5,x_lim_max)


        ax3 = plt.subplot(2, 3, 3)
        ax3.spines.right.set_visible(False)
        ax3.spines.top.set_visible(False)
        ax3.bar(data_3a_key, data_3a_value, width=width, color=color3, label='extinctions')
        ax3.bar(data_3b_key, data_3b_value, width=width, color=color1, label='split')
        ax3.tick_params(axis = 'y', which = 'minor', labelsize = 0)
        ax3.set_yticks(np.arange(0,180,10), minor = True)
        ax3.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax3.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,2), minor = False)
        ax3.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax3.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,1), minor = True)
        ax3.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax3.set_yticks(np.arange(1,180,25), minor = False)
        ax3.set_title(Title[2], loc='left', fontweight='bold')
        ax3.set_xlabel('# classes', fontsize=fontsizeY)
        ax3.set_ylabel('# events in $K$ classes / \n total time in $K$ classes '+r'$(\times 10^{-3})$', fontsize=fontsizeY, labelpad=0)
        ax3.set_xlim(x_lim_min+0.5,x_lim_max)
        ax3.set_ylim(0.05,180)
        ax3.set_yscale('log')


        ax4 = plt.subplot(2, 3, 4)
        ax4.spines.right.set_visible(False)
        ax4.spines.top.set_visible(False)
        ax4.bar(np.arange(x_lim_min-1,int(np.ceil(x_lim_max)))[:], list(p_ext_splt_given_k_gro.values()),
                 color = 'k', width = width) #log=True, #/np.sum(list(dt_dict.values()))/10,
        ax4.set_yscale('log')
        ax4.set_xticks(list(n_gro_before_ext_all_files_dict.keys()))
        ax4.set_xticklabels(list(n_gro_before_ext_all_files_dict.keys()), fontsize=8)
        #ax4.tick_params(axis = 'y', which = 'minor', labelsize = 0)
        #ax4.set_yticks(np.arange(0,180,10), minor = True)
        ax4.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax4.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,2), minor = False)
        ax4.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax4.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,1), minor = True)
        ax4.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        #ax4.set_yticks(np.arange(1,180,25), minor = False)
        ax4.set_title(Title[3], loc='left', fontweight='bold')
        ax4.set_xlim(x_lim_min+0.5, x_lim_max)
        ax4.set_ylabel('# (splits and extinction) divided \n'+r'by time in $K$-classes', fontsize=fontsizeY, labelpad=-1)
        ax4.set_xlabel('# classes', fontsize=fontsizeY)


        #ax4.bar(np.arange(x_lim_min-1,int(np.ceil(x_lim_max))), list(prop_ext_all_files_dict.values()),
                # color = 'k', width = width) #log=True, #/np.sum(list(dt_dict.values()))/10,
        #ax4.plot([x_lim_min-1,int(np.ceil(x_lim_max))], [0.5, 0.5], color='r', linestyle='dashed', label='split')




        non_classified = pickle.load(open('./unclassified_hap/num_SC_haps_all_iters_all_files_E-8_N500_a095_d_1.pkl', 'rb'))
        print (type(non_classified), len(non_classified))


        Mean, Std, full_data = [], [], []
        for ele in non_classified:
            full_data.extend(ele)
            if len(ele) > 0:
                Mean.append(np.round(np.mean(np.array(ele)/1000), decimals=4))
                Std.append(np.round(np.std(np.array(ele)/1000), decimals=4))

        full_data = np.array(full_data)
        #print (np.array(Mean), np.array(Std))

        Avg = np.round(np.mean(full_data/1000), decimals=3)
        STD = np.round(np.std(full_data/1000), decimals=3)
        print (Avg, STD)

        data_X, data_Y = np.unique(full_data, return_counts=True)
        print (max(data_X), 'x limit -- ', '\n')

        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'

        ax1 = plt.subplot(2, 3, 5)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        width = 0.50
        ax1.plot(data_X/1000, data_Y*100/sum(data_Y))
        ax1.vlines(np.mean(full_data)/1000, 0, 10, linestyle='dashed', color='r')
        #ax1.errorbar(range(0,len(data_X)), data_X, yerr=data_Y, elinewidth = width)
        #ax1.vlines(range(0,len(data_X)), data_X-data_Y, data_X+data_Y, linestyles='solid', linewidth=1.0, color='red', alpha=0.5)
        ax1.set_ylabel(r'PDF $(\times~ 10^{-2})$', fontsize=fontsizeY)
        ax1.set_xlabel('Fraction of SC haplotypes', fontsize=fontsizeY)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0.0,27,5), minor = False)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,27,1), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.32,0.1), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.32,0.1/4), minor = True)
        ax1.set_xlim(-0.006,0.32)
        ax1.set_ylim(-0.4, 27.0)
        ax1.text(Avg*5.5, 1.55, Avg, fontsize=fontsizeX-2, color='r')
        ax1.set_title(Title[4], loc='left', fontweight='bold')


        ax2 = inset_axes(ax1, 1.2, 0.8 , loc=1, bbox_to_anchor=(0.67, 0.435),bbox_transform=ax1.figure.transFigure)
        ax2.spines.right.set_visible(False)
        ax2.spines.top.set_visible(False)
        ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0.0,1.01,0.5), minor = False)
        ax2.tick_params(axis = 'y', which = 'minor', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0,1.01,0.1), minor = True)
        ax2.tick_params(axis = 'x', which = 'major', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.32,0.1), minor = False)
        ax2.tick_params(axis = 'x', which = 'minor', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.32,0.1/4), minor = True)
        ax2.set_xlim(-0.005,0.32)
        ax2.set_ylim(-0.015, 1.015)
        ax2.plot(data_X/1000, np.cumsum(data_Y/sum(data_Y)))
        #ax2.vlines(0.1, 0, 0.95, linestyle='dashed', color='k')
        #ax2.hlines(np.cumsum(data_Y/sum(data_Y))[100], 0, 0.1, linestyle='dashed', color='r')
        #ax2.text(0.123, 0.80, np.round(np.cumsum(data_Y/sum(data_Y))[100], 2), fontsize=fontsizeX-2)
        ax2.set_ylabel(r'CDF', fontsize=fontsizeX-3, labelpad=-0.5)






        non_classified = pickle.load(open('./unclassified_hap/n_non_class_hap_all_iters_all_files_E-8.pkl', 'rb'))
        print (type(non_classified), len(non_classified))


        Mean, Std, full_data = [], [], []
        for ele in non_classified:
            full_data.extend(ele)
            if len(ele) > 0:
                Mean.append(np.round(np.mean(np.array(ele)/1000), decimals=4))
                Std.append(np.round(np.std(np.array(ele)/1000), decimals=4))

        full_data = np.array(full_data)
        print (np.array(Mean), np.array(Std))

        Avg = np.round(np.mean(full_data/1000), decimals=3)
        STD = np.round(np.std(full_data/1000), decimals=3)
        print (Avg, STD)

        data_X, data_Y = np.unique(full_data, return_counts=True)
        #print (list(data_X).index(100), np.cumsum(data_Y/sum(data_Y))[100])

        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'

        ax1 = plt.subplot(2, 3, 6)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        width = 0.50
        ax1.plot(data_X/1000, data_Y*100/sum(data_Y))
        ax1.vlines(np.mean(full_data)/1000, 0, 2.0, linestyle='dashed', color='r')
        #ax1.errorbar(range(0,len(data_X)), data_X, yerr=data_Y, elinewidth = width)
        #ax1.vlines(range(0,len(data_X)), data_X-data_Y, data_X+data_Y, linestyles='solid', linewidth=1.0, color='red', alpha=0.5)
        ax1.set_ylabel(r'PDF $(\times~ 10^{-2})$', fontsize=fontsizeY)
        ax1.set_xlabel('Fraction of unclassified haplotypes', fontsize=fontsizeY)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0.0,6.05,2.0), minor = False)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,6.05,0.5), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.75,0.1), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.76,0.05/2), minor = True)
        ax1.set_xlim(-0.01,0.75)
        ax1.set_ylim(-0.070, 6.15)
        ax1.text(Avg+0.016, 1.55, Avg, fontsize=fontsizeX-2, color='r')
        ax1.set_title(Title[5], loc='left', fontweight='bold')


        ax2 = inset_axes(ax1, 1.2, 0.8 , loc=1, bbox_to_anchor=(1.006, 0.435),bbox_transform=ax1.figure.transFigure)
        ax2.spines.right.set_visible(False)
        ax2.spines.top.set_visible(False)
        ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0.0,1.01,0.5), minor = False)
        ax2.tick_params(axis = 'y', which = 'minor', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0,1.01,0.1), minor = True)
        ax2.tick_params(axis = 'x', which = 'major', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.76,0.2), minor = False)
        ax2.tick_params(axis = 'x', which = 'minor', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.76,0.05), minor = True)
        ax2.set_xlim(-0.01,0.75)
        ax2.set_ylim(-0.015, 1.015)
        ax2.plot(data_X/1000, np.cumsum(data_Y/sum(data_Y)))
        ax2.vlines(0.1, 0, 0.95, linestyle='dashed', color='k')
        #ax2.hlines(np.cumsum(data_Y/sum(data_Y))[100], 0, 0.1, linestyle='dashed', color='r')
        if data_X[100] == 100:
            ax2.text(0.123, 0.80, np.round(np.cumsum(data_Y/sum(data_Y))[100], 2), fontsize=fontsizeX-2)
        ax2.set_ylabel(r'CDF', fontsize=fontsizeX-3, labelpad=-0.5)



        #plt.tight_layout()
        plt.savefig('../SI_figures/Fig_ext_splt_statistics_E-8.pdf', transparent=True)
        #plt.show()
        plt.close()

    #E = -6, N = 250, mu = 10^-4
    if index == 3:

        E = -6; N = 250
        x_lim_min = 2
        x_lim_max = 10
        directory = './ext_split_stat/N250'


        cum_t_n_gro_dict = pickle.load(open(directory + '/cum_t_n_gro_dict.pkl', 'rb'))
        n_gro_before_splt_dict = pickle.load(open(directory + '/n_gro_before_splt_dict.pkl', 'rb'))
        n_gro_before_ext_dict = pickle.load(open(directory + '/n_gro_before_ext_dict.pkl', 'rb'))

        n_gro_before_ext_all_files_dict = {}
        n_gro_before_splt_all_files_dict = {}
        for n_gro in range(1,30):
            n_gro_before_ext_all_files_dict[n_gro] = 0
            n_gro_before_splt_all_files_dict[n_gro] = 0

        for vals in n_gro_before_ext_dict.values():
            for n_gro, num in vals.items():
                n_gro_before_ext_all_files_dict[n_gro] += num

        for vals in n_gro_before_splt_dict.values():
            for n_gro, num in vals.items():
                n_gro_before_splt_all_files_dict[n_gro] += num


        p_ext_given_k_gro = {}
        p_splt_given_k_gro = {}
        p_ext_splt_given_k_gro = {}


        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):

            if cum_t_n_gro_dict[n_gro] == 0:
                p_ext_given_k_gro[n_gro] = np.nan
                p_splt_given_k_gro[n_gro] = np.nan
                p_ext_splt_given_k_gro[n_gro] = np.nan

            else:
                p_ext_given_k_gro[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                    cum_t_n_gro_dict[n_gro]
                p_splt_given_k_gro[n_gro] = n_gro_before_splt_all_files_dict[n_gro]/ \
                    cum_t_n_gro_dict[n_gro]
                p_ext_splt_given_k_gro[n_gro] = (n_gro_before_splt_all_files_dict[n_gro] \
                     + n_gro_before_ext_all_files_dict[n_gro])/ \
                    cum_t_n_gro_dict[n_gro]

        p_gro_before_ext_all_files_dict = {}
        p_gro_before_splt_all_files_dict = {}
        prop_ext_all_files_dict = {}
        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):
            p_gro_before_ext_all_files_dict[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                np.sum(list(n_gro_before_ext_all_files_dict.values()))

            p_gro_before_splt_all_files_dict[n_gro] = n_gro_before_splt_all_files_dict[n_gro]/ \
                np.sum(list(n_gro_before_splt_all_files_dict.values()))

        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):
            if (n_gro_before_splt_all_files_dict[n_gro] \
                 + n_gro_before_ext_all_files_dict[n_gro]) == 0:
                prop_ext_all_files_dict[n_gro] = np.nan
            else:
                prop_ext_all_files_dict[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                (n_gro_before_splt_all_files_dict[n_gro] \
                 + n_gro_before_ext_all_files_dict[n_gro])





        fig = plt.figure(figsize=(8,5.0))
        plt.subplots_adjust(top=0.956, bottom=0.071, left=0.072, right=0.995, hspace=0.40, wspace=0.27)
        fontsizeX, fontsizeY, fonttitle, fontticks, fontsizetext = 9, 8, 9, 6.5, 8


        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'




        data_1_key, data_1_value = np.array(list(cum_t_n_gro_dict.keys())), list(cum_t_n_gro_dict.values())/np.sum(list(cum_t_n_gro_dict.values()))
        width = 0.3
        print (len(list(p_gro_before_ext_all_files_dict.values())))
        data_2a_key, data_2a_value = np.arange(x_lim_min-1,int(np.ceil(x_lim_max)))-width/2, list(p_gro_before_ext_all_files_dict.values())
        data_2b_key, data_2b_value = np.arange(x_lim_min-1,int(np.ceil(x_lim_max)))+width/2, list(p_gro_before_splt_all_files_dict.values())
        data_3a_key, data_3a_value = np.array(list(p_ext_given_k_gro.keys())) - width/2, np.array(list(p_ext_given_k_gro.values()))*1000
        data_3b_key, data_3b_value = np.array(list(p_splt_given_k_gro.keys())) + width/2, np.array(list(p_splt_given_k_gro.values()))*1000



        width1=0.4
        binSize = 28

        ax1 = plt.subplot(2, 3, 1)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        ax1.bar(data_1_key, data_1_value, color = 'k', width = width1)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize = 0)
        ax1.set_yticks(np.arange(0,0.5,0.02), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(x_lim_min,x_lim_max+0.0,2), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,1), minor = True)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,0.5,0.10), minor = False)
        ax1.set_title(Title[0], loc='left', fontweight='bold')
        ax1.set_ylabel('Fraction of time in $K$ classes', fontsize=fontsizeY, labelpad=13)
        #ax1.set_xlabel('# classes', fontsize=fontsizeY)
        ax1.set_xlim(x_lim_min+0.5, x_lim_max-0.5)
        ax1.set_xlabel('# classes', fontsize=fontsizeY)

        width=width
        ax2 = plt.subplot(2, 3, 2)
        ax2.spines.right.set_visible(False)
        ax2.spines.top.set_visible(False)
        ax2.bar(data_2a_key, data_2a_value, width=width, color=color3, label='extinctions')
        ax2.bar(data_2b_key, data_2b_value, width=width, color=color1, label='splits')
        ax2.set_xlim(-3, 500)
        ax2.tick_params(axis = 'y', which = 'minor', labelsize = 0)
        ax2.set_yticks(np.arange(0,0.5,0.02), minor = True)
        ax2.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax2.set_xticks(np.arange(x_lim_min,x_lim_max+0.0,2), minor = False)
        ax2.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax2.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,1), minor = True)
        ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax2.set_yticks(np.arange(0,0.5,0.10), minor = False)
        ax2.set_title(Title[1], loc='left', fontweight='bold')
        #ax2.set_xlabel('# classes', fontsize=fontsizeY)
        ax2.set_ylabel('Fraction of events in $K$ classes', fontsize=fontsizeY, labelpad=13)
        ax2.legend(frameon=False, ncol=2, fontsize=fontticks, bbox_to_anchor=(1.0, 1.07))
        ax2.set_xlim(x_lim_min+0.5,x_lim_max-0.5)
        ax2.set_xlabel('# classes', fontsize=fontsizeY)

        ax3 = plt.subplot(2, 3, 3)
        ax3.spines.right.set_visible(False)
        ax3.spines.top.set_visible(False)
        ax3.bar(data_3a_key, data_3a_value, width=width, color=color3, label='extinctions')
        ax3.bar(data_3b_key, data_3b_value, width=width, color=color1, label='split')
        ax3.tick_params(axis = 'y', which = 'minor', labelsize = 0)
        ax3.set_yticks(np.arange(0,180,10), minor = True)
        ax3.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax3.set_xticks(np.arange(x_lim_min,x_lim_max+0.0,2), minor = False)
        ax3.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax3.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,1), minor = True)
        ax3.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax3.set_yticks(np.arange(1,180,25), minor = False)
        ax3.set_title(Title[2], loc='left', fontweight='bold')
        #ax3.set_xlabel('# classes', fontsize=fontsizeY)
        ax3.set_ylabel('# events in $K$ classes / \n total time in $K$ classes '+r'$(\times 10^{-3})$', fontsize=fontsizeY, labelpad=0)
        ax3.set_xlim(x_lim_min+0.5,x_lim_max-0.5)
        ax3.set_ylim(0.05,180)
        ax3.set_yscale('log')
        ax3.set_xlabel('# classes', fontsize=fontsizeY)


        ax4 = plt.subplot(2, 3, 4)
        ax4.spines.right.set_visible(False)
        ax4.spines.top.set_visible(False)
        ax4.bar(np.arange(x_lim_min-1,int(np.ceil(x_lim_max))), list(p_ext_splt_given_k_gro.values()),
                 color = 'k', width = width) #log=True, #/np.sum(list(dt_dict.values()))/10,
        ax4.set_yscale('log')
        ax4.set_xticks(list(n_gro_before_ext_all_files_dict.keys()))
        ax4.set_xticklabels(list(n_gro_before_ext_all_files_dict.keys()), fontsize=8)
        #ax4.tick_params(axis = 'y', which = 'minor', labelsize = 0)
        #ax4.set_yticks(np.arange(0,180,10), minor = True)
        ax4.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax4.set_xticks(np.arange(x_lim_min,x_lim_max+0.0,2), minor = False)
        ax4.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax4.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,1), minor = True)
        ax4.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        #ax4.set_yticks(np.arange(1,180,25), minor = False)
        ax4.set_title(Title[3], loc='left', fontweight='bold')
        ax4.set_xlim(x_lim_min, x_lim_max)
        ax4.set_ylabel('# (splits and extinction) divided \n'+r'by time in $K$-classes', fontsize=fontsizeY, labelpad=-1)
        ax4.set_xlim(x_lim_min+0.5,x_lim_max-0.5)
        ax4.set_xlabel('# classes', fontsize=fontsizeY)



        non_classified = pickle.load(open('./unclassified_hap/num_SC_haps_all_iters_all_files_E-4_N250_a095_d_1.pkl', 'rb'))
        #print (type(non_classified), len(non_classified), non_classified)


        #Mean, Std, full_data = [], [], []
        #for ele in non_classified:
        #    full_data.extend(ele)
        #    if len(ele) > 0:
        #        Mean.append(np.round(np.mean(np.array(ele)/1000), decimals=4))
        #        Std.append(np.round(np.std(np.array(ele)/1000), decimals=4))
        #full_data = np.array(full_data)
        #print (np.array(Mean), np.array(Std))

        full_data = np.array(non_classified)
        Avg = np.round(np.mean(full_data/(2*N)), decimals=3)
        STD = np.round(np.std(full_data/(2*N)), decimals=3)
        print (Avg, STD)
        data_X, data_Y = np.unique(full_data, return_counts=True)

        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'

        ax1 = plt.subplot(2, 3, 5)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        width = 0.50
        ax1.plot(data_X/(2*N), data_Y*100/sum(data_Y))
        ax1.vlines(Avg, 0, 20.0, linestyle='dashed', color='r')
        #ax1.errorbar(range(0,len(data_X)), data_X, yerr=data_Y, elinewidth = width)
        #ax1.vlines(range(0,len(data_X)), data_X-data_Y, data_X+data_Y, linestyles='solid', linewidth=1.0, color='red', alpha=0.5)
        ax1.set_ylabel(r'PDF $(\times~ 10^{-2})$', fontsize=fontsizeY)
        ax1.set_xlabel('Fraction of SC haplotypes', fontsize=fontsizeY)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0.0,33.0,10.0), minor = False)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,33.0,10/5), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.14*2,0.1), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.13*2,0.1/4), minor = True)
        ax1.set_xlim(-0.005,0.13*2)
        ax1.set_ylim(-0.45, 33.0)
        ax1.text(Avg+0.012, 1.55, Avg, fontsize=fontsizeX-2, color='r')
        ax1.set_title(Title[4], loc='left', fontweight='bold')


        ax2 = inset_axes(ax1, 1.2, 0.8 , loc=1, bbox_to_anchor=(0.67, 0.435),bbox_transform=ax1.figure.transFigure)
        ax2.spines.right.set_visible(False)
        ax2.spines.top.set_visible(False)
        ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0.0,1.01,0.5), minor = False)
        ax2.tick_params(axis = 'y', which = 'minor', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0,1.01,0.1), minor = True)
        ax2.tick_params(axis = 'x', which = 'major', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.13*2,0.1), minor = False)
        ax2.tick_params(axis = 'x', which = 'minor', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.13*2,0.1/4), minor = True)
        ax2.set_xlim(-0.01,0.13*2)
        ax2.set_ylim(-0.015, 1.015)
        ax2.plot(data_X/(2*N), np.cumsum(data_Y/sum(data_Y)))
        #ax2.vlines(0.1, 0, 1.05, linestyle='dashed', color='k')
        #ax2.hlines(np.cumsum(data_Y/sum(data_Y))[100], 0, 0.1, linestyle='dashed', color='r')
        #ax2.text(0.123, 0.80, np.round(np.cumsum(data_Y/sum(data_Y))[100], 2), fontsize=fontsizeX-2)
        ax2.set_ylabel(r'CDF', fontsize=fontsizeX-3, labelpad=-0.5)






        non_classified = pickle.load(open('./unclassified_hap/n_non_class_hap_all_iters_all_files_E-4_N250_a095_d_1.pkl', 'rb'))
        print (type(non_classified), len(non_classified))#, non_classified)


        #Mean, Std, full_data = [], [], []
        #for ele in non_classified:
        #    full_data.extend(ele)
        #    if len(ele) > 0:
        #        Mean.append(np.round(np.mean(np.array(ele)/1000), decimals=4))
        #        Std.append(np.round(np.std(np.array(ele)/1000), decimals=4))

        #full_data = np.array(full_data)
        #print (np.array(Mean), np.array(Std))

        full_data = np.array(non_classified)
        Avg = np.round(np.mean(full_data/(2*N)), decimals=3)
        STD = np.round(np.std(full_data/(2*N)), decimals=3)
        print (Avg, STD)

        data_X, data_Y = np.unique(full_data, return_counts=True)
        print (list(data_X).index(100), np.cumsum(data_Y/sum(data_Y))[100])

        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'

        ax1 = plt.subplot(2, 3, 6)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        width = 0.50
        ax1.plot(data_X/(2*N), data_Y*100/sum(data_Y))
        ax1.vlines(Avg, 0, 5.0, linestyle='dashed', color='r')
        #ax1.errorbar(range(0,len(data_X)), data_X, yerr=data_Y, elinewidth = width)
        #ax1.vlines(range(0,len(data_X)), data_X-data_Y, data_X+data_Y, linestyles='solid', linewidth=1.0, color='red', alpha=0.5)
        ax1.set_ylabel(r'PDF $(\times~ 10^{-2})$', fontsize=fontsizeY)
        ax1.set_xlabel('Fraction of unclassified haplotypes', fontsize=fontsizeY)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0.0,19,5.0), minor = False)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,19,1), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.27*2,0.05*2), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.27*2,0.05*2/4), minor = True)
        ax1.set_xlim(-0.02,0.27*2)
        ax1.set_ylim(-0.070, 19.0)
        ax1.text(Avg+0.012, 1.55, Avg, fontsize=fontsizeX-2, color='r')
        ax1.set_title(Title[5], loc='left', fontweight='bold')


        ax2 = inset_axes(ax1, 1.2, 0.8 , loc=1, bbox_to_anchor=(1.006, 0.435),bbox_transform=ax1.figure.transFigure)
        ax2.spines.right.set_visible(False)
        ax2.spines.top.set_visible(False)
        ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0.0,1.01,0.5), minor = False)
        ax2.tick_params(axis = 'y', which = 'minor', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0,1.01,0.1), minor = True)
        ax2.tick_params(axis = 'x', which = 'major', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.27*2,0.1*2), minor = False)
        ax2.tick_params(axis = 'x', which = 'minor', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.27*2,0.05*2/4), minor = True)
        ax2.set_xlim(-0.02,0.27*2)
        ax2.set_ylim(-0.015, 1.015)
        ax2.plot(data_X/(2*N), np.cumsum(data_Y/sum(data_Y)))
        ax2.vlines(0.1, 0, 1.05, linestyle='dashed', color='k')
        #ax2.hlines(np.cumsum(data_Y/sum(data_Y))[100], 0, 0.1, linestyle='dashed', color='r')
        if data_X[list(data_X).index(50)] == 50:
            ax2.text(0.123, 0.80, np.round(np.cumsum(data_Y/sum(data_Y))[50], 2), fontsize=fontsizeX-2)
        ax2.set_ylabel(r'CDF', fontsize=fontsizeX-3, labelpad=-0.5)



        plt.savefig('../SI_figures/Fig_ext_splt_statistics_N250.pdf', transparent=True)
        #plt.show()
        plt.close()

    #E = -6, N = 750, mu = 10^-4
    if index == 4:

        E = -6; N = 750
        x_lim_min = 5
        x_lim_max = 15
        directory = './ext_split_stat/N750'


        cum_t_n_gro_dict = pickle.load(open(directory + '/cum_t_n_gro_dict.pkl', 'rb'))
        n_gro_before_splt_dict = pickle.load(open(directory + '/n_gro_before_splt_dict.pkl', 'rb'))
        n_gro_before_ext_dict = pickle.load(open(directory + '/n_gro_before_ext_dict.pkl', 'rb'))

        n_gro_before_ext_all_files_dict = {}
        n_gro_before_splt_all_files_dict = {}
        for n_gro in range(1,30):
            n_gro_before_ext_all_files_dict[n_gro] = 0
            n_gro_before_splt_all_files_dict[n_gro] = 0

        for vals in n_gro_before_ext_dict.values():
            for n_gro, num in vals.items():
                n_gro_before_ext_all_files_dict[n_gro] += num

        for vals in n_gro_before_splt_dict.values():
            for n_gro, num in vals.items():
                n_gro_before_splt_all_files_dict[n_gro] += num


        p_ext_given_k_gro = {}
        p_splt_given_k_gro = {}
        p_ext_splt_given_k_gro = {}


        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):

            if cum_t_n_gro_dict[n_gro] == 0:
                p_ext_given_k_gro[n_gro] = np.nan
                p_splt_given_k_gro[n_gro] = np.nan
                p_ext_splt_given_k_gro[n_gro] = np.nan

            else:
                p_ext_given_k_gro[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                    cum_t_n_gro_dict[n_gro]
                p_splt_given_k_gro[n_gro] = n_gro_before_splt_all_files_dict[n_gro]/ \
                    cum_t_n_gro_dict[n_gro]
                p_ext_splt_given_k_gro[n_gro] = (n_gro_before_splt_all_files_dict[n_gro] \
                     + n_gro_before_ext_all_files_dict[n_gro])/ \
                    cum_t_n_gro_dict[n_gro]

        p_gro_before_ext_all_files_dict = {}
        p_gro_before_splt_all_files_dict = {}
        prop_ext_all_files_dict = {}
        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):
            p_gro_before_ext_all_files_dict[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                np.sum(list(n_gro_before_ext_all_files_dict.values()))

            p_gro_before_splt_all_files_dict[n_gro] = n_gro_before_splt_all_files_dict[n_gro]/ \
                np.sum(list(n_gro_before_splt_all_files_dict.values()))

        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):
            if (n_gro_before_splt_all_files_dict[n_gro] \
                 + n_gro_before_ext_all_files_dict[n_gro]) == 0:
                prop_ext_all_files_dict[n_gro] = np.nan
            else:
                prop_ext_all_files_dict[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                (n_gro_before_splt_all_files_dict[n_gro] \
                 + n_gro_before_ext_all_files_dict[n_gro])





        fig = plt.figure(figsize=(8,5.0))
        plt.subplots_adjust(top=0.956, bottom=0.071, left=0.072, right=0.995, hspace=0.40, wspace=0.27)
        fontsizeX, fontsizeY, fonttitle, fontticks, fontsizetext = 9, 8, 9, 6.5, 8


        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'




        data_1_key, data_1_value = np.array(list(cum_t_n_gro_dict.keys())), list(cum_t_n_gro_dict.values())/np.sum(list(cum_t_n_gro_dict.values()))
        width = 0.3
        print (len(list(p_gro_before_ext_all_files_dict.values())))
        data_2a_key, data_2a_value = np.arange(x_lim_min-1,int(np.ceil(x_lim_max)))-width/2, list(p_gro_before_ext_all_files_dict.values())
        data_2b_key, data_2b_value = np.arange(x_lim_min-1,int(np.ceil(x_lim_max)))+width/2, list(p_gro_before_splt_all_files_dict.values())
        data_3a_key, data_3a_value = np.array(list(p_ext_given_k_gro.keys())) - width/2, np.array(list(p_ext_given_k_gro.values()))*1000
        data_3b_key, data_3b_value = np.array(list(p_splt_given_k_gro.keys())) + width/2, np.array(list(p_splt_given_k_gro.values()))*1000



        width1=0.4
        binSize = 28

        ax1 = plt.subplot(2, 3, 1)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        ax1.bar(data_1_key, data_1_value, color = 'k', width = width1)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize = 0)
        ax1.set_yticks(np.arange(0,0.32,0.01), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(x_lim_min+1.0,x_lim_max+0.0,2), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,1), minor = True)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,0.32,0.10), minor = False)
        ax1.set_title(Title[0], loc='left', fontweight='bold')
        ax1.set_ylabel('Fraction of time in $K$ classes', fontsize=fontsizeY, labelpad=13)
        #ax1.set_xlabel('# classes', fontsize=fontsizeY)
        ax1.set_xlim(x_lim_min+0.5, x_lim_max-0.5)
        ax1.set_xlabel('# classes', fontsize=fontsizeY)

        width=width
        ax2 = plt.subplot(2, 3, 2)
        ax2.spines.right.set_visible(False)
        ax2.spines.top.set_visible(False)
        ax2.bar(data_2a_key, data_2a_value, width=width, color=color3, label='extinctions')
        ax2.bar(data_2b_key, data_2b_value, width=width, color=color1, label='splits')
        ax2.set_xlim(-3, 500)
        ax2.tick_params(axis = 'y', which = 'minor', labelsize = 0)
        ax2.set_yticks(np.arange(0,0.28,0.01), minor = True)
        ax2.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax2.set_xticks(np.arange(x_lim_min+1.0,x_lim_max+0.0,2), minor = False)
        ax2.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax2.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,1), minor = True)
        ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax2.set_yticks(np.arange(0,0.28,0.10), minor = False)
        ax2.set_title(Title[1], loc='left', fontweight='bold')
        #ax2.set_xlabel('# classes', fontsize=fontsizeY)
        ax2.set_ylabel('Fraction of events in $K$ classes', fontsize=fontsizeY, labelpad=13)
        ax2.legend(frameon=False, ncol=2, fontsize=fontticks, bbox_to_anchor=(1.0, 1.07))
        ax2.set_xlim(x_lim_min+0.5,x_lim_max-0.5)
        ax2.set_xlabel('# classes', fontsize=fontsizeY)

        ax3 = plt.subplot(2, 3, 3)
        ax3.spines.right.set_visible(False)
        ax3.spines.top.set_visible(False)
        ax3.bar(data_3a_key, data_3a_value, width=width, color=color3, label='extinctions')
        ax3.bar(data_3b_key, data_3b_value, width=width, color=color1, label='split')
        ax3.tick_params(axis = 'y', which = 'minor', labelsize = 0)
        ax3.set_yticks(np.arange(0,180,10), minor = True)
        ax3.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax3.set_xticks(np.arange(x_lim_min+1.0,x_lim_max+0.0,2), minor = False)
        ax3.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax3.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,1), minor = True)
        ax3.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax3.set_yticks(np.arange(1,180,25), minor = False)
        ax3.set_title(Title[2], loc='left', fontweight='bold')
        #ax3.set_xlabel('# classes', fontsize=fontsizeY)
        ax3.set_ylabel('# events in $K$ classes / \n total time in $K$ classes '+r'$(\times 10^{-3})$', fontsize=fontsizeY, labelpad=0)
        ax3.set_xlim(x_lim_min+0.5,x_lim_max-0.5)
        ax3.set_ylim(0.05,180)
        ax3.set_yscale('log')
        ax3.set_xlabel('# classes', fontsize=fontsizeY)


        ax4 = plt.subplot(2, 3, 4)
        ax4.spines.right.set_visible(False)
        ax4.spines.top.set_visible(False)
        ax4.bar(np.arange(x_lim_min-1,int(np.ceil(x_lim_max))), list(p_ext_splt_given_k_gro.values()),
                 color = 'k', width = width) #log=True, #/np.sum(list(dt_dict.values()))/10,
        ax4.set_yscale('log')
        ax4.set_xticks(list(n_gro_before_ext_all_files_dict.keys()))
        ax4.set_xticklabels(list(n_gro_before_ext_all_files_dict.keys()), fontsize=8)
        #ax4.tick_params(axis = 'y', which = 'minor', labelsize = 0)
        #ax4.set_yticks(np.arange(0,180,10), minor = True)
        ax4.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax4.set_xticks(np.arange(x_lim_min+1.0,x_lim_max+0.0,2), minor = False)
        ax4.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax4.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,1), minor = True)
        ax4.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        #ax4.set_yticks(np.arange(1,180,25), minor = False)
        ax4.set_title(Title[3], loc='left', fontweight='bold')
        ax4.set_xlim(x_lim_min, x_lim_max)
        ax4.set_ylabel('# (splits and extinction) divided \n'+r'by time in $K$-classes', fontsize=fontsizeY, labelpad=-1)
        ax4.set_xlim(x_lim_min+0.5,x_lim_max-0.5)
        ax4.set_xlabel('# classes', fontsize=fontsizeY)



        non_classified = pickle.load(open('./unclassified_hap/num_SC_haps_all_iters_all_files_E-4_N750_a095_d_1.pkl', 'rb'))
        #print (type(non_classified), len(non_classified), non_classified)


        #Mean, Std, full_data = [], [], []
        #for ele in non_classified:
        #    full_data.extend(ele)
        #    if len(ele) > 0:
        #        Mean.append(np.round(np.mean(np.array(ele)/1000), decimals=4))
        #        Std.append(np.round(np.std(np.array(ele)/1000), decimals=4))
        #full_data = np.array(full_data)
        #print (np.array(Mean), np.array(Std))

        full_data = np.array(non_classified)
        Avg = np.round(np.mean(full_data/(2*N)), decimals=3)
        STD = np.round(np.std(full_data/(2*N)), decimals=3)
        print (Avg, STD)

        data_X, data_Y = np.unique(full_data, return_counts=True)
        #print (list(data_X).index(100), np.cumsum(data_Y/sum(data_Y))[100])

        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'

        ax1 = plt.subplot(2, 3, 5)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        width = 0.50
        ax1.plot(data_X/(2*N), data_Y*100/sum(data_Y))
        ax1.vlines(Avg, 0, 16.2, linestyle='dashed', color='r')
        #ax1.errorbar(range(0,len(data_X)), data_X, yerr=data_Y, elinewidth = width)
        #ax1.vlines(range(0,len(data_X)), data_X-data_Y, data_X+data_Y, linestyles='solid', linewidth=1.0, color='red', alpha=0.5)
        ax1.set_ylabel(r'PDF $(\times~ 10^{-2})$', fontsize=fontsizeY)
        ax1.set_xlabel('Fraction of SC haplotypes', fontsize=fontsizeY)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0.0,16.2,5), minor = False)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,16,1), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.03/1.5,0.01), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.026/1.5,0.01/4), minor = True)
        ax1.set_xlim(-0.0008,0.026/1.5)
        ax1.set_ylim(-0.25, 16)
        ax1.text(Avg+0.0008, 1.25, Avg, fontsize=fontsizeX-2, color='r')
        ax1.set_title(Title[4], loc='left', fontweight='bold')


        ax2 = inset_axes(ax1, 1.2, 0.8 , loc=1, bbox_to_anchor=(0.67, 0.435),bbox_transform=ax1.figure.transFigure)
        ax2.spines.right.set_visible(False)
        ax2.spines.top.set_visible(False)
        ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0.0,1.01,0.5), minor = False)
        ax2.tick_params(axis = 'y', which = 'minor', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0,1.01,0.1), minor = True)
        ax2.tick_params(axis = 'x', which = 'major', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.026,0.01), minor = False)
        ax2.tick_params(axis = 'x', which = 'minor', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.026,0.01/4), minor = True)
        ax2.set_xlim(-0.0008,0.026/1.5)
        ax2.set_ylim(-0.015, 1.015)
        ax2.plot(data_X/(2*N), np.cumsum(data_Y/sum(data_Y)))
        #ax2.vlines(0.1, 0, 1.05, linestyle='dashed', color='k')
        #ax2.hlines(np.cumsum(data_Y/sum(data_Y))[100], 0, 0.1, linestyle='dashed', color='r')
        #ax2.text(0.123, 0.77, np.round(np.cumsum(data_Y/sum(data_Y))[100], 2), fontsize=fontsizeX-2)
        ax2.set_ylabel(r'CDF', fontsize=fontsizeX-3, labelpad=-0.5)






        non_classified = pickle.load(open('./unclassified_hap/n_non_class_hap_all_iters_all_files_E-4_N750_a095_d_1.pkl', 'rb'))
        #print (type(non_classified), len(non_classified))


        #Mean, Std, full_data = [], [], []
        #for ele in non_classified:
        #    full_data.extend(ele)
        #    if len(ele) > 0:
        #        Mean.append(np.round(np.mean(np.array(ele)/1000), decimals=4))
        #        Std.append(np.round(np.std(np.array(ele)/1000), decimals=4))
        #full_data = np.array(full_data)
        #print (np.array(Mean), np.array(Std))
        full_data = np.array(non_classified)
        Avg = np.round(np.mean(full_data/(2*N)), decimals=3)
        STD = np.round(np.std(full_data/(2*N)), decimals=3)
        print (Avg, STD)

        data_X, data_Y = np.unique(full_data, return_counts=True)
        print (list(data_X).index(100), np.cumsum(data_Y/sum(data_Y))[100])

        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'

        ax1 = plt.subplot(2, 3, 6)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        width = 0.50
        ax1.plot(data_X/(2*N), data_Y*100/sum(data_Y))
        ax1.vlines(Avg, 0, 1.2, linestyle='dashed', color='r')
        #ax1.errorbar(range(0,len(data_X)), data_X, yerr=data_Y, elinewidth = width)
        #ax1.vlines(range(0,len(data_X)), data_X-data_Y, data_X+data_Y, linestyles='solid', linewidth=1.0, color='red', alpha=0.5)
        ax1.set_ylabel(r'PDF $(\times~ 10^{-2})$', fontsize=fontsizeY)
        ax1.set_xlabel('Fraction of unclassified haplotypes', fontsize=fontsizeY)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0.0,2.2,0.5), minor = False)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,2.2,0.1), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.57/1.5,0.1), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.57/1.5,0.05/2), minor = True)
        ax1.set_xlim(-0.008,0.58/1.5)
        ax1.set_ylim(-0.070, 2.3)
        ax1.text(Avg-0.018, 1.25, Avg, fontsize=fontsizeX-2, color='r')
        ax1.set_title(Title[5], loc='left', fontweight='bold')


        ax2 = inset_axes(ax1, 1.2, 0.8 , loc=1, bbox_to_anchor=(1.000, 0.435),bbox_transform=ax1.figure.transFigure)
        ax2.spines.right.set_visible(False)
        ax2.spines.top.set_visible(False)
        ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0.0,1.01,0.5), minor = False)
        ax2.tick_params(axis = 'y', which = 'minor', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0,1.01,0.1), minor = True)
        ax2.tick_params(axis = 'x', which = 'major', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.57/1.5,0.1), minor = False)
        ax2.tick_params(axis = 'x', which = 'minor', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.57/1.5,0.05/2), minor = True)
        ax2.set_xlim(-0.008,0.58/1.5)
        ax2.set_ylim(-0.015, 1.015)
        ax2.plot(data_X/(2*N), np.cumsum(data_Y/sum(data_Y)))
        ax2.vlines(0.1, 0, 1.05, linestyle='dashed', color='k')
        #ax2.hlines(np.cumsum(data_Y/sum(data_Y))[100], 0, 0.1, linestyle='dashed', color='r')
        if data_X[list(data_X).index(150)] == 150:
            ax2.text(0.123, 0.77, np.round(np.cumsum(data_Y/sum(data_Y))[list(data_X).index(150)], 2), fontsize=fontsizeX-2)
        ax2.set_ylabel(r'CDF', fontsize=fontsizeX-3, labelpad=-0.5)



        plt.savefig('../SI_figures/Fig_ext_splt_statistics_N750.pdf', transparent=True)
        #plt.show()
        plt.close()

    #E = -6, N = 500, alpha = 0.8, alpha = 0.9
    if index == 5:

        E = -6; N = 500
        x_lim_min = 3
        x_lim_max = 15
        directory = './ext_split_stat/alpha08delta09'


        cum_t_n_gro_dict = pickle.load(open(directory + '/cum_t_n_gro_dict.pkl', 'rb'))
        n_gro_before_splt_dict = pickle.load(open(directory + '/n_gro_before_splt_dict.pkl', 'rb'))
        n_gro_before_ext_dict = pickle.load(open(directory + '/n_gro_before_ext_dict.pkl', 'rb'))

        n_gro_before_ext_all_files_dict = {}
        n_gro_before_splt_all_files_dict = {}
        for n_gro in range(1,30):
            n_gro_before_ext_all_files_dict[n_gro] = 0
            n_gro_before_splt_all_files_dict[n_gro] = 0

        for vals in n_gro_before_ext_dict.values():
            for n_gro, num in vals.items():
                n_gro_before_ext_all_files_dict[n_gro] += num

        for vals in n_gro_before_splt_dict.values():
            for n_gro, num in vals.items():
                n_gro_before_splt_all_files_dict[n_gro] += num


        p_ext_given_k_gro = {}
        p_splt_given_k_gro = {}
        p_ext_splt_given_k_gro = {}


        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):

            if cum_t_n_gro_dict[n_gro] == 0:
                p_ext_given_k_gro[n_gro] = np.nan
                p_splt_given_k_gro[n_gro] = np.nan
                p_ext_splt_given_k_gro[n_gro] = np.nan

            else:
                p_ext_given_k_gro[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                    cum_t_n_gro_dict[n_gro]
                p_splt_given_k_gro[n_gro] = n_gro_before_splt_all_files_dict[n_gro]/ \
                    cum_t_n_gro_dict[n_gro]
                p_ext_splt_given_k_gro[n_gro] = (n_gro_before_splt_all_files_dict[n_gro] \
                     + n_gro_before_ext_all_files_dict[n_gro])/ \
                    cum_t_n_gro_dict[n_gro]

        p_gro_before_ext_all_files_dict = {}
        p_gro_before_splt_all_files_dict = {}
        prop_ext_all_files_dict = {}
        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):
            p_gro_before_ext_all_files_dict[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                np.sum(list(n_gro_before_ext_all_files_dict.values()))

            p_gro_before_splt_all_files_dict[n_gro] = n_gro_before_splt_all_files_dict[n_gro]/ \
                np.sum(list(n_gro_before_splt_all_files_dict.values()))

        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):
            if (n_gro_before_splt_all_files_dict[n_gro] \
                 + n_gro_before_ext_all_files_dict[n_gro]) == 0:
                prop_ext_all_files_dict[n_gro] = np.nan
            else:
                prop_ext_all_files_dict[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                (n_gro_before_splt_all_files_dict[n_gro] \
                 + n_gro_before_ext_all_files_dict[n_gro])





        fig = plt.figure(figsize=(8,2.5))
        plt.subplots_adjust(top=0.910, bottom=0.14, left=0.056, right=0.995, hspace=0.40, wspace=0.27)
        fontsizeX, fontsizeY, fonttitle, fontticks, fontsizetext = 9, 8, 9, 6.5, 8


        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'




        data_1_key, data_1_value = np.array(list(cum_t_n_gro_dict.keys())), list(cum_t_n_gro_dict.values())/np.sum(list(cum_t_n_gro_dict.values()))
        width = 0.3
        print (len(list(p_gro_before_ext_all_files_dict.values())))
        data_2a_key, data_2a_value = np.arange(x_lim_min-1,int(np.ceil(x_lim_max)))-width/2, list(p_gro_before_ext_all_files_dict.values())
        data_2b_key, data_2b_value = np.arange(x_lim_min-1,int(np.ceil(x_lim_max)))+width/2, list(p_gro_before_splt_all_files_dict.values())
        data_3a_key, data_3a_value = np.array(list(p_ext_given_k_gro.keys())) - width/2, np.array(list(p_ext_given_k_gro.values()))*1000
        data_3b_key, data_3b_value = np.array(list(p_splt_given_k_gro.keys())) + width/2, np.array(list(p_splt_given_k_gro.values()))*1000



        width1=0.4
        binSize = 28

        ax1 = plt.subplot(1, 3, 1)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        ax1.bar(data_1_key, data_1_value, color = 'k', width = width1)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize = 0)
        ax1.set_yticks(np.arange(0,0.32,0.01), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(x_lim_min+1,x_lim_max+0.0,2), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,1), minor = True)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,0.32,0.10), minor = False)
        ax1.set_title(Title[0], loc='left', fontweight='bold')
        ax1.set_ylabel('Fraction of time in $K$ classes', fontsize=fontsizeY, labelpad=5)
        #ax1.set_xlabel('# classes', fontsize=fontsizeY)
        ax1.set_xlim(x_lim_min+0.5, x_lim_max-0.5)
        ax1.set_xlabel('# classes', fontsize=fontsizeY)


        non_classified = pickle.load(open('./unclassified_hap/num_SC_haps_all_iters_all_files_E-6_N500_a08_d_09.pkl', 'rb'))
        print (type(non_classified), len(non_classified))


        Mean, Std, full_data = [], [], []
        for ele in non_classified:
            full_data.extend(ele)
            if len(ele) > 0:
                Mean.append(np.round(np.mean(np.array(ele)/1000), decimals=4))
                Std.append(np.round(np.std(np.array(ele)/1000), decimals=4))

        full_data = np.array(full_data)
        print (np.array(Mean), np.array(Std))

        Avg = np.round(np.mean(full_data/1000), decimals=3)
        STD = np.round(np.std(full_data/1000), decimals=3)
        print (Avg, STD)

        data_X, data_Y = np.unique(full_data, return_counts=True)
        print (list(data_X).index(100), np.cumsum(data_Y/sum(data_Y))[100])

        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'

        ax1 = plt.subplot(1, 3, 2)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        width = 0.50
        ax1.plot(data_X/1000, data_Y*100/sum(data_Y))
        ax1.vlines(Avg, 0, 4.0, linestyle='dashed', color='r')
        #ax1.errorbar(range(0,len(data_X)), data_X, yerr=data_Y, elinewidth = width)
        #ax1.vlines(range(0,len(data_X)), data_X-data_Y, data_X+data_Y, linestyles='solid', linewidth=1.0, color='red', alpha=0.5)
        ax1.set_ylabel(r'PDF $(\times~ 10^{-2})$', fontsize=fontsizeY)
        ax1.set_xlabel('Fraction of SC haplotypes', fontsize=fontsizeY)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0.0,7.0,2.0), minor = False)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,8,0.5/2), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.55,0.1), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.58,0.05/2), minor = True)
        ax1.set_xlim(-0.01,0.57)
        ax1.set_ylim(-0.10, 7.7)
        ax1.text(Avg+0.025, 3.0, Avg, fontsize=fontsizeX-2, color='r')
        ax1.set_title(Title[1], loc='left', fontweight='bold')


        ax2 = inset_axes(ax1, 1.2, 0.8 , loc=1, bbox_to_anchor=(0.66, 0.95),bbox_transform=ax1.figure.transFigure)
        ax2.spines.right.set_visible(False)
        ax2.spines.top.set_visible(False)
        ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0.0,1.01,0.5), minor = False)
        ax2.tick_params(axis = 'y', which = 'minor', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0,1.01,0.1), minor = True)
        ax2.tick_params(axis = 'x', which = 'major', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.55,0.1), minor = False)
        ax2.tick_params(axis = 'x', which = 'minor', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.58,0.05/1), minor = True)
        ax2.set_xlim(-0.008,0.47)
        ax2.set_ylim(-0.015, 1.015)
        ax2.plot(data_X/1000, np.cumsum(data_Y/sum(data_Y)))
        #ax2.vlines(0.1, 0, 1.05, linestyle='dashed', color='k')
        #ax2.hlines(np.cumsum(data_Y/sum(data_Y))[100], 0, 0.1, linestyle='dashed', color='r')
        #ax2.text(0.123, 0.77, np.round(np.cumsum(data_Y/sum(data_Y))[100], 2), fontsize=fontsizeX-2)
        ax2.set_ylabel(r'CDF', fontsize=fontsizeX-3, labelpad=-0.5)






        non_classified = pickle.load(open('./unclassified_hap/n_non_class_hap_all_iters_all_files_E-6_N500_a08_d_09.pkl', 'rb'))
        print (type(non_classified), len(non_classified))


        Mean, Std, full_data = [], [], []
        for ele in non_classified:
            full_data.extend(ele)
            if len(ele) > 0:
                Mean.append(np.round(np.mean(np.array(ele)/1000), decimals=4))
                Std.append(np.round(np.std(np.array(ele)/1000), decimals=4))

        full_data = np.array(full_data)
        print (np.array(Mean), np.array(Std))

        Avg = np.round(np.mean(full_data/1000), decimals=3)
        STD = np.round(np.std(full_data/1000), decimals=3)
        print (Avg, STD)

        data_X, data_Y = np.unique(full_data, return_counts=True)
        print (list(data_X).index(100), np.cumsum(data_Y/sum(data_Y))[100])

        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'

        ax1 = plt.subplot(1, 3, 3)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        width = 0.50
        ax1.plot(data_X/1000, data_Y*100/sum(data_Y))
        ax1.vlines(Avg, 0, 1.2, linestyle='dashed', color='r')
        #ax1.errorbar(range(0,len(data_X)), data_X, yerr=data_Y, elinewidth = width)
        #ax1.vlines(range(0,len(data_X)), data_X-data_Y, data_X+data_Y, linestyles='solid', linewidth=1.0, color='red', alpha=0.5)
        ax1.set_ylabel(r'PDF $(\times~ 10^{-2})$', fontsize=fontsizeY)
        ax1.set_xlabel('Fraction of unclassified haplotypes', fontsize=fontsizeY)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0.0,2.2,0.5), minor = False)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,2.2,0.1), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.73,0.2), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.73,0.05/2), minor = True)
        ax1.set_xlim(-0.016,0.73)
        ax1.set_ylim(-0.040, 2.0)
        ax1.text(Avg+0.018, 1.25, Avg, fontsize=fontsizeX-2, color='r')
        ax1.set_title(Title[2], loc='left', fontweight='bold')


        ax2 = inset_axes(ax1, 1.2, 0.8 , loc=1, bbox_to_anchor=(1.006, 0.95),bbox_transform=ax1.figure.transFigure)
        ax2.spines.right.set_visible(False)
        ax2.spines.top.set_visible(False)
        ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0.0,1.01,0.5), minor = False)
        ax2.tick_params(axis = 'y', which = 'minor', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0,1.01,0.1), minor = True)
        ax2.tick_params(axis = 'x', which = 'major', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.73,0.2), minor = False)
        ax2.tick_params(axis = 'x', which = 'minor', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.73,0.05/2), minor = True)
        ax2.set_xlim(-0.016,0.73)
        ax2.set_ylim(-0.015, 1.015)
        ax2.plot(data_X/1000, np.cumsum(data_Y/sum(data_Y)))
        ax2.vlines(0.1, 0, 1.05, linestyle='dashed', color='k')
        #ax2.hlines(np.cumsum(data_Y/sum(data_Y))[100], 0, 0.1, linestyle='dashed', color='r')
        ax2.text(0.123, 0.77, np.round(np.cumsum(data_Y/sum(data_Y))[100], 2), fontsize=fontsizeX-2)
        ax2.set_ylabel(r'CDF', fontsize=fontsizeX-3, labelpad=-0.5)


        plt.savefig('../SI_figures/Fig_ext_splt_statistics_alpha08delta09.pdf', transparent=True)
        #plt.show()
        plt.close()

    #E = -6, N = 500, mu = 2*10^-4
    if index == 6:

        E = -6; N = 500
        x_lim_min = 5
        x_lim_max = 14
        directory = './ext_split_stat/twicemutation'


        cum_t_n_gro_dict = pickle.load(open(directory + '/cum_t_n_gro_dict.pkl', 'rb'))
        n_gro_before_splt_dict = pickle.load(open(directory + '/n_gro_before_splt_dict.pkl', 'rb'))
        n_gro_before_ext_dict = pickle.load(open(directory + '/n_gro_before_ext_dict.pkl', 'rb'))

        n_gro_before_ext_all_files_dict = {}
        n_gro_before_splt_all_files_dict = {}
        for n_gro in range(1,30):
            n_gro_before_ext_all_files_dict[n_gro] = 0
            n_gro_before_splt_all_files_dict[n_gro] = 0

        for vals in n_gro_before_ext_dict.values():
            for n_gro, num in vals.items():
                n_gro_before_ext_all_files_dict[n_gro] += num

        for vals in n_gro_before_splt_dict.values():
            for n_gro, num in vals.items():
                n_gro_before_splt_all_files_dict[n_gro] += num


        p_ext_given_k_gro = {}
        p_splt_given_k_gro = {}
        p_ext_splt_given_k_gro = {}


        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):

            if cum_t_n_gro_dict[n_gro] == 0:
                p_ext_given_k_gro[n_gro] = np.nan
                p_splt_given_k_gro[n_gro] = np.nan
                p_ext_splt_given_k_gro[n_gro] = np.nan

            else:
                p_ext_given_k_gro[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                    cum_t_n_gro_dict[n_gro]
                p_splt_given_k_gro[n_gro] = n_gro_before_splt_all_files_dict[n_gro]/ \
                    cum_t_n_gro_dict[n_gro]
                p_ext_splt_given_k_gro[n_gro] = (n_gro_before_splt_all_files_dict[n_gro] \
                     + n_gro_before_ext_all_files_dict[n_gro])/ \
                    cum_t_n_gro_dict[n_gro]

        p_gro_before_ext_all_files_dict = {}
        p_gro_before_splt_all_files_dict = {}
        prop_ext_all_files_dict = {}
        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):
            p_gro_before_ext_all_files_dict[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                np.sum(list(n_gro_before_ext_all_files_dict.values()))

            p_gro_before_splt_all_files_dict[n_gro] = n_gro_before_splt_all_files_dict[n_gro]/ \
                np.sum(list(n_gro_before_splt_all_files_dict.values()))

        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):
            if (n_gro_before_splt_all_files_dict[n_gro] \
                 + n_gro_before_ext_all_files_dict[n_gro]) == 0:
                prop_ext_all_files_dict[n_gro] = np.nan
            else:
                prop_ext_all_files_dict[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                (n_gro_before_splt_all_files_dict[n_gro] \
                 + n_gro_before_ext_all_files_dict[n_gro])





        fig = plt.figure(figsize=(8,2.5))
        plt.subplots_adjust(top=0.910, bottom=0.14, left=0.056, right=0.995, hspace=0.40, wspace=0.27)
        fontsizeX, fontsizeY, fonttitle, fontticks, fontsizetext = 9, 8, 9, 6.5, 8


        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'




        data_1_key, data_1_value = np.array(list(cum_t_n_gro_dict.keys())), list(cum_t_n_gro_dict.values())/np.sum(list(cum_t_n_gro_dict.values()))
        width = 0.3
        print (len(list(p_gro_before_ext_all_files_dict.values())))
        data_2a_key, data_2a_value = np.arange(x_lim_min-1,int(np.ceil(x_lim_max)))-width/2, list(p_gro_before_ext_all_files_dict.values())
        data_2b_key, data_2b_value = np.arange(x_lim_min-1,int(np.ceil(x_lim_max)))+width/2, list(p_gro_before_splt_all_files_dict.values())
        data_3a_key, data_3a_value = np.array(list(p_ext_given_k_gro.keys())) - width/2, np.array(list(p_ext_given_k_gro.values()))*1000
        data_3b_key, data_3b_value = np.array(list(p_splt_given_k_gro.keys())) + width/2, np.array(list(p_splt_given_k_gro.values()))*1000



        width1=0.4
        binSize = 28

        ax1 = plt.subplot(1, 3, 1)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        ax1.bar(data_1_key, data_1_value, color = 'k', width = width1)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize = 0)
        ax1.set_yticks(np.arange(0,0.37,0.01), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(x_lim_min+1.0,x_lim_max+0.0,2), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,1), minor = True)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,0.32,0.10), minor = False)
        ax1.set_title(Title[0], loc='left', fontweight='bold')
        ax1.set_ylabel('Fraction of time in $K$ classes', fontsize=fontsizeY, labelpad=5)
        #ax1.set_xlabel('# classes', fontsize=fontsizeY)
        ax1.set_xlim(x_lim_min+0.5, x_lim_max-0.5)
        ax1.set_xlabel('# classes', fontsize=fontsizeY)



        non_classified = pickle.load(open('./unclassified_hap/num_SC_haps_all_iters_all_files_E-4_N500_a095_d_1_2mu.pkl', 'rb'))
        print (type(non_classified), len(non_classified))


        Mean, Std, full_data = [], [], []
        for ele in non_classified:
            full_data.extend(ele)
            if len(ele) > 0:
                Mean.append(np.round(np.mean(np.array(ele)/1000), decimals=4))
                Std.append(np.round(np.std(np.array(ele)/1000), decimals=4))

        full_data = np.array(full_data)
        print (np.array(Mean), np.array(Std))

        Avg = np.round(np.mean(full_data/1000), decimals=3)
        STD = np.round(np.std(full_data/1000), decimals=3)
        print (Avg, STD)

        data_X, data_Y = np.unique(full_data, return_counts=True)
        print (max(data_X)/1000, 'max of x ticks')

        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'

        ax1 = plt.subplot(1, 3, 2)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        width = 0.50
        ax1.plot(data_X/1000, data_Y*100/sum(data_Y))
        ax1.vlines(Avg, 0, 13.5, linestyle='dashed', color='r')
        #ax1.errorbar(range(0,len(data_X)), data_X, yerr=data_Y, elinewidth = width)
        #ax1.vlines(range(0,len(data_X)), data_X-data_Y, data_X+data_Y, linestyles='solid', linewidth=1.0, color='red', alpha=0.5)
        ax1.set_ylabel(r'PDF $(\times~ 10^{-2})$', fontsize=fontsizeY)
        ax1.set_xlabel('Fraction of SC haplotypes', fontsize=fontsizeY)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0.0,15,5), minor = False)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,15,1), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.021,0.01/2), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.021,0.01/10), minor = True)
        ax1.set_xlim(-0.0005,0.022)
        ax1.set_ylim(-0.15, 16)
        ax1.text(Avg*1.2, 1.25, Avg, fontsize=fontsizeX-2, color='r')
        ax1.set_title(Title[1], loc='left', fontweight='bold')


        ax2 = inset_axes(ax1, 1.2, 0.8 , loc=1, bbox_to_anchor=(0.66, 0.95),bbox_transform=ax1.figure.transFigure)
        ax2.spines.right.set_visible(False)
        ax2.spines.top.set_visible(False)
        ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0.0,1.01,0.5), minor = False)
        ax2.tick_params(axis = 'y', which = 'minor', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0,1.01,0.1), minor = True)
        ax2.tick_params(axis = 'x', which = 'major', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.021,0.02/2), minor = False)
        ax2.tick_params(axis = 'x', which = 'minor', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.021,0.01/4), minor = True)
        ax2.set_xlim(-0.0005,0.022)
        ax2.set_ylim(-0.015, 1.015)
        ax2.plot(data_X/1000, np.cumsum(data_Y/sum(data_Y)))
        #ax2.vlines(0.1, 0, 1.05, linestyle='dashed', color='k')
        #ax2.hlines(np.cumsum(data_Y/sum(data_Y))[100], 0, 0.1, linestyle='dashed', color='r')
        #ax2.text(0.123, 0.77, np.round(np.cumsum(data_Y/sum(data_Y))[100], 2), fontsize=fontsizeX-2)
        ax2.set_ylabel(r'CDF', fontsize=fontsizeX-3, labelpad=-0.5)






        non_classified = pickle.load(open('./unclassified_hap/n_non_class_hap_all_iters_all_files_E-4_N500_a095_d_1_2mu.pkl', 'rb'))
        print (type(non_classified), len(non_classified))


        Mean, Std, full_data = [], [], []
        for ele in non_classified:
            full_data.extend(ele)
            if len(ele) > 0:
                Mean.append(np.round(np.mean(np.array(ele)/1000), decimals=4))
                Std.append(np.round(np.std(np.array(ele)/1000), decimals=4))

        full_data = np.array(full_data)
        print (np.array(Mean), np.array(Std))

        Avg = np.round(np.mean(full_data/1000), decimals=3)
        STD = np.round(np.std(full_data/1000), decimals=3)
        print (Avg, STD)

        data_X, data_Y = np.unique(full_data, return_counts=True)
        data_XX, data_YY, binSize = bin_Control(np.concatenate(([data_X], [data_Y])).T, 100, 1)
        print (data_XX, data_YY)
        print (list(data_X).index(100), np.cumsum(data_Y/sum(data_Y))[100])

        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'

        ax1 = plt.subplot(1, 3, 3)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        width = 0.50
        #ax1.plot(data_XX/1000, data_YY*100/sum(data_Y))
        ax1.plot(data_XX/1000, data_YY*100)
        ax1.vlines(Avg, 0, 3.2, linestyle='dashed', color='r')
        #ax1.errorbar(range(0,len(data_X)), data_X, yerr=data_Y, elinewidth = width)
        #ax1.vlines(range(0,len(data_X)), data_X-data_Y, data_X+data_Y, linestyles='solid', linewidth=1.0, color='red', alpha=0.5)
        ax1.set_ylabel(r'PDF $(\times~ 10^{-2})$', fontsize=fontsizeY)
        ax1.set_xlabel('Fraction of unclassified haplotypes', fontsize=fontsizeY)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0.0,3.5,1), minor = False)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,3.5,0.1), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.41,0.1), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.4,0.05/2), minor = True)
        ax1.set_xlim(-0.008,0.41)
        ax1.set_ylim(-0.070, 3.5)
        ax1.text(Avg+0.02, .2, Avg, fontsize=fontsizeX-2, color='r')
        ax1.set_title(Title[2], loc='left', fontweight='bold')


        ax2 = inset_axes(ax1, 1.2, 0.8 , loc=1, bbox_to_anchor=(1.006, 0.95),bbox_transform=ax1.figure.transFigure)
        ax2.spines.right.set_visible(False)
        ax2.spines.top.set_visible(False)
        ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0.0,1.01,0.5), minor = False)
        ax2.tick_params(axis = 'y', which = 'minor', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0,1.01,0.1), minor = True)
        ax2.tick_params(axis = 'x', which = 'major', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.47,0.1), minor = False)
        ax2.tick_params(axis = 'x', which = 'minor', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.47,0.05/2), minor = True)
        ax2.set_xlim(-0.008,0.47)
        ax2.set_ylim(-0.015, 1.015)
        ax2.plot(data_X/1000, np.cumsum(data_Y/sum(data_Y)))
        ax2.vlines(0.1, 0, 1.05, linestyle='dashed', color='k')
        #ax2.hlines(np.cumsum(data_Y/sum(data_Y))[100], 0, 0.1, linestyle='dashed', color='r')
        ax2.text(0.123, 0.77, np.round(np.cumsum(data_Y/sum(data_Y))[100], 2), fontsize=fontsizeX-2)
        ax2.set_ylabel(r'CDF', fontsize=fontsizeX-3, labelpad=-0.5)


        plt.savefig('../SI_figures/Fig_ext_splt_statistics_twicemutation.pdf', transparent=True)
        #plt.show()
        plt.close()

    #E = -6, N = 500, mu = 0.5*10^-4
    if index == 7:

        E = -6; N = 500
        x_lim_min = 3
        x_lim_max = 12
        directory = './ext_split_stat/halfmutation'


        cum_t_n_gro_dict = pickle.load(open(directory + '/cum_t_n_gro_dict.pkl', 'rb'))
        n_gro_before_splt_dict = pickle.load(open(directory + '/n_gro_before_splt_dict.pkl', 'rb'))
        n_gro_before_ext_dict = pickle.load(open(directory + '/n_gro_before_ext_dict.pkl', 'rb'))

        n_gro_before_ext_all_files_dict = {}
        n_gro_before_splt_all_files_dict = {}
        for n_gro in range(1,30):
            n_gro_before_ext_all_files_dict[n_gro] = 0
            n_gro_before_splt_all_files_dict[n_gro] = 0

        for vals in n_gro_before_ext_dict.values():
            for n_gro, num in vals.items():
                n_gro_before_ext_all_files_dict[n_gro] += num

        for vals in n_gro_before_splt_dict.values():
            for n_gro, num in vals.items():
                n_gro_before_splt_all_files_dict[n_gro] += num


        p_ext_given_k_gro = {}
        p_splt_given_k_gro = {}
        p_ext_splt_given_k_gro = {}


        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):

            if cum_t_n_gro_dict[n_gro] == 0:
                p_ext_given_k_gro[n_gro] = np.nan
                p_splt_given_k_gro[n_gro] = np.nan
                p_ext_splt_given_k_gro[n_gro] = np.nan

            else:
                p_ext_given_k_gro[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                    cum_t_n_gro_dict[n_gro]
                p_splt_given_k_gro[n_gro] = n_gro_before_splt_all_files_dict[n_gro]/ \
                    cum_t_n_gro_dict[n_gro]
                p_ext_splt_given_k_gro[n_gro] = (n_gro_before_splt_all_files_dict[n_gro] \
                     + n_gro_before_ext_all_files_dict[n_gro])/ \
                    cum_t_n_gro_dict[n_gro]

        p_gro_before_ext_all_files_dict = {}
        p_gro_before_splt_all_files_dict = {}
        prop_ext_all_files_dict = {}
        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):
            p_gro_before_ext_all_files_dict[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                np.sum(list(n_gro_before_ext_all_files_dict.values()))

            p_gro_before_splt_all_files_dict[n_gro] = n_gro_before_splt_all_files_dict[n_gro]/ \
                np.sum(list(n_gro_before_splt_all_files_dict.values()))

        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):
            if (n_gro_before_splt_all_files_dict[n_gro] \
                 + n_gro_before_ext_all_files_dict[n_gro]) == 0:
                prop_ext_all_files_dict[n_gro] = np.nan
            else:
                prop_ext_all_files_dict[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                (n_gro_before_splt_all_files_dict[n_gro] \
                 + n_gro_before_ext_all_files_dict[n_gro])





        fig = plt.figure(figsize=(8,2.5))
        plt.subplots_adjust(top=0.910, bottom=0.14, left=0.056, right=0.995, hspace=0.40, wspace=0.27)
        fontsizeX, fontsizeY, fonttitle, fontticks, fontsizetext = 9, 8, 9, 6.5, 8


        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'




        data_1_key, data_1_value = np.array(list(cum_t_n_gro_dict.keys())), list(cum_t_n_gro_dict.values())/np.sum(list(cum_t_n_gro_dict.values()))
        width = 0.3
        print (len(list(p_gro_before_ext_all_files_dict.values())))
        data_2a_key, data_2a_value = np.arange(x_lim_min-1,int(np.ceil(x_lim_max)))-width/2, list(p_gro_before_ext_all_files_dict.values())
        data_2b_key, data_2b_value = np.arange(x_lim_min-1,int(np.ceil(x_lim_max)))+width/2, list(p_gro_before_splt_all_files_dict.values())
        data_3a_key, data_3a_value = np.array(list(p_ext_given_k_gro.keys())) - width/2, np.array(list(p_ext_given_k_gro.values()))*1000
        data_3b_key, data_3b_value = np.array(list(p_splt_given_k_gro.keys())) + width/2, np.array(list(p_splt_given_k_gro.values()))*1000



        width1=0.4
        binSize = 28

        ax1 = plt.subplot(1, 3, 1)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        ax1.bar(data_1_key, data_1_value, color = 'k', width = width1)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize = 0)
        ax1.set_yticks(np.arange(0,0.32,0.01), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(x_lim_min+1.0,x_lim_max+0.0,2), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,1), minor = True)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,0.32,0.10), minor = False)
        ax1.set_title(Title[0], loc='left', fontweight='bold')
        ax1.set_ylabel('Fraction of time in $K$ classes', fontsize=fontsizeY, labelpad=5)
        #ax1.set_xlabel('# classes', fontsize=fontsizeY)
        ax1.set_xlim(x_lim_min+0.5, x_lim_max-1.5)
        ax1.set_xlabel('# classes', fontsize=fontsizeY)




        non_classified = pickle.load(open('./unclassified_hap/num_SC_haps_all_iters_all_files_E-4_N500_a095_d_1_05mu.pkl', 'rb'))
        print (type(non_classified), len(non_classified))


        Mean, Std, full_data = [], [], []
        for ele in non_classified:
            full_data.extend(ele)
            if len(ele) > 0:
                Mean.append(np.round(np.mean(np.array(ele)/1000), decimals=4))
                Std.append(np.round(np.std(np.array(ele)/1000), decimals=4))

        full_data = np.array(full_data)
        print (np.array(Mean), np.array(Std))

        Avg = np.round(np.mean(full_data/1000), decimals=3)
        STD = np.round(np.std(full_data/1000), decimals=3)
        print (Avg, STD, '\n')

        data_X, data_Y = np.unique(full_data, return_counts=True)
        #print (max(data_X)/1000, 'max of x ticks')

        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'

        ax1 = plt.subplot(1, 3, 2)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        width = 0.50
        ax1.plot(data_X/1000, data_Y*100/sum(data_Y))
        ax1.vlines(Avg, 0, 20.0, linestyle='dashed', color='r')
        #ax1.errorbar(range(0,len(data_X)), data_X, yerr=data_Y, elinewidth = width)
        #ax1.vlines(range(0,len(data_X)), data_X-data_Y, data_X+data_Y, linestyles='solid', linewidth=1.0, color='red', alpha=0.5)
        ax1.set_ylabel(r'PDF $(\times~ 10^{-2})$', fontsize=fontsizeY)
        ax1.set_xlabel('Fraction of SC haplotypes', fontsize=fontsizeY)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0.0,35.0,10), minor = False)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,37.0,10/4), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.23,0.05), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.23,0.05/4), minor = True)
        ax1.set_xlim(-0.005,0.23)
        ax1.set_ylim(-0.5, 37)
        ax1.text(Avg+0.010, 8.5, Avg, fontsize=fontsizeX-2, color='r')
        ax1.set_title(Title[1], loc='left', fontweight='bold')


        ax2 = inset_axes(ax1, 1.2, 0.8 , loc=1, bbox_to_anchor=(0.66, 0.95),bbox_transform=ax1.figure.transFigure)
        ax2.spines.right.set_visible(False)
        ax2.spines.top.set_visible(False)
        ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0.0,1.01,0.5), minor = False)
        ax2.tick_params(axis = 'y', which = 'minor', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0,1.01,0.1), minor = True)
        ax2.tick_params(axis = 'x', which = 'major', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.23,0.05), minor = False)
        ax2.tick_params(axis = 'x', which = 'minor', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.23,0.05/2), minor = True)
        ax2.set_xlim(-0.005,0.23)
        ax2.set_ylim(-0.015, 1.015)
        ax2.plot(data_X/1000, np.cumsum(data_Y/sum(data_Y)))
        #ax2.vlines(0.1, 0, 1.05, linestyle='dashed', color='k')
        #ax2.hlines(np.cumsum(data_Y/sum(data_Y))[100], 0, 0.1, linestyle='dashed', color='r')
        #ax2.text(0.123, 0.77, np.round(np.cumsum(data_Y/sum(data_Y))[100], 2), fontsize=fontsizeX-2)
        ax2.set_ylabel(r'CDF', fontsize=fontsizeX-3, labelpad=-0.5)






        non_classified = pickle.load(open('./unclassified_hap/n_non_class_hap_all_iters_all_files_E-4_N500_a095_d_1_05mu.pkl', 'rb'))
        #print (type(non_classified), len(non_classified))


        Mean, Std, full_data = [], [], []
        for ele in non_classified:
            full_data.extend(ele)
            if len(ele) > 0:
                Mean.append(np.round(np.mean(np.array(ele)/1000), decimals=4))
                Std.append(np.round(np.std(np.array(ele)/1000), decimals=4))

        full_data = np.array(full_data)
        #print (np.array(Mean), np.array(Std))

        Avg = np.round(np.mean(full_data/1000), decimals=3)
        STD = np.round(np.std(full_data/1000), decimals=3)
        print (Avg, STD)

        data_X, data_Y = np.unique(full_data, return_counts=True)
        print (np.where(data_X==100), data_Y)
        print (list(data_X).index(100), np.cumsum(data_Y/sum(data_Y))[100])

        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'

        ax1 = plt.subplot(1, 3, 3)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        width = 0.50
        ax1.plot(data_X/1000, data_Y*100/sum(data_Y))
        ax1.vlines(Avg, 0, 4.2, linestyle='dashed', color='r')
        #ax1.errorbar(range(0,len(data_X)), data_X, yerr=data_Y, elinewidth = width)
        #ax1.vlines(range(0,len(data_X)), data_X-data_Y, data_X+data_Y, linestyles='solid', linewidth=1.0, color='red', alpha=0.5)
        ax1.set_ylabel(r'PDF $(\times~ 10^{-2})$', fontsize=fontsizeY)
        ax1.set_xlabel('Fraction of unclassified haplotypes', fontsize=fontsizeY)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0.0,7.2,2.0), minor = False)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,7.2,2/4), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.47,0.1), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.47,0.05/2), minor = True)
        ax1.set_xlim(-0.008,0.36)
        ax1.set_ylim(-0.10, 7.2)
        ax1.text(Avg+0.03, 1.25, Avg, fontsize=fontsizeX-2, color='r')
        ax1.set_title(Title[2], loc='left', fontweight='bold')


        ax2 = inset_axes(ax1, 1.2, 0.8 , loc=1, bbox_to_anchor=(1.006, 0.95),bbox_transform=ax1.figure.transFigure)
        ax2.spines.right.set_visible(False)
        ax2.spines.top.set_visible(False)
        ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0.0,1.01,0.5), minor = False)
        ax2.tick_params(axis = 'y', which = 'minor', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0,1.01,0.1), minor = True)
        ax2.tick_params(axis = 'x', which = 'major', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.47,0.1), minor = False)
        ax2.tick_params(axis = 'x', which = 'minor', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.47,0.05/2), minor = True)
        ax2.set_xlim(-0.008,0.36)
        ax2.set_ylim(-0.015, 1.015)
        ax2.plot(data_X/1000, np.cumsum(data_Y/sum(data_Y)))
        ax2.vlines(0.1, 0, 1.05, linestyle='dashed', color='k')
        #ax2.hlines(np.cumsum(data_Y/sum(data_Y))[100], 0, 0.1, linestyle='dashed', color='r')
        if data_X[100] == 100:
            ax2.text(0.123, 0.77, np.round(np.cumsum(data_Y/sum(data_Y))[100], 2), fontsize=fontsizeX-2)
        ax2.set_ylabel(r'CDF', fontsize=fontsizeX-3, labelpad=-0.5)


        plt.savefig('../SI_figures/Fig_ext_splt_statistics_halfmutation.pdf', transparent=True)
        #plt.show()
        plt.close()

    #E = -6, N = 500, alpha = 0.6, alpha = 0.9
    if index == 8:

        E = -6; N = 500
        x_lim_min = 3
        x_lim_max = 15
        directory = './ext_split_stat/alpha06delta09'


        cum_t_n_gro_dict = pickle.load(open(directory + '/cum_t_n_gro_dict.pkl', 'rb'))
        #n_gro_before_splt_dict = pickle.load(open(directory + '/n_gro_before_splt_dict.pkl', 'rb'))
        #n_gro_before_ext_dict = pickle.load(open(directory + '/n_gro_before_ext_dict.pkl', 'rb'))
        '''
        n_gro_before_ext_all_files_dict = {}
        n_gro_before_splt_all_files_dict = {}
        for n_gro in range(1,30):
            n_gro_before_ext_all_files_dict[n_gro] = 0
            n_gro_before_splt_all_files_dict[n_gro] = 0

        for vals in n_gro_before_ext_dict.values():
            for n_gro, num in vals.items():
                n_gro_before_ext_all_files_dict[n_gro] += num

        for vals in n_gro_before_splt_dict.values():
            for n_gro, num in vals.items():
                n_gro_before_splt_all_files_dict[n_gro] += num


        p_ext_given_k_gro = {}
        p_splt_given_k_gro = {}
        p_ext_splt_given_k_gro = {}


        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):

            if cum_t_n_gro_dict[n_gro] == 0:
                p_ext_given_k_gro[n_gro] = np.nan
                p_splt_given_k_gro[n_gro] = np.nan
                p_ext_splt_given_k_gro[n_gro] = np.nan

            else:
                p_ext_given_k_gro[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                    cum_t_n_gro_dict[n_gro]
                p_splt_given_k_gro[n_gro] = n_gro_before_splt_all_files_dict[n_gro]/ \
                    cum_t_n_gro_dict[n_gro]
                p_ext_splt_given_k_gro[n_gro] = (n_gro_before_splt_all_files_dict[n_gro] \
                     + n_gro_before_ext_all_files_dict[n_gro])/ \
                    cum_t_n_gro_dict[n_gro]

        p_gro_before_ext_all_files_dict = {}
        p_gro_before_splt_all_files_dict = {}
        prop_ext_all_files_dict = {}
        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):
            p_gro_before_ext_all_files_dict[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                np.sum(list(n_gro_before_ext_all_files_dict.values()))

            p_gro_before_splt_all_files_dict[n_gro] = n_gro_before_splt_all_files_dict[n_gro]/ \
                np.sum(list(n_gro_before_splt_all_files_dict.values()))

        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):
            if (n_gro_before_splt_all_files_dict[n_gro] \
                 + n_gro_before_ext_all_files_dict[n_gro]) == 0:
                prop_ext_all_files_dict[n_gro] = np.nan
            else:
                prop_ext_all_files_dict[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                (n_gro_before_splt_all_files_dict[n_gro] \
                 + n_gro_before_ext_all_files_dict[n_gro])
        '''




        fig = plt.figure(figsize=(8,2.5))
        plt.subplots_adjust(top=0.910, bottom=0.14, left=0.056, right=0.995, hspace=0.40, wspace=0.27)
        fontsizeX, fontsizeY, fonttitle, fontticks, fontsizetext = 9, 8, 9, 6.5, 8


        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'




        data_1_key, data_1_value = np.array(list(cum_t_n_gro_dict.keys())), list(cum_t_n_gro_dict.values())/np.sum(list(cum_t_n_gro_dict.values()))
        print (data_1_key, data_1_value)
        width = 0.3
        #print (len(list(p_gro_before_ext_all_files_dict.values())))
        #data_2a_key, data_2a_value = np.arange(x_lim_min-1,int(np.ceil(x_lim_max)))-width/2, list(p_gro_before_ext_all_files_dict.values())
        #data_2b_key, data_2b_value = np.arange(x_lim_min-1,int(np.ceil(x_lim_max)))+width/2, list(p_gro_before_splt_all_files_dict.values())
        #data_3a_key, data_3a_value = np.array(list(p_ext_given_k_gro.keys())) - width/2, np.array(list(p_ext_given_k_gro.values()))*1000
        #data_3b_key, data_3b_value = np.array(list(p_splt_given_k_gro.keys())) + width/2, np.array(list(p_splt_given_k_gro.values()))*1000



        width1=0.4
        binSize = 28

        ax1 = plt.subplot(1, 3, 1)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        ax1.bar(data_1_key, data_1_value, color = 'k', width = width1)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize = 0)
        ax1.set_yticks(np.arange(0,0.32,0.01), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(x_lim_min+1,x_lim_max+0.0,2), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,1), minor = True)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,0.32,0.10), minor = False)
        ax1.set_title(Title[0], loc='left', fontweight='bold')
        ax1.set_ylabel('Fraction of time in $K$ classes', fontsize=fontsizeY, labelpad=5)
        ax1.set_xlabel('# classes', fontsize=fontsizeY)
        ax1.set_xlim(x_lim_min+0.5, x_lim_max-0.5)
        ax1.set_xlabel('# classes', fontsize=fontsizeY)


        non_classified = pickle.load(open('./unclassified_hap/num_SC_haps_all_iters_all_files_E-6_N500_a06_d_09.pkl', 'rb'))
        #print (type(non_classified), len(non_classified))


        Mean, Std, full_data = [], [], []
        for ele in non_classified:
            full_data.extend(ele)
            if len(ele) > 0:
                Mean.append(np.round(np.mean(np.array(ele)/1000), decimals=4))
                Std.append(np.round(np.std(np.array(ele)/1000), decimals=4))

        full_data = np.array(full_data)
        #print (np.array(Mean), np.array(Std))

        Avg = np.round(np.mean(full_data/1000), decimals=3)
        STD = np.round(np.std(full_data/1000), decimals=3)
        print (Avg, STD)

        data_X, data_Y = np.unique(full_data, return_counts=True)
        print (max(data_X)/1000, 'x limit', '\n')

        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'

        ax1 = plt.subplot(1, 3, 2)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        width = 0.50
        ax1.plot(data_X/1000, data_Y*100/sum(data_Y))
        ax1.vlines(Avg, 0, 3.8, linestyle='dashed', color='r')
        #ax1.errorbar(range(0,len(data_X)), data_X, yerr=data_Y, elinewidth = width)
        #ax1.vlines(range(0,len(data_X)), data_X-data_Y, data_X+data_Y, linestyles='solid', linewidth=1.0, color='red', alpha=0.5)
        ax1.set_ylabel(r'PDF $(\times~ 10^{-2})$', fontsize=fontsizeY)
        ax1.set_xlabel('Fraction of SC haplotypes', fontsize=fontsizeY)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0.0,7.0,2.0), minor = False)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,8,0.5/2), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.75,0.2), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.75,0.2/4), minor = True)
        ax1.set_xlim(-0.01,0.75)
        ax1.set_ylim(-0.08, 4.1)
        ax1.text(Avg+0.025, 3.0, Avg, fontsize=fontsizeX-2, color='r')
        ax1.set_title(Title[1], loc='left', fontweight='bold')


        ax2 = inset_axes(ax1, 1.2, 0.8 , loc=1, bbox_to_anchor=(0.66, 0.95),bbox_transform=ax1.figure.transFigure)
        ax2.spines.right.set_visible(False)
        ax2.spines.top.set_visible(False)
        ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0.0,1.01,0.5), minor = False)
        ax2.tick_params(axis = 'y', which = 'minor', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0,1.01,0.1), minor = True)
        ax2.tick_params(axis = 'x', which = 'major', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.75,0.2), minor = False)
        ax2.tick_params(axis = 'x', which = 'minor', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.75,0.2/4), minor = True)
        ax2.set_xlim(-0.01, 0.75)
        ax2.set_ylim(-0.015, 1.015)
        ax2.plot(data_X/1000, np.cumsum(data_Y/sum(data_Y)))
        #ax2.vlines(0.1, 0, 1.05, linestyle='dashed', color='k')
        #ax2.hlines(np.cumsum(data_Y/sum(data_Y))[100], 0, 0.1, linestyle='dashed', color='r')
        #ax2.text(0.123, 0.77, np.round(np.cumsum(data_Y/sum(data_Y))[100], 2), fontsize=fontsizeX-2)
        ax2.set_ylabel(r'CDF', fontsize=fontsizeX-3, labelpad=-0.5)






        non_classified = pickle.load(open('./unclassified_hap/n_non_class_hap_all_iters_all_files_E-6_N500_a06_d_09.pkl', 'rb'))
        print (type(non_classified), len(non_classified))


        Mean, Std, full_data = [], [], []
        for ele in non_classified:
            full_data.extend(ele)
            if len(ele) > 0:
                Mean.append(np.round(np.mean(np.array(ele)/1000), decimals=4))
                Std.append(np.round(np.std(np.array(ele)/1000), decimals=4))

        full_data = np.array(full_data)
        print (np.array(Mean), np.array(Std))

        Avg = np.round(np.mean(full_data/1000), decimals=3)
        STD = np.round(np.std(full_data/1000), decimals=3)
        print (Avg, STD)

        data_X, data_Y = np.unique(full_data, return_counts=True)
        print (max(data_X), 'x limit')

        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'

        ax1 = plt.subplot(1, 3, 3)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        width = 0.50
        ax1.plot(data_X/1000, data_Y*100/sum(data_Y))
        ax1.vlines(Avg, 0, 1.2, linestyle='dashed', color='r')
        #ax1.errorbar(range(0,len(data_X)), data_X, yerr=data_Y, elinewidth = width)
        #ax1.vlines(range(0,len(data_X)), data_X-data_Y, data_X+data_Y, linestyles='solid', linewidth=1.0, color='red', alpha=0.5)
        ax1.set_ylabel(r'PDF $(\times~ 10^{-2})$', fontsize=fontsizeY)
        ax1.set_xlabel('Fraction of unclassified haplotypes', fontsize=fontsizeY)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0.0,2.2,0.5), minor = False)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,2.2,0.1), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.8,0.2), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.8,0.2/4), minor = True)
        ax1.set_xlim(-0.008,0.8)
        ax1.set_ylim(-0.02, 1.5)
        ax1.text(Avg-0.018, 1.25, Avg, fontsize=fontsizeX-2, color='r')
        ax1.set_title(Title[2], loc='left', fontweight='bold')


        ax2 = inset_axes(ax1, 1.2, 0.8 , loc=1, bbox_to_anchor=(1.006, 0.95),bbox_transform=ax1.figure.transFigure)
        ax2.spines.right.set_visible(False)
        ax2.spines.top.set_visible(False)
        ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0.0,1.01,0.5), minor = False)
        ax2.tick_params(axis = 'y', which = 'minor', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0,1.01,0.1), minor = True)
        ax2.tick_params(axis = 'x', which = 'major', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.8,0.2), minor = False)
        ax2.tick_params(axis = 'x', which = 'minor', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.8,0.2/4), minor = True)
        ax2.set_xlim(-0.008,0.8)
        ax2.set_ylim(-0.015, 1.015)
        ax2.plot(data_X/1000, np.cumsum(data_Y/sum(data_Y)))
        ax2.vlines(0.1, 0, 1.05, linestyle='dashed', color='k')
        #ax2.hlines(np.cumsum(data_Y/sum(data_Y))[100], 0, 0.1, linestyle='dashed', color='r')
        if data_X[100] == 100:
            ax2.text(0.123, 0.67, np.round(np.cumsum(data_Y/sum(data_Y))[100], 2), fontsize=fontsizeX-2)
        ax2.set_ylabel(r'CDF', fontsize=fontsizeX-3, labelpad=-0.5)


        plt.savefig('../SI_figures/Fig_ext_splt_statistics_alpha06delta09.pdf', transparent=True)
        #plt.show()
        plt.close()

    #E = -6, N = 500, mu = 10^-4, Pdel=Pdup=0
    if index == 9:

        E = -6
        x_lim_min = 4
        x_lim_max = 11
        directory = './ext_split_stat/pdel0_pdup0'


        cum_t_n_gro_dict = pickle.load(open(directory + '/cum_t_n_gro_dict.pkl', 'rb'))
        n_gro_before_splt_dict = pickle.load(open(directory + '/n_gro_before_splt_dict.pkl', 'rb'))
        n_gro_before_ext_dict = pickle.load(open(directory + '/n_gro_before_ext_dict.pkl', 'rb'))

        n_gro_before_ext_all_files_dict = {}
        n_gro_before_splt_all_files_dict = {}
        for n_gro in range(1,30):
            n_gro_before_ext_all_files_dict[n_gro] = 0
            n_gro_before_splt_all_files_dict[n_gro] = 0

        for vals in n_gro_before_ext_dict.values():
            for n_gro, num in vals.items():
                n_gro_before_ext_all_files_dict[n_gro] += num

        for vals in n_gro_before_splt_dict.values():
            for n_gro, num in vals.items():
                n_gro_before_splt_all_files_dict[n_gro] += num


        p_ext_given_k_gro = {}
        p_splt_given_k_gro = {}
        p_ext_splt_given_k_gro = {}


        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):

            if cum_t_n_gro_dict[n_gro] == 0:
                p_ext_given_k_gro[n_gro] = np.nan
                p_splt_given_k_gro[n_gro] = np.nan
                p_ext_splt_given_k_gro[n_gro] = np.nan

            else:
                p_ext_given_k_gro[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                    cum_t_n_gro_dict[n_gro]
                p_splt_given_k_gro[n_gro] = n_gro_before_splt_all_files_dict[n_gro]/ \
                    cum_t_n_gro_dict[n_gro]
                p_ext_splt_given_k_gro[n_gro] = (n_gro_before_splt_all_files_dict[n_gro] \
                     + n_gro_before_ext_all_files_dict[n_gro])/ \
                    cum_t_n_gro_dict[n_gro]

        p_gro_before_ext_all_files_dict = {}
        p_gro_before_splt_all_files_dict = {}
        prop_ext_all_files_dict = {}
        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):
            p_gro_before_ext_all_files_dict[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                np.sum(list(n_gro_before_ext_all_files_dict.values()))

            p_gro_before_splt_all_files_dict[n_gro] = n_gro_before_splt_all_files_dict[n_gro]/ \
                np.sum(list(n_gro_before_splt_all_files_dict.values()))

        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):
            if (n_gro_before_splt_all_files_dict[n_gro] \
                 + n_gro_before_ext_all_files_dict[n_gro]) == 0:
                prop_ext_all_files_dict[n_gro] = np.nan
            else:
                prop_ext_all_files_dict[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                (n_gro_before_splt_all_files_dict[n_gro] \
                 + n_gro_before_ext_all_files_dict[n_gro])





        fig = plt.figure(figsize=(8,3.0))
        plt.subplots_adjust(top=0.926, bottom=0.117, left=0.055, right=0.995, hspace=0.40, wspace=0.27)
        fontsizeX, fontsizeY, fonttitle, fontticks, fontsizetext = 9, 8, 9, 6.5, 8


        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'



        data_1_key, data_1_value = np.array(list(cum_t_n_gro_dict.keys())), list(cum_t_n_gro_dict.values())/np.sum(list(cum_t_n_gro_dict.values()))
        width = 0.3
        print (data_1_key, data_1_value)
        print (len(list(p_gro_before_ext_all_files_dict.values())))
        data_2a_key, data_2a_value = np.arange(x_lim_min-1,int(np.ceil(x_lim_max)))-width/2, list(p_gro_before_ext_all_files_dict.values())
        data_2b_key, data_2b_value = np.arange(x_lim_min-1,int(np.ceil(x_lim_max)))+width/2, list(p_gro_before_splt_all_files_dict.values())
        data_3a_key, data_3a_value = np.array(list(p_ext_given_k_gro.keys())) - width/2, np.array(list(p_ext_given_k_gro.values()))*1000
        data_3b_key, data_3b_value = np.array(list(p_splt_given_k_gro.keys())) + width/2, np.array(list(p_splt_given_k_gro.values()))*1000



        width1=0.4
        binSize = 28

        ax1 = plt.subplot(1, 3, 1)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        ax1.bar(data_1_key, data_1_value, color = 'k', width = width1)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize = 0)
        ax1.set_yticks(np.arange(0,0.36,0.01), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(x_lim_min+2,x_lim_max+1.0,2), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,1), minor = True)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,0.36,0.10), minor = False)
        ax1.set_title(Title[0], loc='left', fontweight='bold')
        ax1.set_ylabel('Fraction of time in $K$ classes', fontsize=fontsizeY)
        #ax1.set_xlabel('# classes', fontsize=fontsizeY)
        ax1.set_xlim(x_lim_min+0.5, x_lim_max-0.5)
        ax1.set_xlabel('# classes', fontsize=fontsizeY)

        width=width
        ax2 = plt.subplot(1, 3, 2)
        ax2.spines.right.set_visible(False)
        ax2.spines.top.set_visible(False)
        ax2.bar(data_2a_key, data_2a_value, width=width, color=color3, label='extinctions')
        ax2.bar(data_2b_key, data_2b_value, width=width, color=color1, label='splits')
        ax2.set_xlim(-3, 500)
        ax2.tick_params(axis = 'y', which = 'minor', labelsize = 0)
        ax2.set_yticks(np.arange(0,0.36,0.01), minor = True)
        ax2.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax2.set_xticks(np.arange(x_lim_min+2,x_lim_max+1.0,2), minor = False)
        ax2.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax2.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,1), minor = True)
        ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax2.set_yticks(np.arange(0,0.36,0.10), minor = False)
        ax2.set_title(Title[1], loc='left', fontweight='bold')
        #ax2.set_xlabel('# classes', fontsize=fontsizeY)
        ax2.set_ylabel('Fraction of events in $K$ classes', fontsize=fontsizeY, labelpad=13)
        ax2.legend(frameon=False, ncol=2, fontsize=fontticks, bbox_to_anchor=(1.0, 1.07))
        ax2.set_xlim(x_lim_min+0.5,x_lim_max-0.5)
        ax2.set_xlabel('# classes', fontsize=fontsizeY)

        ax3 = plt.subplot(1, 3, 3)
        ax3.spines.right.set_visible(False)
        ax3.spines.top.set_visible(False)
        ax3.bar(data_3a_key, data_3a_value, width=width, color=color3, label='extinctions')
        ax3.bar(data_3b_key, data_3b_value, width=width, color=color1, label='split')
        ax3.tick_params(axis = 'y', which = 'minor', labelsize = 0)
        ax3.set_yticks(np.arange(0,180,10), minor = True)
        ax3.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax3.set_xticks(np.arange(x_lim_min+2,x_lim_max+1.0,2), minor = False)
        ax3.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax3.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,1), minor = True)
        ax3.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax3.set_yticks(np.arange(1,180,25), minor = False)
        ax3.set_title(Title[2], loc='left', fontweight='bold')
        #ax3.set_xlabel('# classes', fontsize=fontsizeY)
        ax3.set_ylabel('# events in $K$ classes / total \ntime in $K$ classes '+r'$(\times 10^{-3})$', fontsize=fontsizeY, labelpad=-3)
        ax3.set_xlim(x_lim_min+0.5,x_lim_max-0.5)
        ax3.set_ylim(0.05,10)
        ax3.set_yscale('log')
        ax3.set_xlabel('# classes', fontsize=fontsizeY)


        plt.savefig('../SI_figures/Fig_ext_splt_statistics_pdel0_pdup0.pdf', transparent=True)
        #plt.show()
        plt.close()

    #E = -6, N = 500, alpha = 0.6, alpha = 0.9
    if index == 10:

        E = -6; N = 1000
        x_lim_min = 5
        x_lim_max = 19
        directory = './ext_split_stat/N1000'


        cum_t_n_gro_dict = pickle.load(open(directory + '/cum_t_n_gro_dict.pkl', 'rb'))
        #n_gro_before_splt_dict = pickle.load(open(directory + '/n_gro_before_splt_dict.pkl', 'rb'))
        #n_gro_before_ext_dict = pickle.load(open(directory + '/n_gro_before_ext_dict.pkl', 'rb'))
        '''
        n_gro_before_ext_all_files_dict = {}
        n_gro_before_splt_all_files_dict = {}
        for n_gro in range(1,30):
            n_gro_before_ext_all_files_dict[n_gro] = 0
            n_gro_before_splt_all_files_dict[n_gro] = 0

        for vals in n_gro_before_ext_dict.values():
            for n_gro, num in vals.items():
                n_gro_before_ext_all_files_dict[n_gro] += num

        for vals in n_gro_before_splt_dict.values():
            for n_gro, num in vals.items():
                n_gro_before_splt_all_files_dict[n_gro] += num


        p_ext_given_k_gro = {}
        p_splt_given_k_gro = {}
        p_ext_splt_given_k_gro = {}


        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):

            if cum_t_n_gro_dict[n_gro] == 0:
                p_ext_given_k_gro[n_gro] = np.nan
                p_splt_given_k_gro[n_gro] = np.nan
                p_ext_splt_given_k_gro[n_gro] = np.nan

            else:
                p_ext_given_k_gro[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                    cum_t_n_gro_dict[n_gro]
                p_splt_given_k_gro[n_gro] = n_gro_before_splt_all_files_dict[n_gro]/ \
                    cum_t_n_gro_dict[n_gro]
                p_ext_splt_given_k_gro[n_gro] = (n_gro_before_splt_all_files_dict[n_gro] \
                     + n_gro_before_ext_all_files_dict[n_gro])/ \
                    cum_t_n_gro_dict[n_gro]

        p_gro_before_ext_all_files_dict = {}
        p_gro_before_splt_all_files_dict = {}
        prop_ext_all_files_dict = {}
        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):
            p_gro_before_ext_all_files_dict[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                np.sum(list(n_gro_before_ext_all_files_dict.values()))

            p_gro_before_splt_all_files_dict[n_gro] = n_gro_before_splt_all_files_dict[n_gro]/ \
                np.sum(list(n_gro_before_splt_all_files_dict.values()))

        for n_gro in range(x_lim_min-1,int(np.ceil(x_lim_max))):
            if (n_gro_before_splt_all_files_dict[n_gro] \
                 + n_gro_before_ext_all_files_dict[n_gro]) == 0:
                prop_ext_all_files_dict[n_gro] = np.nan
            else:
                prop_ext_all_files_dict[n_gro] = n_gro_before_ext_all_files_dict[n_gro]/ \
                (n_gro_before_splt_all_files_dict[n_gro] \
                 + n_gro_before_ext_all_files_dict[n_gro])
        '''




        fig = plt.figure(figsize=(8,2.5))
        plt.subplots_adjust(top=0.910, bottom=0.14, left=0.056, right=0.995, hspace=0.40, wspace=0.27)
        fontsizeX, fontsizeY, fonttitle, fontticks, fontsizetext = 9, 8, 9, 6.5, 8


        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'




        data_1_key, data_1_value = np.array(list(cum_t_n_gro_dict.keys())), list(cum_t_n_gro_dict.values())/np.sum(list(cum_t_n_gro_dict.values()))
        print (data_1_key, data_1_value)
        width = 0.3
        #print (len(list(p_gro_before_ext_all_files_dict.values())))
        #data_2a_key, data_2a_value = np.arange(x_lim_min-1,int(np.ceil(x_lim_max)))-width/2, list(p_gro_before_ext_all_files_dict.values())
        #data_2b_key, data_2b_value = np.arange(x_lim_min-1,int(np.ceil(x_lim_max)))+width/2, list(p_gro_before_splt_all_files_dict.values())
        #data_3a_key, data_3a_value = np.array(list(p_ext_given_k_gro.keys())) - width/2, np.array(list(p_ext_given_k_gro.values()))*1000
        #data_3b_key, data_3b_value = np.array(list(p_splt_given_k_gro.keys())) + width/2, np.array(list(p_splt_given_k_gro.values()))*1000



        width1=0.4
        binSize = 28

        ax1 = plt.subplot(1, 3, 1)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        ax1.bar(data_1_key, data_1_value, color = 'k', width = width1)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize = 0)
        ax1.set_yticks(np.arange(0,0.26,0.01), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(x_lim_min+1,x_lim_max+0.0,2), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(x_lim_min,x_lim_max+1.0,1), minor = True)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,0.26,0.10), minor = False)
        ax1.set_title(Title[0], loc='left', fontweight='bold')
        ax1.set_ylabel('Fraction of time in $K$ classes', fontsize=fontsizeY, labelpad=5)
        ax1.set_xlabel('# classes', fontsize=fontsizeY)
        ax1.set_xlim(x_lim_min+0.5, x_lim_max-0.5)
        ax1.set_xlabel('# classes', fontsize=fontsizeY)


        non_classified = pickle.load(open('./unclassified_hap/num_SC_haps_all_iters_all_files_E-6_N1000_a095_d_1.pkl', 'rb'))
        #print (type(non_classified), len(non_classified))

        #Mean, Std, full_data = [], [], []
        #for ele in non_classified:
        #    full_data.extend(ele)
        #    if len(ele) > 0:
        #        Mean.append(np.round(np.mean(np.array(ele)/1000), decimals=4))
        #        Std.append(np.round(np.std(np.array(ele)/1000), decimals=4))

        #full_data = np.array(full_data)
        #print (np.array(Mean), np.array(Std))
        full_data = np.array(non_classified)
        Avg = np.round(np.mean(full_data/(2*N)), decimals=3)
        STD = np.round(np.std(full_data/(2*N)), decimals=3)
        print (Avg, STD)

        data_X, data_Y = np.unique(full_data, return_counts=True)
        print (max(data_X)/(2*N), 'x limit', '\n')

        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'

        ax1 = plt.subplot(1, 3, 2)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        width = 0.50
        ax1.plot(data_X/(2*N), data_Y*100/sum(data_Y))
        ax1.vlines(Avg, 0, 10.8, linestyle='dashed', color='r')
        #ax1.errorbar(range(0,len(data_X)), data_X, yerr=data_Y, elinewidth = width)
        #ax1.vlines(range(0,len(data_X)), data_X-data_Y, data_X+data_Y, linestyles='solid', linewidth=1.0, color='red', alpha=0.5)
        ax1.set_ylabel(r'PDF $(\times~ 10^{-2})$', fontsize=fontsizeY)
        ax1.set_xlabel('Fraction of SC haplotypes', fontsize=fontsizeY)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0.0,14.0,5), minor = False)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,14,5/10), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.031/2,0.01), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.03/2,0.01/8), minor = True)
        ax1.set_xlim(-0.0005,0.028/2)
        ax1.set_ylim(-0.16, 14.1)
        ax1.text(Avg+0.0005, 2.0, Avg, fontsize=fontsizeX-2, color='r')
        ax1.set_title(Title[1], loc='left', fontweight='bold')


        ax2 = inset_axes(ax1, 1.2, 0.8 , loc=1, bbox_to_anchor=(0.66, 0.95),bbox_transform=ax1.figure.transFigure)
        ax2.spines.right.set_visible(False)
        ax2.spines.top.set_visible(False)
        ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0.0,1.01,0.5), minor = False)
        ax2.tick_params(axis = 'y', which = 'minor', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0,1.01,0.1), minor = True)
        ax2.tick_params(axis = 'x', which = 'major', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.05/2,0.01), minor = False)
        ax2.tick_params(axis = 'x', which = 'minor', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.05/2,0.01/8), minor = True)
        ax2.set_xlim(-0.0005, 0.028/2)
        ax2.set_ylim(-0.015, 1.015)
        ax2.plot(data_X/(2*N), np.cumsum(data_Y/sum(data_Y)))
        #ax2.vlines(0.1, 0, 1.05, linestyle='dashed', color='k')
        #ax2.hlines(np.cumsum(data_Y/sum(data_Y))[100], 0, 0.1, linestyle='dashed', color='r')
        #ax2.text(0.123, 0.77, np.round(np.cumsum(data_Y/sum(data_Y))[100], 2), fontsize=fontsizeX-2)
        ax2.set_ylabel(r'CDF', fontsize=fontsizeX-3, labelpad=-0.5)






        non_classified = pickle.load(open('./unclassified_hap/n_non_class_hap_all_iters_all_files_E-6_N1000_a095_d_1.pkl', 'rb'))
        #print (non_classified, type(non_classified), len(non_classified))


        #Mean, Std, full_data = [], [], []
        #for ele in non_classified:
        #    full_data.extend(ele)
        #    if len(ele) > 0:
        #        Mean.append(np.round(np.mean(np.array(ele)/1000), decimals=4))
        #        Std.append(np.round(np.std(np.array(ele)/1000), decimals=4))

        #full_data = np.array(full_data)
        #print (np.array(Mean), np.array(Std))
        full_data = np.array(non_classified)
        Avg = np.round(np.mean(full_data/(2*N)), decimals=3)
        STD = np.round(np.std(full_data/(2*N)), decimals=3)
        print (Avg, STD)

        data_X, data_Y = np.unique(full_data, return_counts=True)
        print (max(data_X), len(data_X), data_X[197], 'x limit')

        Title = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i']
        alpha_Color = 0.25
        lw = 0.5; mW = 1.5; mS = 6
        color1, color2, color3 = 'g', 'b', 'r'

        ax1 = plt.subplot(1, 3, 3)
        ax1.spines.right.set_visible(False)
        ax1.spines.top.set_visible(False)
        width = 0.50
        ax1.plot(data_X/(2*N), data_Y*100/sum(data_Y))
        ax1.vlines(Avg, 0, 0.5, linestyle='dashed', color='r')
        #ax1.errorbar(range(0,len(data_X)), data_X, yerr=data_Y, elinewidth = width)
        #ax1.vlines(range(0,len(data_X)), data_X-data_Y, data_X+data_Y, linestyles='solid', linewidth=1.0, color='red', alpha=0.5)
        ax1.set_ylabel(r'PDF $(\times~ 10^{-2})$', fontsize=fontsizeY)
        ax1.set_xlabel('Fraction of unclassified haplotypes', fontsize=fontsizeY)
        ax1.tick_params(axis = 'y', which = 'major', labelsize=fontticks)
        ax1.set_yticks(np.arange(0.0,0.7,0.2), minor = False)
        ax1.tick_params(axis = 'y', which = 'minor', labelsize=fontticks)
        ax1.set_yticks(np.arange(0,0.7,0.2/5), minor = True)
        ax1.tick_params(axis = 'x', which = 'major', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.8/2,0.1), minor = False)
        ax1.tick_params(axis = 'x', which = 'minor', labelsize=fontticks)
        ax1.set_xticks(np.arange(0,0.8/2,0.2/4), minor = True)
        ax1.set_xlim(-0.008,0.8/2)
        ax1.set_ylim(-0.005, 0.62)
        ax1.text(Avg-0.128/2, 0.1, Avg, fontsize=fontsizeX-2, color='r')
        ax1.set_title(Title[2], loc='left', fontweight='bold')


        ax2 = inset_axes(ax1, 1.2, 0.8 , loc=1, bbox_to_anchor=(1.006, 0.95),bbox_transform=ax1.figure.transFigure)
        ax2.spines.right.set_visible(False)
        ax2.spines.top.set_visible(False)
        ax2.tick_params(axis = 'y', which = 'major', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0.0,1.01,0.5), minor = False)
        ax2.tick_params(axis = 'y', which = 'minor', labelsize=fontticks-1)
        ax2.set_yticks(np.arange(0,1.01,0.1), minor = True)
        ax2.tick_params(axis = 'x', which = 'major', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.8/2,0.2), minor = False)
        ax2.tick_params(axis = 'x', which = 'minor', labelsize=fontticks-1)
        ax2.set_xticks(np.arange(0,0.8/2,0.2/4), minor = True)
        ax2.set_xlim(-0.008,0.8/2)
        ax2.set_ylim(-0.015, 1.015)
        ax2.plot(data_X/(2*N), np.cumsum(data_Y/sum(data_Y)))
        ax2.vlines(0.1, 0, 1.05, linestyle='dashed', color='k')
        #ax2.hlines(np.cumsum(data_Y/sum(data_Y))[100], 0, 0.1, linestyle='dashed', color='r')
        if data_X[list(data_X).index(200)] == 200:
            ax2.text(0.123, 0.67, np.round(np.cumsum(data_Y/sum(data_Y))[list(data_X).index(200)], 2), fontsize=fontsizeX-2)
        ax2.set_ylabel(r'CDF', fontsize=fontsizeX-3, labelpad=-0.5)


        plt.savefig('../SI_figures/Fig_ext_splt_statistics_N1000.pdf', transparent=True)
        #plt.show()
        plt.close()

# index = 1 = Fig_ext_splt_statistics_E-4
# index = 2 = Fig_ext_splt_statistics_E-8
# index = 3 = Fig_ext_splt_statistics_N250
# index = 4 = Fig_ext_splt_statistics_N750
# index = 5 = Fig_ext_splt_statistics_alpha08delta09
# index = 6 = Fig_ext_splt_statistics_twicemutation
# index = 7 = Fig_ext_splt_statistics_halfmutation
# index = 8 = Fig_ext_splt_statistics_alpha06delta09
# index = 9 = Fig_ext_splt_statistics_pdel0_pdup0
# index = 10 = Fig_ext_splt_statistics_N1000

#for index in range(1,11):   print (SI_figures(index))
#print (SI_figures(2))


print ('Ends|----|H:M:S|{}'.format(datetime.now() - start_time), '\n')
###############################################################################################################
###############################################################################################################
